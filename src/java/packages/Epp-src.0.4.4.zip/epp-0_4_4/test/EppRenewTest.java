/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppRenewTest.java,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.command.*;
import com.neulevel.epp.core.response.*;

import java.util.*;
import org.w3c.dom.*;

/**
 * The <code>EppRenewTest</code> class tests functions of
 * <code>EppCommandRenew</code> commands.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
public class EppRenewTest
{
	public static void main( String argv[] )
	{
		testDomain();
		testSvcsub();
	}

	private static void testDomain()
	{
		Node epp;
		EppCommandRenewDomain cmd;
		EppCommandRenewDomain newcmd;
		Calendar cal = Calendar.getInstance();

		cmd = new EppCommandRenewDomain("example.biz", cal);
		cmd.setPeriod(new EppPeriod(1, 'y'));
		cmd.setClientTransactionId("ABC-DEF-12345");
		System.out.println(cmd);

		EppParser parser = new EppParser(cmd.toString());
		if( parser.hasError() )
		{
			System.out.println(parser.getResult());
			System.exit(1);
		}

		epp = parser.getRootNode();
		newcmd = (EppCommandRenewDomain) EppCommand.fromXML(epp);
		if( newcmd == null )
		{
			System.out.println("Error in fromXML");
			System.exit(1);
		}
		System.out.println(newcmd);
	}

	private static void testSvcsub()
	{
		Node epp;
		EppCommandRenewSvcsub cmd;
		EppCommandRenewSvcsub newcmd;
		Calendar cal = Calendar.getInstance();

		cmd = new EppCommandRenewSvcsub("BIZLOCK-123", cal);
		cmd.setUserId("myUserId");
		cmd.setAuthInfo(new EppAuthInfo(EppAuthInfo.TYPE_PW, "2fooBAR"));
		cmd.setPeriod(new EppPeriod(1, 'y'));
		cmd.setClientTransactionId("ABC-DEF-12345");
		System.out.println(cmd);

		EppParser parser = new EppParser(cmd.toString());
		if( parser.hasError() )
		{
			System.out.println(parser.getResult());
			System.exit(1);
		}

		epp = parser.getRootNode();
		newcmd = (EppCommandRenewSvcsub) EppCommand.fromXML(epp);
		if( newcmd == null )
		{
			System.out.println("Error in fromXML");
			System.exit(1);
		}
		System.out.println(newcmd);
	}
}
