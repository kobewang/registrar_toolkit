/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: BizProtect.java,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
package com.neulevel.biz;

/**
 * This <code>BizProtect</code> class defines various services ids
 * in the BIZprotect product suite.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
public class BizProtect
{
	/**
	 * Service ID for BIZ Account
	 */
	public static final String BIZ_ACCOUNT = "BIZaccount";

	/**
	 * Service ID for BIZ Lock
	 */
	public static final String BIZ_LOCK = "BIZlock";
}
