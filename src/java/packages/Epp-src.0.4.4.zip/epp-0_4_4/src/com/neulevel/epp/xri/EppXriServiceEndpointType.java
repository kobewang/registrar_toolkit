/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppXriServiceEndpointType.java,v 1.1 2006/03/12 02:01:30 wtan Exp $
 */
package com.neulevel.epp.xri;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.EppEntity;
import com.neulevel.epp.core.EppUtil;


/**
 * This <code>EppXriServiceEndpointType</code> class encapsulates
 * the EPP XRI Authority ServiceEndpoint Type as defined in the
 * XRI Authority XML Schema type <code>sepTypeType</code>.
 *
 * @author William Tan william.tan@neustar.biz
 * @version $Revision: 1.1 $ $Date: 2006/03/12 02:01:30 $
 */
public class EppXriServiceEndpointType extends EppXriServiceEndpointRule
{
	/**
	 * Creates a default <code>EppXriServiceEndpointType</code> object
	 */
	public EppXriServiceEndpointType()
	{
		super();
	}

	/**
	 * Creates an <code>EppXriServiceEndpointType</code> object with the specified fields
	 */
	public EppXriServiceEndpointType( String type, String match, Boolean select )
	{
		super(type, match, select);
	}

	/**
	 * Converts an XML element into an <code>EppXriServiceEndpointType</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP XRI sepTypeType.
	 *
	 * @param root root node for an <code>EppXriServiceEndpoint</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriServiceEndpointType</code> object, or null if the node is
	 *         invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppXriServiceEndpointType sepType = new EppXriServiceEndpointType();
		sepType.setFromXML(root);
		return sepType;
	}

	/**
	 * Gets the value of this Type rule.
	 * This is an alias for the superclass' <code>getValue</code> method.
	 */
	public String getType()
	{
		return getValue();
	}

	/**
	 * Sets the value of this Type rule.
	 * This is an alias for the superclass' <code>setValue</code> method.
	 */
	public void setType( String type )
	{
		setValue(type);
	}


	public String toString()
	{
		return toString("type");
	}
}
