/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppXriRef.java,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
package com.neulevel.epp.xri;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.EppEntity;
import com.neulevel.epp.core.EppUtil;

/**
 * This <code>EppXriRef</code> class defines Ref 
 * information associated with XRI authority objects.  It
 * implements XRI refAddType and refInfType defined
 * in the XRI authority schema file.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
public class EppXriRef extends EppEntity
{
	/**
	 * Default priority value - 10
	 */
	public static final int     DEFAULT_PRIORITY = 10;

	private int     priority;
	private String  ref;

	/**
	 * Creates an <code>EppXriRef</code> object
	 */
	public EppXriRef()
	{
		this(null);
	}

	/**
	 * Creates an <code>EppXriRef</code> object with a Ref
	 * and the default priority value
	 */
	public EppXriRef( String ref )
	{
		this(ref, DEFAULT_PRIORITY);
	}

	/**
	 * Creates an <code>EppXriRef</code> object with a Ref
	 * and a priority value
	 */
	public EppXriRef( String ref, int priority )
	{
		this.priority = priority;
		this.ref      = ref;
	}

	/**
	 * Gets the priority value for this Ref
	 */
	public int getPriority()
	{
		return this.priority;
	}

	/**
	 * Sets the priority value for this Ref
	 */
	public void setPriority( int priority )
	{
		this.priority = priority;
	}

	/**
	 * Gets the XRI string of the Ref
	 */
	public String getRef()
	{
		return this.ref;
	}

	/**
	 * Sets the XRI string of the Ref
	 */
	public void setRef( String ref )
	{
		this.ref = ref;
	}

	/**
         * Converts the <code>EppXriRef</code> object into an XML element
         *
         * @param doc the XML <code>Document</code> object
         * @param tag the tag/element name for the <code>EppXriRef</code> object
         *
         * @return an <code>Element</code> object
         */
	public Element toXML( Document doc, String tag )
	{
		Element body = doc.createElement(tag);

		body.appendChild(doc.createTextNode(this.ref));
		body.setAttribute("priority", "" + this.priority);

		return body;
	}

	/**
	 * Converts an XML element into an <code>EppXriRef</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP XRI refAddType or refInfType.
	 *
	 * @param root root node for an <code>EppXriRef</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriRef</code> object, or null if the node is
	 *         invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppXriRef ref     = new EppXriRef();
		String   flag     = null;

		ref.setRef(EppUtil.getText(root));

		flag = ((Element) root).getAttribute("priority");
		if( flag != null )
		{
			try
			{
				int priority = Integer.parseInt(flag);
				ref.setPriority(priority);
			}
			catch( NumberFormatException e )
			{
			}
		}
		return ref;
	}

	public String toString()
	{
		return toString("ref");
	}
}
