/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandRenew.java,v 1.3 2006/03/01 01:35:38 wtan Exp $
 */
package com.neulevel.epp.core.command;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.xri.command.*;

/**
 * This <code>EppCommandRenew</code> class implements EPP Command Renew
 * entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.3 $ $Date: 2006/03/01 01:35:38 $
 */
abstract public class EppCommandRenew extends EppCommand
{
	/**
	 * The current expiration date of the registration for the EPP object
	 * to be renewed
	 */
	protected Calendar  curExpDate;
	/**
	 * The new registration period for the the EPP object to be renewed
	 */
	protected EppPeriod period;

	/**
	 * Gets the current expiration date of the object to be renewed
	 */
	public Calendar getCurrentExpireDate()
	{
		return this.curExpDate;
	}

	/**
	 * Sets the current expiration date of the object to be renewed
	 */
	public void setCurrentExpireDate( Calendar curExpDate )
	{
		this.curExpDate = curExpDate;
	}

	/**
	 * Gets the <code>EppPeriod</code> object containing the period
	 * to be renewed for the object
	 */
	public EppPeriod getPeriod()
	{
		return this.period;
	}

	/**
	 * Sets the <code>EppPeriod</code> object containing the period
	 * to be renewed for the object
	 */
	public void setPeriod( EppPeriod period )
	{
		this.period = period;
	}

	/**
	 * Converts an XML element into an <code>EppCommandRenew</code> object.
	 * The caller of this method must make sure that the root node is of an
	 * EPP Command Renew entity.
	 *
	 * @param root root node for an <code>EppCommandRenew</code> object
	 *             in XML format
	 *
	 * @return an <code>EppCommandRenew</code> object, or null if the node
	 *         is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		String command = root.getLocalName();
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String prefix = node.getPrefix();
			String name = node.getLocalName();
			if( (prefix == null) || (name == null) )
			{
				continue;
			}
			if( name.equals(command) )
			{
				if( prefix.equals("domain") )
				{
					return EppCommandRenewDomain.fromXML(node);
				}
				else if( prefix.equals("svcsub") )
				{
					return EppCommandRenewSvcsub.fromXML(node);
				}
				else if( prefix.equals("xriINU") )
				{
					return EppCommandRenewXriNumber.fromXML(node);
				}
				else if( prefix.equals("xriINA") )
				{
					return EppCommandRenewXriName.fromXML(node);
				}
				else if( prefix.equals("xriISV") )
				{
					return EppCommandRenewXriService.fromXML(node);
				}
			}
		}

		return null;
	}

	public String toString()
	{
		return toString("renew");
	}
}
