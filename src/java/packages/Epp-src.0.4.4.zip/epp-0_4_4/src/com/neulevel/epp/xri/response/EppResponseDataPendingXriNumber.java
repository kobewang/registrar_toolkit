/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataPendingXriNumber.java,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
package com.neulevel.epp.xri.response;

import java.util.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.response.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;

/**
 * This <code>EppResponseDataPendingXriNumber</code> class implements EPP
 * Response Data entity for EPP Pending Actions of EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
public class EppResponseDataPendingXriNumber extends EppResponseDataPending
{
	private String   inumber;

	/**
	 * Creates an <code>EppResponseDataPendingXriNumber</code> object
	 *
	 * @param inumber the i-number of the <code>EppXriNumber</code> object associated with the pending action
	 */
	public EppResponseDataPendingXriNumber( String inumber )
	{
		this.inumber = inumber;
		this.paResult = false;
		this.paTRID = null;
		this.paDate = null;
	}

	/**
	 * Creates an <code>EppResponseDataPendingXriNumber</code> object
	 *
	 * @param inumber the i-number of the <code>EppXriNumber</code> object associated with the pending action
	 * @param result the boolean flag indicating if the pending action is a success or a failure
	 */
	public EppResponseDataPendingXriNumber( String inumber, boolean result )
	{
		this.inumber = inumber;
		this.paResult = result;
		this.paTRID = null;
		this.paDate = null;
	}

	/**
	 * Gets the i-number of the XRI i-number object associated with the pending action
	*/
	public String getINumber()
	{
		return this.inumber;
	}

	/**
	 * Sets the i-number of the XRI i-number object associated with the pending action
	 */
	public void setINumber( String inumber )
	{
		this.inumber = inumber;
	}

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataPendingXriNumber</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for an pending action of an EPP XRI INumber object
	 *
	 * @param root root node for an <code>EppResponseDataPendingXriNumber</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataPendingXriNumber</code> object,
	 *         or null if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppResponseDataPendingXriNumber res = null;
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			else if( name.equals("inumber") )
			{
				String inumber = EppUtil.getText(node);
				if( res == null )
				{
					res = new EppResponseDataPendingXriNumber(inumber);
					String cd = ((Element) node).getAttribute("paResult");
					if(    (cd != null)
					    && (    cd.equals("0")
						 || cd.equalsIgnoreCase("f")
						 || cd.equalsIgnoreCase("false") ) )
					{
						res.setResult(false);
					}
					else
					{
						res.setResult(true);
					}
				}
			}
			else if( res != null )
			{
				res.fromXMLCommon(node, name);
			}
		}

		return res;
	}

	/**
	 * Converts an <code>EppResponseDataPendingXriNumber</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataPendingXriNumber</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = doc.createElement(tag);
		ElementNSImpl data = EppUtil.createElementNS(doc, "xriINU", "panData");
		body.appendChild(data);

		if( inumber != null )
		{
			elm = doc.createElement("inumber");
			elm.appendChild(doc.createTextNode(inumber));
			if( paResult == true )
			{
				elm.setAttribute("paResult", "1");
			}
			else
			{
				elm.setAttribute("paResult", "0");
			}
			data.appendChild(elm);
		}

		toXMLCommon(doc, data);

		return body;
	}
}
