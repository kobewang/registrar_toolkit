/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandInfoXriName.java,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
package com.neulevel.epp.xri.command;

import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.command.*;

/**
 * This <code>EppCommandInfo</code> class implements EPP Command Info
 * entity for EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
public class EppCommandInfoXriName extends EppCommandInfo
{
	private String iname;

	/**
	 * Creates an <code>EppCommandInfoXriName</code> object for
	 * querying an XRI i-name based on its i-name
	 */
	public EppCommandInfoXriName( String iname )
	{
		this.iname = iname;
	}

	/**
	 * Creates an <code>EppCommandInfoXriName</code> object for
	 * querying an XRI i-name based on its i-name, given a client
	 * transaction id associated with the operation
	 */
	public EppCommandInfoXriName( String iname, String xid )
	{
		this.iname = iname;
		this.clTRID = xid;
	}

	/**
	 * Gets the i-name of the XRI i-name object to be queried
	 */
	public String getIName()
	{
		return this.iname;
	}

	/**
	 * Sets the i-name of the XRI i-name object to be queried
	 */
	public void setIName( String iname )
	{
		this.iname = iname;
	}

	/**
	 * Converts the <code>EppCommandInfoXriName</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandInfoXriName</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = EppUtil.createElementNS(doc, "xriINA", tag);

		if( iname != null )
		{
			elm = doc.createElement("iname");
			elm.appendChild(doc.createTextNode(iname));
			body.appendChild(elm);
		}

		return toXMLCommon(doc, tag, body);
	}

	/**
	 * Converts an XML element into an <code>EppCommandInfoXriName</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Info entity for EPP XriName object.
	 *
	 * @param root root node for an <code>EppCommandInfoXriName</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandInfoXriName</code> object, or null
	 *         if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppCommandInfoXriName cmd = null;
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("iname") )
			{
				String iname = EppUtil.getText(node);
				if( cmd == null )
				{
					cmd = new EppCommandInfoXriName(iname);
				}
				else
				{
					cmd.setIName(iname);
				}
			}
		}

		return cmd;
	}
}
