/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandLogout.java,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
package com.neulevel.epp.core.command;

import org.w3c.dom.*;
import com.neulevel.epp.core.*;

/**
 * This <code>EppCommandLogout</code> class implements EPP Command Logout
 * entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
public class EppCommandLogout extends EppCommand
{
	/**
	 * Creates an <code>EppCommandLogout</code> object
	 */
	public EppCommandLogout()
	{
	}

	/**
	 * Creates an <code>EppCommandLogout</code> object
	 *
	 * @param clientTransactionId client transaction id associated with
	 *                            the command
	 */
	public EppCommandLogout( String clientTransactionId )
	{
		this.setClientTransactionId(clientTransactionId);
	}

	/**
	 * Converts the <code>EppCommandLogout</code> object into an XML element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the <code>EppCommandLogout</code>
	 *            object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		return toXMLCommon(doc, tag, (EppEntity) null);
	}

	/**
	 * Converts an XML element into an <code>EppCommandLogout</code> object.
	 * The caller of this method must make sure that the root node is of an
	 * EPP Command Create entity.
	 *
	 * @param root root node for an <code>EppCommandLogout</code> object
	 *             in XML format
	 *
	 * @return an <code>EppCommandLogout</code> object, or null if the node
	 *         is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		return new EppCommandLogout();
	}

	public String toString()
	{
		return toString("logout");
	}
}
