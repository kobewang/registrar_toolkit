/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppHello.java,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
package com.neulevel.epp.core;

import org.w3c.dom.*;

/**
 * This <code>EppHello</code> class implements EPP Hello entity used in
 * the EPP Protocol initialization.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
public class EppHello extends EppEntity
{
	/**
	 * Creates an <code>EppHello</code> object
	 */
	public EppHello()
	{
	}

	/**
	 * Converts the <code>EppHello</code> object into an XML element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the <code>EppHello</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element epp = EppUtil.createElementNS(doc, "epp", null);
		Element body = doc.createElement(tag);
		epp.appendChild(body);
		return epp;
	}

	/**
	 * Converts an XML element into an <code>EppHello</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP addrType.
	 *
	 * @param root root node for an <code>EppHello</code> object in XML
	 *             format
	 *
	 * @return an <code>EppHello</code> object, or null if the node
	 *         is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("hello") )
			{
				return new EppHello();
			}
		}

		return null;
	}

	public String toString()
	{
		return toString("hello");
	}
}
