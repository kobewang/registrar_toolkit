/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandInfoXriNumber.java,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
package com.neulevel.epp.xri.command;

import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.command.*;

/**
 * This <code>EppCommandInfo</code> class implements EPP Command Info
 * entity for EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
public class EppCommandInfoXriNumber extends EppCommandInfo
{
	private String inumber;

	/**
	 * Creates an <code>EppCommandInfoXriNumber</code> object for
	 * querying an XRI i-number based on its i-number
	 */
	public EppCommandInfoXriNumber( String inumber )
	{
		this.inumber = inumber;
	}

	/**
	 * Creates an <code>EppCommandInfoXriNumber</code> object for
	 * querying an XRI i-number based on its i-number, given a client
	 * transaction id associated with the operation
	 */
	public EppCommandInfoXriNumber( String inumber, String xid )
	{
		this.inumber = inumber;
		this.clTRID = xid;
	}

	/**
	 * Gets the i-number of the XRI i-number object to be queried
	 */
	public String getINumber()
	{
		return this.inumber;
	}

	/**
	 * Sets the i-number of the XRI i-number object to be queried
	 */
	public void setINumber( String inumber )
	{
		this.inumber = inumber;
	}

	/**
	 * Converts the <code>EppCommandInfoXriNumber</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandInfoXriNumber</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = EppUtil.createElementNS(doc, "xriINU", tag);

		if( inumber != null )
		{
			elm = doc.createElement("inumber");
			elm.appendChild(doc.createTextNode(inumber));
			body.appendChild(elm);
		}

		return toXMLCommon(doc, tag, body);
	}

	/**
	 * Converts an XML element into an <code>EppCommandInfoXriNumber</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Info entity for EPP XriNumber object.
	 *
	 * @param root root node for an <code>EppCommandInfoXriNumber</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandInfoXriNumber</code> object, or null
	 *         if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppCommandInfoXriNumber cmd = null;
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("inumber") )
			{
				String inumber = EppUtil.getText(node);
				if( cmd == null )
				{
					cmd = new EppCommandInfoXriNumber(inumber);
				}
				else
				{
					cmd.setINumber(inumber);
				}
			}
		}

		return cmd;
	}
}
