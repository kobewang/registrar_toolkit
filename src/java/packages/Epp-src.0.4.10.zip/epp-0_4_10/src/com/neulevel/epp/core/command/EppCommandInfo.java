/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandInfo.java,v 1.4 2009/11/23 14:35:54 nseshadr Exp $
 */
package com.neulevel.epp.core.command;

import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.xri.command.*;

/**
 * This <code>EppCommandInfo</code> class implements EPP Command Info
 * entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.4 $ $Date: 2009/11/23 14:35:54 $
 */
abstract public class EppCommandInfo extends EppCommand
{
	/**
	 * Converts an XML element into an <code>EppCommandInfo</code> object.
	 * The caller of this method must make sure that the root node is of an
	 * EPP Command Info entity.
	 *
	 * @param root root node for an <code>EppCommandInfo</code> object
	 *             in XML format
	 *
	 * @return an <code>EppCommandInfo</code> object, or null if the node
	 *         is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		String command = root.getLocalName();
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String prefix = node.getPrefix();
			String name = node.getLocalName();
			if( (prefix == null) || (name == null) )
			{
				continue;
			}
			if( name.equals(command) )
			{
				if( prefix.equals("contact") )
				{
					return EppCommandInfoContact.fromXML(node);
				}
				else if( prefix.equals("domain") )
				{
					return EppCommandInfoDomain.fromXML(node);
				}
				else if( prefix.equals("host") )
				{
					return EppCommandInfoHost.fromXML(node);
				}
				else if( prefix.equals("svcsub") )
				{
					return EppCommandInfoSvcsub.fromXML(node);
				}
				else if( prefix.equals("xriAU") )
				{
					return EppCommandInfoXriAuthority.fromXML(node);
				}
				else if( prefix.equals("xriINU") )
				{
					return EppCommandInfoXriNumber.fromXML(node);
				}
				else if( prefix.equals("xriINA") )
				{
					return EppCommandInfoXriName.fromXML(node);
				}
				else if( prefix.equals("xriISV") )
				{
					return EppCommandInfoXriService.fromXML(node);
				}
				else if( prefix.equals("xriCS") )
				{
					return EppCommandInfoXriCodeString.fromXML(node);
				}
			}
		}

		return null;
	}

	public String toString()
	{
		return toString("info");
	}
}
