/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandTransfer.java,v 1.3 2006/03/01 01:35:38 wtan Exp $
 */
package com.neulevel.epp.core.command;

import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.xri.command.*;

/**
 * This <code>EppCommandTransfer</code> class implements EPP Command Transfer
 * entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.3 $ $Date: 2006/03/01 01:35:38 $
 */
abstract public class EppCommandTransfer extends EppCommand implements EppPollable
{
	/**
	 * Transfer operation type for approving a transfer request
	 */
	public static final String OPTYPE_APPROVE = "approve";
	/**
	 * Transfer operation type for canceling a transfer request
	 */
	public static final String OPTYPE_CANCEL = "cancel";
	/**
	 * Transfer operation type for querying the status of a transfer request
	 */
	public static final String OPTYPE_QUERY = "query";
	/**
	 * Transfer operation type for rejecting a transfer request
	 */
	public static final String OPTYPE_REJECT = "reject";
	/**
	 * Transfer operation type for requesting an object transfer
	 */
	public static final String OPTYPE_REQUEST = "request";

	/**
	 * The type of the transfer operation
	 */
	protected String      op;
	/**
	 * The authorization information associated with the transfer operation
	 */
	protected EppAuthInfo authInfo;

	/**
	 * Gets the authorization info for the transfer operation
	 */
	public EppAuthInfo getAuthInfo()
	{
		return this.authInfo;
	}

	/**
	 * Sets the authorization info for the transfer operation
	 */
	public void setAuthInfo( EppAuthInfo authInfo )
	{
		this.authInfo = authInfo;
	}

	/**
	 * Gets the operation related to the transfer.
	 */
	public String getOperation()
	{
		return this.op;
	}

	/**
	 * Sets the operation related to the transfer. Valid operations are:
	 * <UL>
	 * <LI>approve</LI>
	 * <LI>cancel</LI>
	 * <LI>query</LI>
	 * <LI>reject</LI>
	 * <LI>request</LI>
	 * </UL>
	 */
	public void setOperation( String operation )
	{
		this.op = operation;
	}

	/**
	 * Converts an XML element into an <code>EppCommandTransfer</code>
	 * object. The caller of this method must make sure that the root
	 * node is of an EPP Object transferType entity. This method is
	 * for the interface defined in <code>EppPollable</code>
	 *
	 * @param root root node for an <code>EppCommandTransfer</code> object
	 *             in XML format
	 *
	 * @return an <code>EppCommandTransfer</code> object, or null if the
	 *         node is invalid
	 */
	public static EppEntity fromXMLPoll( Node root )
	{
		EppCommandTransfer cmd = null;
		String prefix = root.getPrefix();
		if( prefix != null )
		{
			if( prefix.equals("contact") )
			{
				cmd = (EppCommandTransfer) EppCommandTransferContact.fromXML(root);
			}
			else if( prefix.equals("domain") )
			{
				cmd = (EppCommandTransfer) EppCommandTransferDomain.fromXML(root);
			}
			else if( prefix.equals("svcsub") )
			{
				cmd = (EppCommandTransfer) EppCommandTransferSvcsub.fromXML(root);
			}
			else if( prefix.equals("xriAU") )
			{
				cmd = (EppCommandTransfer) EppCommandTransferXriAuthority.fromXML(root);
			}
			else if( prefix.equals("xriINA") )
			{
				cmd = (EppCommandTransfer) EppCommandTransferXriName.fromXML(root);
			}
		}
		return cmd;
	}

	/**
	 * Converts an XML element into an <code>EppCommandTransfer</code>
	 * object. The caller of this method must make sure that the root
	 * node is of an EPP Command Transfer entity.
	 *
	 * @param root root node for an <code>EppCommandTransfer</code> object
	 *             in XML format
	 *
	 * @return an <code>EppCommandTransfer</code> object, or null if the
	 *         node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		String command = root.getLocalName();
		EppCommandTransfer cmd = null;

		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String prefix = node.getPrefix();
			String name = node.getLocalName();
			if( (prefix == null) || (name == null) )
			{
				continue;
			}
			if( name.equals(command) )
			{
				cmd = (EppCommandTransfer) fromXMLPoll(node);
				break;
			}
		}
			
		if( cmd != null )
		{
			cmd.setOperation(((Element) root).getAttribute("op"));
		}

		return cmd;
	}

	public String toString()
	{
		return toString("transfer");
	}
}
