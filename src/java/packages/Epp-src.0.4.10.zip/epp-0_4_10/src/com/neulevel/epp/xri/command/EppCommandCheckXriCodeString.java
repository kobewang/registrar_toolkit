/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 */
package com.neulevel.epp.xri.command;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.command.*;

public class EppCommandCheckXriCodeString extends EppCommandCheck {
	/**
	* Constructor to create an object of <code>EppCommandCheckXriCodeString</code>
	* @param
	* @return
	**/
	public EppCommandCheckXriCodeString() {
		this.codeString = new Vector();
		this.clTRID = null;
	}
	/**
	* Constructor to create object of <code>EppCommandCheckXriCodeString</code> with one argument.
	* @param xid String client transaction id.
	* @return
	**/
	public EppCommandCheckXriCodeString( String xid ) {
		this.codeString = new Vector();
		this.clTRID = xid;
	}
	/**
	* Method to retrive collection of code string user wants to check.
	* @param
	* @return Vector of String
	**/
	public Vector getCodeStringId() {
		return this.codeString;
	}
	/**
	* Method to retrive collection of code string user wants to check.
	* @param
	* @return Vector of String
	**/
	public Vector get() {
		return this.codeString;
	}
	/**
	* Method to add codeString to be checcked.
	* @param csId String codeString.
	* @return
	**/
	public void addCodeStringId( String csId ) {
		this.codeString.addElement(csId);
	}
	/**
	* Method to add codeString to be checcked.
	* @param csId String codeString.
	* @return
	**/
	public void add( String csId) {
		this.addCodeStringId(csId);
	}
	public Element toXML( Document doc, String tag ) {
		Element elm;
		Element body = EppUtil.createElementNS(doc, "xriCS", tag);
	
		if( codeString != null ) {
			for( int i = 0; i < codeString.size(); i++ ) {
				String authId = (String)codeString.elementAt(i);
				elm = doc.createElement("codeString");
				elm.appendChild(doc.createTextNode(authId));
				body.appendChild(elm);
			}
		}
		return toXMLCommon(doc, tag, body);
	}
	public static EppCommandCheckXriCodeString fromXML( Node root ) {
		EppCommandCheckXriCodeString cmd = new EppCommandCheckXriCodeString();
		NodeList list = root.getChildNodes();
		for(int i = 0;i<list.getLength();i++) {
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null ) {
				continue;
			}
			if( name.equals("codeString") || name.equals("xriCS:codeString") ) {
				String authId = EppUtil.getText(node);
				cmd.addCodeStringId(authId);
			}
		}
		return cmd;

	}
	private Vector codeString;
}
