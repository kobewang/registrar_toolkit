/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataCheckXriCodeString.java,v 1.1 2009/11/23 14:35:31 nseshadr Exp $
 */
package com.neulevel.epp.xri.response;

import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.response.*;

/**
 * This <code>EppResponseDataCheckXriCodeString</code> class implements EPP
 * Response Data entity for EPP Command Check of EPP XRI CodeString objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2009/11/23 14:35:31 $
 */
public class EppResponseDataCheckXriCodeString extends EppResponseDataCheck {
	public EppResponseDataCheckXriCodeString() {};
	public static EppResponseDataCheckXriCodeString fromXML( Node root ) {
		EppResponseDataCheckXriCodeString rsp = new EppResponseDataCheckXriCodeString();
		rsp.fromXMLCommon(root, "codeString");
		return rsp;
	}
	public Element toXML( Document doc, String tag ) {
		Element elm;
		Element body = doc.createElement(tag);
		Element data = EppUtil.createElementNS(doc, "xriCS", "chkData");
		body.appendChild(data);
		toXMLCommon(doc, data, "codeString");
		return body;
	}
};
