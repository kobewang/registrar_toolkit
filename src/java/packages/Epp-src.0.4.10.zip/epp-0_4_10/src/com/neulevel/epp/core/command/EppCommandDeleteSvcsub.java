/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandDeleteSvcsub.java,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
package com.neulevel.epp.core.command;

import org.w3c.dom.*;
import com.neulevel.epp.core.*;

/**
 * This <code>EppCommandDelete</code> class implements EPP Command Delete
 * entity for EPP Svcsub objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
public class EppCommandDeleteSvcsub extends EppCommandDelete
{
	private String id;
	private String userid;
	private EppAuthInfo authInfo;
	private String service;

	/**
	 * Creates an <code>EppCommandDeleteSvcsub</code> object for
	 * deleting a service subscription object based on its id
	 */
	public EppCommandDeleteSvcsub( String id )
	{
		this.id = id;
		this.userid = null;
		this.authInfo = null;
		this.service = null;
	}

	/**
	 * Creates an <code>EppCommandDeleteSvcsub</code> object for
	 * deleting a service subscription object based on its id, given a client
	 * transaction id associated with the operation
	 */
	public EppCommandDeleteSvcsub( String id, String xid )
	{
		this.id = id;
		this.clTRID = xid;
		this.userid = null;
		this.authInfo = null;
		this.service = null;
	}

	/**
	 * Gets the id of the service subscription object to be deleted
	 */
	public String getId()
	{
		return this.id;
	}

	/**
	 * Sets the id of the service subscription object to be deleted
	 */
	public void setId( String id )
	{
		this.id = id;
	}

	/**
	 * Gets the user id that can be used for authorization purpose
	 */
	public String getUserId()
	{
		return this.userid;
	}

	/**
	 * Sets the user id that can be used for authorization purpose
	 */
	public void setUserId( String userid )
	{
		this.userid = userid;
	}

	/**
	 * Gets the authorization info for the delete operation
	 */
	public EppAuthInfo getAuthInfo()
	{
		return this.authInfo;
	}

	/**
	 * Sets the authorization info for the delete operation
	 */
	public void setAuthInfo( EppAuthInfo authInfo )
	{
		this.authInfo = authInfo;
	}

	/**
	 * Gets the service name
	 */
	public String getService()
	{
		return this.service;
	}

	/**
	 * Sets the service name
	 */
	public void setService( String service )
	{
		this.service = service;
	}

	/**
	 * Converts the <code>EppCommandDeleteSvcsub</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandDeleteSvcsub</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = EppUtil.createElementNS(doc, "svcsub", tag);

		if( id != null )
		{
			elm = doc.createElement("id");
			elm.appendChild(doc.createTextNode(id));
			body.appendChild(elm);
		}
		if( service != null )
		{
			elm = doc.createElement("service");
			elm.appendChild(doc.createTextNode(service));
			body.appendChild(elm);
		}
		if( userid != null )
		{
			elm = doc.createElement("userid");
			elm.appendChild(doc.createTextNode(userid));
			body.appendChild(elm);
		}
		if( authInfo != null )
		{
			body.appendChild(authInfo.toXML(doc, "authInfo"));
		}

		return toXMLCommon(doc, tag, body);
	}

	/**
	 * Converts an XML element into an <code>EppCommandDeleteSvcsub</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Delete entity for EPP Svcsub object.
	 *
	 * @param root root node for an <code>EppCommandDeleteSvcsub</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandDeleteSvcsub</code> object, or null
	 *         if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppCommandDeleteSvcsub cmd = null;
		String userid = null;
		EppAuthInfo authInfo = null;
		String service = null;
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("id") )
			{
				String id = EppUtil.getText(node);
				cmd = new EppCommandDeleteSvcsub(id);
			}
			else if( name.equals("service") )
			{
				service = EppUtil.getText(node);
			}
			else if( name.equals("userid") )
			{
				userid = EppUtil.getText(node);
			}
			else if( name.equals("authInfo") )
			{
				authInfo = (EppAuthInfo) EppAuthInfo.fromXML(node);
			}
		}
		if( cmd != null )
		{
			cmd.setAuthInfo(authInfo);
			cmd.setUserId(userid);
			cmd.setService(service);
		}

		return cmd;
	}
}
