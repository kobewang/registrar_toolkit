/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppTestXriCommand.cpp,v 1.2 2009/11/23 14:44:26 nseshadr Exp $
 */
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.command.*;
import com.neulevel.epp.core.response.*;
import com.neulevel.epp.xri.*;
import com.neulevel.epp.xri.command.*;
import com.neulevel.epp.xri.response.*;
import org.w3c.dom.*;

public class EppTestXriCommand {
	public static void main(String argv[]) {
		EppParser parser = new EppParser();
	Node n;

//	EppXriTrustee trustee;
//	EppXriSocialData esd;
	EppXriContactData cd = new EppXriContactData();
	cd.setContactHandle("nav-admin-con");
	cd.setContactType(EppXriContactData.adminContact);

	EppXriAuthority auth = new EppXriAuthority("auth-id-dsdsa");
	auth.setIsEscrow(true);
	auth.setIsContact(true);
	auth.addContactHandle(cd);

	EppXriContactData cd1 = new EppXriContactData();
	cd1.setContactHandle("nav-billing-con");
	cd1.setContactType(EppXriContactData.billingContact);
	auth.addContactHandle(cd1);

	EppXriContactData cd2 = new EppXriContactData();
	cd2.setContactHandle("nav-tech-con");
	cd2.setContactType(EppXriContactData.techContact);
	auth.addContactHandle(cd2);

	EppXriContactData cd3 = new EppXriContactData();
	cd3.setContactHandle("nav-tech2-con");
	cd3.setContactType(EppXriContactData.techContact);
	auth.addContactHandle(cd3);

	EppXriContactData cd4 = new EppXriContactData();
	cd4.setContactHandle("nav-tech3-con");
	cd4.setContactType(EppXriContactData.techContact);
	auth.addContactHandle(cd4);

	EppXriContactData cd5 = new EppXriContactData();
	cd5.setContactHandle("nav-billing2-con");
	cd5.setContactType(EppXriContactData.billingContact);
	auth.addContactHandle(cd5);

	System.out.println(auth.toString());
	parser.parse(auth.toString());
	n = parser.getDocument().getElementsByTagName("xriAU:xriAU").item(0);
	if( n != null ) {
		EppXriAuthority _del = (EppXriAuthority)EppXriAuthority.fromXML(n);
		System.out.println(_del.toString());
	} else {
		System.out.println("We got root node as NULL");
	}
	EppCommandUpdateXriAuthority upAuth = new EppCommandUpdateXriAuthority("auth-nav-123","123");
	upAuth.addContact(cd);
	upAuth.removeContact(cd2);
	System.out.println(upAuth.toString());
	parser.parse(upAuth.toString());
	n = parser.getRootNode();
	if( n != null ) {
		EppCommandUpdateXriAuthority upA = (EppCommandUpdateXriAuthority) EppCommand.fromXML(n);
		System.out.println(upA.toString());
	} else {
		System.out.println("Root Node is null for EppCommandUpdateXriAuthority");
		if( parser.hasError() ) {
			System.out.println(parser.getErrorMessage());
		}
	}

	EppXriCodeString cs = new EppXriCodeString();
	EppStatus _lstat_ = new EppStatus("ok");
	cs.setParentIName("@mc*neustar");
	cs.setCodeString("@mc*neustar*campaign");
	cs.setRoid("test-IS-ON-9090");
	cs.setClid("cl-cur-date-time-123-sec");
	cs.setCrid("cr-cur-date-time-abc-text");
	cs.setCrdate("2005-05-03T22:00:00.0Z");
	cs.setUpdatedId("50-10000");
	cs.setUpdatedDate("2009-10-05T09:00:00.0Z");
	cs.setExpiryDate("2010-01-01T00:00:00.0Z");
	cs.setTransactionDate("2005-05-04T09:00:00.0Z");
	cs.setAuthId("AUTHORITY");
	cs.setUsedRUnits(45);
	cs.setTotalRUnits(100);
	cs.setUsedMCap(100);
	cs.setTotalMCap(100);
	cs.setResStartDate("2005-05-03T22:00:00.0Z");
	cs.setResEndDate("2010-01-01T00:00:00.0Z");
	cs.setStatus(_lstat_);

	EppXriCodeStringExt ext = new EppXriCodeStringExt();
	ext.addVas("UseServiceMark", "Y");
	ext.addVas("IPManagement", "Y");
	ext.addVas("Location", "Y");
	ext.addVas("UMD","Y");
	ext.addVas("InternationReach","Y");
	ext.addVas("FrooToEndUser","Y");

	cs.addValueAddedService(ext);
	EppAuthInfo ai = new EppAuthInfo("pw","notnow");
	ai.setType("pw");
	ai.setValue("guesswhat");
	cs.setAuthInfo(ai);

	EppXriResolutionPattern res = new EppXriResolutionPattern();
	res.setPatternId("every-day");
	cs.addResPattern(res);
	res.setPatternId("every-monday");
	res.setDayOfWeek("1");
	cs.addResPattern(res);

	System.out.println(cs.toString());

	System.out.println("*************************** Commands ***************************");
	EppCommandCheckXriCodeString ckCS = new EppCommandCheckXriCodeString();
	String cs_str;
	cs_str = "@mc*neustar*pepsi";
	ckCS.addCodeStringId(cs_str);
	cs_str = "@mc*neustar*coke";
	ckCS.addCodeStringId(cs_str);
	cs_str = "@mc*neustar*pepsi*mirinda";
	ckCS.addCodeStringId(cs_str);
	cs_str = "@mc*neustar*pepsi*sprint";
	ckCS.addCodeStringId(cs_str);
	System.out.println(ckCS.toString());

	EppCommandInfoXriCodeString inCS = new EppCommandInfoXriCodeString(cs_str,"yyuuyyuu");
//	inCS.setClientTransactionId("hhhhgghgh");
	System.out.println(inCS.toString());

	EppCommandUpdateXriCodeString upCS = new EppCommandUpdateXriCodeString("@mc*neustar*pepsi*sprint","neu-xx-level-one-two");
	EppStatus stat = new EppStatus("clientInGoodHolding");
	upCS.addNewStatus(stat);
	stat.setStatus("Ok");
	upCS.addNewStatus(stat);
	stat.setStatus("pendingDelete");
	upCS.addRemStatus(stat);
	stat.setStatus("clientHold");
	upCS.addRemStatus(stat);
	stat.setStatus("serverHold");
	upCS.addRemStatus(stat);
	upCS.addNewRecPattterns(res);
	res.setPatternId("every-day");
	res.setDayOfWeek("*");
	upCS.addRemRecPattern(res);
	upCS.setResolutionStartDate("2009-10-05T09:00:00.0Z", "delete");
	upCS.setResolutionEndDate("2019-10-05T09:00:00.0Z", "add");
	upCS.updateTotalRUnits(5000,"dec",10000);
	upCS.updateTotalRUnits(1000,"add",10000);
	upCS.updateTotalMCaps(1000,"add",10000);
	upCS.updateTotalMCaps(5000,"dec",10000);
	System.out.println(upCS.toString());
}
}
