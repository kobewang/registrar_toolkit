/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppLoginTest.java,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.command.*;
import com.neulevel.epp.core.response.*;

import org.w3c.dom.*;

/**
 * The <code>EppLoginTest</code> class tests functions of
 * <code>EppLoginTest</code> commands.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
public class EppLoginTest
{
	public static void main( String argv[] )
	{
		EppCreds creds = new EppCreds("username", "password");
		creds.setNewPassword("newpassword");

		EppServiceMenu menu = new EppServiceMenu();

		menu.addService("contact");
		menu.addService("domain");
		menu.addService("host");
		menu.addUnspec("obj1ext", "http://custom/obj1ext-1.0", "xml/obj1ext-1.0.xsd");

		EppCommandLogin login = new EppCommandLogin(menu);
		login.setClientTransactionId("ABC-DEF-12345");
		login.setCreds(creds);
		System.out.println(login);

		EppParser parser = new EppParser(login.toString());

		if( parser.hasError() )
		{
			System.out.println(parser.getResult());
			System.exit(1);
		}

		Node epp = parser.getRootNode();
		EppCommand cmd = (EppCommand) EppCommand.fromXML(epp);
		if( cmd == null )
		{
			System.out.println("Error in fromXML");
			System.exit(1);
		}
		System.out.println(cmd);
	}
}
