/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataRenew.java,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
package com.neulevel.epp.core.response;

import java.util.*;
import com.neulevel.epp.core.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;

/**
 * This <code>EppResponseDataRenew</code> class implements EPP
 * Response Data entity for EPP Command Renew on EPP objects.
 *
 * @since EPP-1.0
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
abstract public class EppResponseDataRenew extends EppResponseData
{
	/**
         * The new expiration date of the object after it is renewed
	 */
	protected Calendar exDate;

	/**
	 * Gets new expiration date of the object renewed
	 */
	public Calendar getDateExpired()
	{
		return this.exDate;
	}

	/**
	 * Sets expiration date of the domain renewed
	 */
	public void setDateExpired( Calendar exDate )
	{
		this.exDate = exDate;
	}
}
