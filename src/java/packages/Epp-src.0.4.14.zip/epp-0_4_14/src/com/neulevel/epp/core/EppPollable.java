/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppPollable.java,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
package com.neulevel.epp.core;

import org.w3c.dom.*;
import org.apache.xerces.dom.*;

/**
 * The <code>EppPollable</code> interface is designed for pollable
 * <code>EppEntity</code>, such as <code>EppCommandTransfer</code> objects,
 * that can be included as the data element in the response of an EPP Poll
 * command.
 *
 * <P><B>Warning</B>: This interface is no longer used. Just for compatiblity. It may be removed
 * in the future.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
public interface EppPollable
{
	/**
	 * Converts the <code>EppPollable</code> object into an XML element
	 * that can be included as the data element in the response of an
	 * EPP Poll command.
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the <code>EppEntity</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	abstract public Element toXMLPoll( Document doc, String tag );
}
