/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandInfoXriCodeString.java,v 1.2 2009/12/02 20:15:05 nseshadr Exp $
 */
package com.neulevel.epp.xri.command;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.command.*;


public class EppCommandInfoXriCodeString extends EppCommandInfo {
	/**
	* No argument constructor for constructing object of <code>EppCommandInfo</code>
	* @param
	* @return
	**/
	public EppCommandInfoXriCodeString() {
		this.codeString = null;
		clTRID   = null;
	}

	/**
	* Constructor with 2 arguments to construct object of <code>EppCommandInfoXriCodeString</code>
	* @param codeString String value representing codeString
	* @return
	**/
	public EppCommandInfoXriCodeString( String codeString) {
		this.codeString   = codeString;
		clTRID   = null;
	}

	/**
	* Constructor with 2 arguments to construct object of <code>EppCommandInfoXriCodeString</code>
	* @param codeString String value representing codeString
	* @param xid String value representing client transaction id.
	* @return
	**/
	public EppCommandInfoXriCodeString( String codeString, String xid ) {
		this.codeString   = codeString;
		clTRID   = xid;
	}

	/**
	* Method to retrive previously populated codeString.
	* @param
	* @return String representing codeString.
	**/
	public String getCodeString() {
		return this.codeString;
	}

	/**
	* Method to set codeString to be queried.
	* @param codeString String
	* @return
	**/
	public void setCodeString( String codeString ) {
		this.codeString = codeString;
	}
	public Element toXML( Document doc, String tag ) {
		Element elm;
		Element body = EppUtil.createElementNS(doc, "xriCS", tag);
		if( codeString  != null ) {
			elm = doc.createElement("codeString");
			elm.appendChild(doc.createTextNode(codeString));
			body.appendChild(elm);
		}
		return toXMLCommon(doc, tag, body);

	}
	public static EppCommandInfoXriCodeString fromXML( Node root ) {
		EppCommandInfoXriCodeString cmd = null;
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ ) {
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null ) {
				continue;
			}
			if( name.equals("codeString") || name.equals("xriCS:codeString") ) {
				String s = EppUtil.getText(node);
				if( (s != null) && (s.length() > 0) ) {
					if( cmd == null ) {
						cmd = new EppCommandInfoXriCodeString(s);
						if( cmd == null ) {
							return cmd;
						}
					} else {
						cmd.setCodeString(s);
					}
				}
			}
		}
		return cmd;
	}
	private String		codeString;
}
