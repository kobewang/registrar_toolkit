/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppExtension.java,v 1.9 2013/07/08 21:36:29 achowdhu Exp $
 */
package com.neulevel.epp.ext;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.ext.command.*;
import com.neulevel.epp.ext.response.*;

/**
 * This <code>EppExtension</code> class implements EPP Extension entity.
 * 
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.9 $ $Date: 2013/07/08 21:36:29 $
 */
abstract public class EppExtension extends EppEntity {
	/**
	 * Converts an XML element into an <code>EppExtension</code> object. The
	 * caller of this method must make sure that the root node is a child node
	 * of an EPP extension tag
	 * 
	 * @param root
	 *            root node for an <code>EppExtension</code> object in XML
	 *            format
	 * 
	 * @return an <code>EppEntity</code> object, or null if the node is invalid
	 */
	public static EppEntity fromXML(Node root) {
		if (root == null) {
			return null;
		}

		String prefix = root.getPrefix();
		String name = root.getLocalName();

		if ((prefix == null) || (name == null)) {
			return null;
		}

		EppExtension entity = null;

		if (prefix.equals("secDNS")) {
			if (name.equals("create")) {
				entity = (EppExtension) EppCommandCreateSecDns.fromXML(root);
				if (null != entity) {
					String maj_min[] = EppUtil.getDnsSecMajorMinor(root);
					if (null != maj_min) {
						entity.secDnsMajor = maj_min[0];
						entity.secDnsMinor = maj_min[1];
					}
				}
			} else if (name.equals("update")) {
				entity = (EppExtension) EppCommandUpdateSecDns.fromXML(root);
				if (null != entity) {
					String maj_min[] = EppUtil.getDnsSecMajorMinor(root);
					if (null != maj_min) {
						entity.secDnsMajor = maj_min[0];
						entity.secDnsMinor = maj_min[1];
					}
				}
			} else if (name.equals("infData")) {
				entity = (EppExtension) EppResponseDataInfoSecDns.fromXML(root);
				if (null != entity) {
					String maj_min[] = EppUtil.getDnsSecMajorMinor(root);
					if (null != maj_min) {
						entity.secDnsMajor = maj_min[0];
						entity.secDnsMinor = maj_min[1];
					}
				}
			}
		} else if (prefix.equals("launch")) {
			if (name.equals("create")) {
				entity = (EppExtension) EppCommandCreateLaunchRegistration
						.fromXML(root);
			} else if (name.equals("update")) {
				entity = (EppExtension) EppCommandUpdateLaunchRegistration
						.fromXML(root);
			} else if (name.equals("delete")) {
				entity = (EppExtension) EppCommandDeleteLaunchRegistration
						.fromXML(root);
			} else if (name.equals("info")) {
				entity = (EppExtension) EppCommandInfoLaunchRegistration
						.fromXML(root);
			} else if (name.equals("infData")) {
				entity = (EppExtension) EppResponseDataInfoLaunchRegistration
						.fromXML(root);
			} else if (name.equals("creData")) {
				entity = (EppExtension) EppResponseDataCreateLaunchRegistration
						.fromXML(root);
			} else if (name.equals("chkData")) {
				entity = (EppExtension) EppResponseDataCheckClaims
						.fromXML(root);
			}
		} else if (prefix.equals("idn")) {
			if (name.equals("data")) {
				entity = (EppExtension) EppIDNData.fromXML(root);
			}
		}
		return (EppEntity) entity;
	}

	protected String secDnsMajor = "1";
	protected String secDnsMinor = "1";
}
