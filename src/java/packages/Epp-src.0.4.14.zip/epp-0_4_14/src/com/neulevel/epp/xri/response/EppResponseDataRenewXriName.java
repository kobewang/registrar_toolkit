/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataRenewXriName.java,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
package com.neulevel.epp.xri.response;

import java.util.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.response.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;

/**
 * This <code>EppResponseDataRenewXriName</code> class implements EPP
 * Response Data entity for EPP Command Renew of EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
public class EppResponseDataRenewXriName extends EppResponseDataRenew
{
	private String   iname;

	/**
	 * Creates an <code>EppResponseDataRenewXriName</code> object
	 *
	 * @param iname the i-name of the XRI i-name object renewed
	 */
	public EppResponseDataRenewXriName( String iname )
	{
		this.iname  = iname;
		this.exDate = null;
	}

	/**
	 * Creates an <code>EppResponseDataRenewXriName</code> object
	 *
	 * @param iname  the i-name of the XRI i-name object renewed
	 * @param exDate the expiration date of the XRI i-name
	 *               object renewed
	 */
	public EppResponseDataRenewXriName( String iname, Calendar exDate )
	{
		this.iname  = iname;
		this.exDate = exDate;
	}

	/**
	 * Gets the i-name
	*/
	public String getIName()
	{
		return this.iname;
	}

	/**
	 * Sets the i-name
	 */
	public void setIName( String iname )
	{
		this.iname = iname;
	}

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataRenewXriName</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XRI I-Name object
	 *
	 * @param root root node for an <code>EppResponseDataRenewXriName</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataRenewXriName</code> object,
	 *         or null if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		String i_number = null;
		Calendar exDate = null;
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			else if( name.equals("iname") )
			{
				i_number = EppUtil.getText(node);
			}
			else if( name.equals("exDate") )
			{
				exDate = EppUtil.getDate(node);
			}
		}

		return new EppResponseDataRenewXriName(i_number, exDate);
	}

	/**
	 * Converts an <code>EppResponseDataRenewXriName</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataRenewXriName</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = doc.createElement(tag);
		ElementNSImpl data = EppUtil.createElementNS(doc, "xriINA", "renData");
		body.appendChild(data);

		if( iname != null )
		{
			elm = doc.createElement("iname");
			elm.appendChild(doc.createTextNode(iname));
			data.appendChild(elm);
		}
		if( exDate != null )
		{
			elm = doc.createElement("exDate");
			elm.appendChild(EppUtil.createTextNode(doc, exDate));
			data.appendChild(elm);
		}

		return body;
	}
}
