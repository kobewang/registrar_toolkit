package com.neulevel.epp.core;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.EppEntity;
import com.neulevel.epp.core.EppObject;
import com.neulevel.epp.core.EppUtil;

public class EppUnspecNVPairTuple 
{
  /**
  * No argument constructor for creating an object of <code>EppUnspecNVPairTuple</code>
  * @param
  * @return
  **/

		public EppUnspecNVPairTuple()
		{
			name = new String();
			value = new String();
		}

  /**
  * Two argument constructor for creating an object of <code>EppUnspecNVPairTuple</code>
  * @param nm : Name
	* @param v  : Value
  * @return
  **/
		public EppUnspecNVPairTuple(String nm , String v)
		{
			name = new String(nm);
			value = new String(v);
		}
	/**
 	* Method to get name part of the NV pair
 	* @param none
	*	@return name
	*/

		public String getName()
		{
			return name;
		}

	/**
 	* Method to get value part of the NV pair
 	* @param none
	*	@return value
	*/
		public String getValue()
		{
			return value;
		}
	/**
 	* Method to set name part of the NV pair
 	* @param String nm
	*	@return void
	*/
		public void setName(String nm)
		{
			name = new String(nm);
		}
	/**
 	* Method to set value part of the NV pair
 	* @param String v
	*	@return void
	*/
		public void setValue(String v)
		{
			value = new String(v);
		}
    private String name;
    private String value;
}
