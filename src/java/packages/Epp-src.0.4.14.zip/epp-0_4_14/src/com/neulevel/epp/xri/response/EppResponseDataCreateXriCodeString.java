/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataCreateXriCodeString.java,v 1.1 2009/11/23 14:35:33 nseshadr Exp $
 */
package com.neulevel.epp.xri.response;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.response.*;

/**
 * This <code>EppResponseDataCreateXriCodeString</code> class implements EPP
 * Response Data entity for EPP Command Create of EPP XRI CodeString objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2009/11/23 14:35:33 $
 */
public class EppResponseDataCreateXriCodeString extends EppResponseDataCreate {

	public EppResponseDataCreateXriCodeString() {
		this.codeString = null;
		this.crDate = Calendar.getInstance();
	}

	public EppResponseDataCreateXriCodeString( String codeString ) {
		this.codeString = codeString;
		this.crDate = Calendar.getInstance();
	}

	public EppResponseDataCreateXriCodeString( String codeString, Calendar crDate ) {
		this.codeString = codeString;
		this.crDate = crDate;
	}

	public void setCodeString( String codeString ) {
		this.codeString = codeString;
	}

	public String getCodeString() {
		return this.codeString;
	}

	public static EppResponseDataCreateXriCodeString fromXML( Node root ) {
		String auth_id = null;
		Calendar create_date = null;
		NodeList list = root.getChildNodes();
		for(int i=0;i<list.getLength();i++) {
			Node node = list.item(i);
			String name = node.getLocalName();
			if(name == null) {
				continue;
			}
			if(name.equals("codeString") || name.equals("xriCS:codeString")) {
				String id = EppUtil.getText(node);
				if( (id != null) && (id.length()>0)) {
					auth_id = id;
				}
			} else if(name.equals("crDate") || name.equals("xriCS:crDate")) {
				Calendar t = EppUtil.getDate(node);
				if(t != null) {
					create_date = t;
				}
			}
		}
		return new EppResponseDataCreateXriCodeString(auth_id,create_date);
	}

	public Element toXML( Document doc, String tag ) {
		Element elm;
		Element body = doc.createElement(tag);
		Element data = EppUtil.createElementNS(doc,"xriCS","creData");
		body.appendChild(data);
		if(codeString != null) {
			elm = doc.createElement("codeString");
			elm.appendChild(doc.createTextNode(codeString));
			data.appendChild(elm);
		}
		if(crDate != null ) {
			elm = doc.createElement("crDate");
			elm.appendChild(EppUtil.createTextNode(doc,crDate));
			data.appendChild(elm);
		}
		return body;

	}
	private String codeString;
}
