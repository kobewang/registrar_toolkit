/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppTransferTest.java,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.command.*;
import com.neulevel.epp.core.response.*;

import org.w3c.dom.*;

/**
 * The <code>EppTransferTest</code> class tests functions of
 * <code>EppCommandTransfer</code> commands.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
public class EppTransferTest
{
	public static void main( String argv[] )
	{
		testContact();
		testDomain();
		testSvcsub();
	}

	private static void testContact()
	{
		Node epp;
		EppCommandTransfer cmd;
		EppCommandTransfer newcmd;

		cmd = new EppCommandTransferContact("CONTACT-12345");
		cmd.setClientTransactionId("ABC-DEF-12345");
		cmd.setOperation("request");
		cmd.setAuthInfo(new EppAuthInfo("pw", "2fooBar", "CONTACT-12345"));
		System.out.println(cmd);

		EppParser parser = new EppParser(cmd.toString());
		if( parser.hasError() )
		{
			System.out.println(parser.getResult());
			System.exit(1);
		}

		epp = parser.getRootNode();
		newcmd = (EppCommandTransfer) EppCommand.fromXML(epp);
		if( newcmd == null )
		{
			System.out.println("Error in fromXML");
			System.exit(1);
		}
		System.out.println(newcmd);
	}

	private static void testDomain()
	{
		Node epp;
		EppCommandTransfer cmd;
		EppCommandTransfer newcmd;

		cmd = new EppCommandTransferDomain("example.biz", new EppPeriod(1, 'y'));
		cmd.setClientTransactionId("ABC-DEF-12345");
		cmd.setOperation("approve");
		cmd.setAuthInfo(new EppAuthInfo("pw", "2fooBar", "EXAMPLE-12345"));
		System.out.println(cmd);

		EppParser parser = new EppParser(cmd.toString());
		if( parser.hasError() )
		{
			System.out.println(parser.getResult());
			System.exit(1);
		}

		epp = parser.getRootNode();
		newcmd = (EppCommandTransfer) EppCommand.fromXML(epp);
		if( newcmd == null )
		{
			System.out.println("Error in fromXML");
			System.exit(1);
		}
		System.out.println(newcmd);
	}

	private static void testSvcsub()
	{
		Node epp;
		EppCommandTransferSvcsub cmd;
		EppCommandTransfer newcmd;

		cmd = new EppCommandTransferSvcsub("BIZLOCK-12345");
		cmd.setUserId("myUserId");
		cmd.setClientTransactionId("ABC-DEF-12345");
		cmd.setOperation("approve");
		cmd.setAuthInfo(new EppAuthInfo("pw", "2fooBar", "BIZLOCK-12345"));
		System.out.println(cmd);

		EppParser parser = new EppParser(cmd.toString());
		if( parser.hasError() )
		{
			System.out.println(parser.getResult());
			System.exit(1);
		}

		epp = parser.getRootNode();
		newcmd = (EppCommandTransfer) EppCommand.fromXML(epp);
		if( newcmd == null )
		{
			System.out.println("Error in fromXML");
			System.exit(1);
		}
		System.out.println(newcmd);
	}
}
