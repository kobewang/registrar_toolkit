/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandInfoContact.java,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
package com.neulevel.epp.core.command;

import org.w3c.dom.*;
import com.neulevel.epp.core.*;

/**
 * This <code>EppCommandInfoContact</code> class implements EPP Command Info
 * entity for EPP Contact objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
public class EppCommandInfoContact extends EppCommandInfo
{
	private String id;
	private EppAuthInfo authInfo;

	/**
	 * Creates an <code>EppCommandInfoContact</code> object for
	 * querying a contact object based on its id
	 */
	public EppCommandInfoContact( String id )
	{
		this.id = id;
		this.clTRID = null;
		this.authInfo = null;
	}

	/**
	 * Creates an <code>EppCommandInfoContact</code> object for
	 * querying a contact object based on its id, given a client
	 * transaction id assoicated with the operation
	 */
	public EppCommandInfoContact( String id, String xid )
	{
		this.id = id;
		this.clTRID = xid;
		this.authInfo = null;
	}

	/**
	 * Gets the id of the contact object to be queried
	 */
	public String getId()
	{
		return this.id;
	}

	/**
	 * Sets the id of the contact object to be queried
	 */
	public void setId( String id )
	{
		this.id = id;
	}

	/**
	 * Gets the optional authorization info for querying the contact object
	 */
	public EppAuthInfo getAuthInfo()
	{
		return this.authInfo;
	}

	/**
	 * Sets the optional authorization info for querying the contact object
	 */
	public void setAuthInfo( EppAuthInfo authInfo )
	{
		this.authInfo = authInfo;
	}

	/**
	 * Converts the <code>EppCommandInfoContact</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandInfoContact</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = EppUtil.createElementNS(doc, "contact", tag);

		if( id != null )
		{
			elm = doc.createElement("id");
			elm.appendChild(doc.createTextNode(id));
			body.appendChild(elm);
		}
		if( authInfo != null )
		{
			body.appendChild(authInfo.toXML(doc, "authInfo"));
		}

		return toXMLCommon(doc, tag, body);
	}

	/**
	 * Converts an XML element into an <code>EppCommandInfoContact</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Info entity for EPP contact object.
	 *
	 * @param root root node for an <code>EppCommandInfoContact</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandInfoContact</code> object, or null
	 *         if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppCommandInfoContact cmd = null;
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("id") )
			{
				String id = EppUtil.getText(node);
				if( (id != null) && (id.length() > 0) )
				{
					if( cmd == null )
					{
						cmd = new EppCommandInfoContact(id);
					}
					else
					{
						cmd.setId(id);
					}
				}
			}
			else if( name.equals("authInfo") )
			{
				if( cmd != null )
				{
					EppAuthInfo p;
					p = (EppAuthInfo) EppAuthInfo.fromXML(node);
					if( p != null )
					{
						cmd.setAuthInfo(p);
					}
				}
			}
		}

		return cmd;
	}
}
