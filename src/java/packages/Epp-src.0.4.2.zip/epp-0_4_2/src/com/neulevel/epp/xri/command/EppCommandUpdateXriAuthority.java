/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandUpdateXriAuthority.java,v 1.3 2006/03/01 01:35:38 wtan Exp $
 */
package com.neulevel.epp.xri.command;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.command.*;
import com.neulevel.epp.xri.*;

/**
 * This <code>EppCommandUpdateXriAuthority</code> class implements EPP Command Update
 * entity for EPP XRI Authority objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.3 $ $Date: 2006/03/01 01:35:38 $
 */
public class EppCommandUpdateXriAuthority extends EppCommandUpdate
{
	private String           authId;

	private Vector           trusteeAdded;
	private Vector           trusteeRemoved;

	private Vector           refAdded;
	private Vector           refRemoved;

	private Vector           sepAdded;
	private Vector           sepRemoved;

	private String           newAuthId;
	private EppXriSocialData newSocialData;
	private EppAuthInfo      newAuthInfo;

	private EppAuthInfo      authInfo;

	private boolean		 nullifySocialData;
	private EppXriSocialData addSocialData;

	/**
	 * Creates an <code>EppCommandUpdateXriAuthority</code> given the
	 * identifier of the XRI authority object
	 */
	public EppCommandUpdateXriAuthority( String authId )
	{
		this(authId, null);
	}

	/**
	 * Creates an <code>EppCommandUpdateXriAuthority</code> given the
	 * identifier of the XRI authority object and a client transaction id
	 */
	public EppCommandUpdateXriAuthority( String authId, String xid )
	{
		this.authId = authId;
		this.clTRID = xid;

		this.trusteeAdded   = new Vector();
		this.trusteeRemoved = new Vector();

		this.refAdded        = new Vector();
		this.refRemoved      = new Vector();

		this.sepAdded       = new Vector();
		this.sepRemoved     = new Vector();

		this.newAuthId      = null;
		this.newAuthInfo    = null;

		this.authInfo       = null;

		this.nullifySocialData = false;
	}

	/**
	 * Gets the identifier of the XRI authority object to be updated
	 */
	public String getAuthorityId()
	{
		return this.authId;
	}

	/**
	 * Sets the identifier of the XRI authority object to be updated
	 */
	public void setAuthorityId( String authId )
	{
		this.authId = authId;
	}

	/**
	 * Gets the list of trustees to be associated with the XRI
	 * authority object
	 */
	public Vector getTrusteeAdded()
	{
		return this.trusteeAdded;
	}

	/**
	 * Adds a trustee to the list of trustees to be associated with
	 * the XRI authority object
	 */
	public void addTrustee( EppXriTrustee trustee )
	{
		this.trusteeAdded.addElement(trustee);
	}

	/**
	 * Gets the list of trustees to be removed from the XRI
	 * authority object
	 */
	public Vector getTrusteeRemoved()
	{
		return this.trusteeRemoved;
	}

	/**
	 * Adds a trustee to the list of trustees to be removed from
	 * the XRI authority object
	 */
	public void removeTrustee( EppXriTrustee trustee )
	{
		this.trusteeRemoved.addElement(trustee);
	}

	/**
	 * Gets the list of refs to be associated with
	 * the XRI authority object
	 */
	public Vector getRefAdded()
	{
		return this.refAdded;
	}

	/**
	 * Adds a ref to the list of refs to
	 * be associated with the XRI authority object
	 */
	public void addRef( String ref )
	{
		EppXriRef exr = new EppXriRef(ref);
		this.refAdded.addElement(exr);
	}

	/**
	 * Adds a ref to the list of refs to
	 * be associated with the XRI authority object
	 */
	public void addRef( EppXriRef ref )
	{
		this.refAdded.addElement(ref);
	}

	/**
	 * Gets the list of refs to be removed from the XRI
	 * authority object
	 */
	public Vector getRefRemoved()
	{
		return this.refRemoved;
	}

	/**
	 * Adds a ref to the list of refs to
	 * be removed from the XRI authority object
	 */
	public void removeRef( String ref )
	{
		this.refRemoved.addElement(ref);
	}

	/**
	 * Gets the list of service endpoints to be associated with the XRI authority
	 * object
	 */
	public Vector getServiceEndpointAdded()
	{
		return this.sepAdded;
	}

	/**
	 * Adds an service endpoint to the list of service endpoints to be associated with the XRI
	 * authority object
	 */
	public void addServiceEndpoint( EppXriServiceEndpoint sep )
	{
		this.sepAdded.addElement(sep);
	}

	/**
	 * Gets the list of identifiers of service endpoints to be removed from the
	 * XRI authority object
	 */
	public Vector getServiceEndpointRemoved()
	{
		return this.sepRemoved;
	}

	/**
	 * Adds the identifier of an service endpoint to the list of identifiers of
	 * service endpoints to be removed from the XRI authority object
	 */
	public void removeServiceEndpoint( String id )
	{
		this.sepRemoved.addElement(id);
	}

	/*
	 * Gets the new identifier for the XRI authority object, or null if
	 * the identifier of the XRI authority object is not to be changed
	 */
	public String getNewAuthorityId()
	{
		return this.newAuthId;
	}

	/**
	 * Sets the new identifier for the XRI authority object if it needs
	 * to be changed
	 */
	public void setNewAuthorityId( String newAuthId )
	{
		this.newAuthId = newAuthId;
	}

	/**
	 * Gets the new/updated social data associated with the XRI authority object
	 */
	public EppXriSocialData getNewSocialData()
	{
		return this.newSocialData;
	}

	/**
	 * Sets the new/updated social data associated with the XRI authority object
	 */
	public void setNewSocialData( EppXriSocialData newSocialData )
	{
		this.newSocialData = newSocialData;
		this.addSocialData = null;
		this.nullifySocialData = false;
	}

	/**
	 * Gets the social data to be associated with the XRI authority object
	 */
	public EppXriSocialData getSocialData()
	{
		return this.addSocialData;
	}

	/**
	 * Sets the social data to be associated with the XRI authority object
	 */
	public void setSocialData( EppXriSocialData addSocialData )
	{
		this.addSocialData = addSocialData;
		this.newSocialData = null;
		this.nullifySocialData = false;
	}

	/*
	 * Gets the flag for nullifying existing social data associated 
	 * with the XRI authority object
	 */
	public boolean isSocialDataNullified()
	{
		return this.nullifySocialData;
	}
	
	/**
	 * Sets the flag for nullifying existing social data associated 
	 * with the XRI authority object
	 */
	public void nullifySocialData()
	{
		this.nullifySocialData = true;
		this.addSocialData = null;
		this.newSocialData = null;
	}

	/*
	 * Gets the new authorization information for the XRI authority object, or null if
	 * the authorization information of the XRI authority object is not to be changed
	 */
	public EppAuthInfo getNewAuthInfo()
	{
		return this.newAuthInfo;
	}

	/**
	 * Sets the new authorization information for the XRI authority object if it needs
	 * to be changed
	 */
	public void setNewAuthInfo( EppAuthInfo authInfo )
	{
		this.newAuthInfo = authInfo;
	}

	/**
	 * Gets the authorization info for the update operation
	 */
	public EppAuthInfo getAuthInfo()
	{
		return this.authInfo;
	}

	/**
	 * Sets the authorization info for the update operation
	 */
	public void setAuthInfo( EppAuthInfo authInfo )
	{
		this.authInfo = authInfo;
	}

	/**
	 * Converts the <code>EppCommandUpdateXriAuthority</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the 
	 *            <code>EppCommandUpdateXriAuthority</code> object
	 *
	 * @return an <code>Element</code> object 
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = EppUtil.createElementNS(doc, "xriAU", tag);

		if( authId != null )
		{
			elm = doc.createElement("authId");
			elm.appendChild(doc.createTextNode(authId));
			body.appendChild(elm);
		}
		if(    (statusAdded.size()  > 0)
		    || (trusteeAdded.size() > 0)
		    || (refAdded.size()      > 0)
		    || (sepAdded.size()     > 0)
		    || (addSocialData != null) )
		{
			elm = doc.createElement("add");
			if( addSocialData != null )
			{
				elm.appendChild(addSocialData.toXML(doc, "socialData"));
			}
			trusteeToXML(doc, elm, trusteeAdded);
			refToXML     (doc, elm, refAdded);
			sepToXML    (doc, elm, sepAdded);
			statusToXML (doc, elm, statusAdded);
			body.appendChild(elm);
		}
		if(    (statusRemoved.size()  > 0)
		    || (trusteeRemoved.size() > 0)
		    || (refRemoved.size()      > 0)
		    || (sepRemoved.size()     > 0)
		    || (nullifySocialData == true) )
		{
			elm = doc.createElement("rem");
			if( nullifySocialData == true )
			{
				elm.appendChild(doc.createElement("socialData"));
			}
			trusteeToXML(doc, elm, trusteeRemoved);
			stringToXML (doc, elm, refRemoved , "ref" , null);
			stringToXML (doc, elm, sepRemoved, "sep", "id");
			statusToXML (doc, elm, statusRemoved);
			body.appendChild(elm);
		}
		if( (newAuthId != null) || (newSocialData != null) || (newAuthInfo != null) )
		{
			elm = doc.createElement("chg");
			if( newAuthId != null )
			{
				Element authId = doc.createElement("authId");
				authId.appendChild(doc.createTextNode(newAuthId));
				elm.appendChild(authId);
			}
			if( newSocialData != null )
			{
				elm.appendChild(newSocialData.toXML(doc, "socialData"));
			}
			if( newAuthInfo != null )
			{
				elm.appendChild(newAuthInfo.toXML(doc, "authInfo"));
			}
			body.appendChild(elm);
		}
		if( authInfo != null )
		{
			body.appendChild(authInfo.toXML(doc, "authInfo"));
		}

		return toXMLCommon(doc, tag, body);
	}

	/**
	 * Converts an XML element into an <code>EppCommandUpdateAuthority</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Update entity for an EPP XRI Authority object.
	 *
	 * @param root root node for an <code>EppCommandUpdateAuthority</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandUpdateAuthority</code> object, or null
	 *         if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppCommandUpdateXriAuthority cmd = null;
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("authId") )
			{
				String authId = EppUtil.getText(node);
				if( cmd == null )
				{
					cmd = new EppCommandUpdateXriAuthority(authId);
				}
				else
				{
					cmd.setAuthorityId(authId);
				}
			}
			else if( name.equals("add") )
			{
				if( cmd != null )
				{
					cmd.socialDataFromXML(node, true);
					cmd.trusteeFromXML(node, cmd.trusteeAdded);
					cmd.refFromXML     (node, cmd.refAdded);
					cmd.sepFromXML    (node, cmd.sepAdded);
					cmd.statusFromXML (node, cmd.statusAdded);
				}
			}
			else if( name.equals("rem") )
			{
				if( cmd != null )
				{
					cmd.socialDataFromXML(node, false);
					cmd.trusteeFromXML(node, cmd.trusteeRemoved);
					cmd.stringFromXML (node, cmd.refRemoved    , "ref" ,  null);
					cmd.stringFromXML (node, cmd.sepRemoved   , "sep", "id");
					cmd.statusFromXML (node, cmd.statusRemoved);
				}
			}
			else if( name.equals("chg") )
			{
				if( cmd != null )
				{
					cmd.addNewStuff(node);
				}
			}
			else if( name.equals("authInfo") )
			{
				if( cmd != null )
				{
					EppAuthInfo authInfo = (EppAuthInfo) EppAuthInfo.fromXML(node);
					if( authInfo != null )
					{
						cmd.setAuthInfo(authInfo);
					}
				}
			}
		}

		return cmd;
	}

	/**
	 * Adds elements included in the &lt;chg&gt tag of the update command
	 * for an XRI authority object
	 *
	 * @param root the root <code>Node</code> of the &lt;chg&gt; tag
	 */
	private void addNewStuff( Node root )
	{
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("authId") )
			{
				String authId = EppUtil.getText(node);
				setNewAuthorityId(authId);
			}
			else if( name.equals("socialData") )
			{
				EppXriSocialData socialData = (EppXriSocialData) EppXriSocialData.fromXML(node);
				setNewSocialData(socialData);
			}
			else if( name.equals("authInfo") )
			{
				EppAuthInfo authInfo = (EppAuthInfo) EppAuthInfo.fromXML(node);
				setNewAuthInfo(authInfo);
			}
		}
	}

	/**
	 * Converts a list of EPP XRI trustee objects into XML
	 *
	 * @param doc  the XML <code>Document</code> object
	 * @param body the XML <code>Element</code> object to which the list
	 *             of EPP XRI trustee objects is appended
	 * @param list the list of EPP XRI trustee objects to be converted
	 */
	private void trusteeToXML( Document doc, Element body, Vector list )
	{
		Element elm;
		if( list != null )
		{
			for( int i = 0; i < list.size(); i++ )
			{
				Object obj = list.elementAt(i);
				if( obj instanceof EppXriTrustee )
				{
					EppXriTrustee trustee = (EppXriTrustee) obj;
					elm = trustee.toXML(doc, "trustee");
					body.appendChild(elm);
				}
			}
		}
	}

	/**
	 * Converts a list of EPP XRI Trustee objects from XML
	 *
	 * @param root the XML <code>Node</code> object containing the list
	 *             of EPP XRI Trustee objects
	 * @param trusteeList the list of EPP XRI Trustee objects to be stored
	 */
	private void trusteeFromXML( Node root, Vector trusteeList )
	{
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("trustee") )
			{
				EppXriTrustee trustee = (EppXriTrustee) EppXriTrustee.fromXML(node);
				trusteeList.addElement(trustee);
			}
		}
	}

	/**
	 * Converts a list of EPP XRI Ref objects into XML
	 *
	 * @param doc  the XML <code>Document</code> object
	 * @param body the XML <code>Element</code> object to which the list
	 *             of EPP XRI Ref objects is appended
	 * @param list the list of EPP XRI Ref objects to be converted
	 */
	private void refToXML( Document doc, Element body, Vector list )
	{
		Element elm;
		if( list != null )
		{
			for( int i = 0; i < list.size(); i++ )
			{
				Object obj = list.elementAt(i);
				if( obj instanceof EppXriRef )
				{
					EppXriRef ref = (EppXriRef) obj;
					elm = ref.toXML(doc, "ref");
					body.appendChild(elm);
				}
			}
		}
	}

	/**
	 * Converts a list of EPP XRI Ref objects from XML
	 *
	 * @param root the XML <code>Node</code> object containing the list
	 *             of EPP XRI Ref objects
	 * @param refList the list of EPP XRI Ref objects to be stored
	 */
	private void refFromXML( Node root, Vector refList )
	{
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("ref") )
			{
				EppXriRef ref = (EppXriRef) EppXriRef.fromXML(node);
				refList.addElement(ref);
			}
		}
	}

	/**
	 * Converts a list of EPP XRI service endpoint objects into XML
	 *
	 * @param doc  the XML <code>Document</code> object
	 * @param body the XML <code>Element</code> object to which the list
	 *             of EPP XRI service endpoint objects is appended
	 * @param list the list of EPP XRI service endpoint objects to be converted
	 */
	private void sepToXML( Document doc, Element body, Vector list )
	{
		Element elm;
		if( list != null )
		{
			for( int i = 0; i < list.size(); i++ )
			{
				Object obj = list.elementAt(i);
				if( obj instanceof EppXriServiceEndpoint )
				{
					EppXriServiceEndpoint sep = (EppXriServiceEndpoint) obj;
					elm = sep.toXML(doc, "sep");
					body.appendChild(elm);
				}
			}
		}
	}

	/**
	 * Converts a list of EPP XRI service endpoint objects from XML
	 *
	 * @param root the XML <code>Node</code> object containing the list
	 *             of EPP XRI service endpoint objects
	 * @param sepList the list of EPP XRI service endpoint objects to be stored
	 */
	private void sepFromXML( Node root, Vector sepList )
	{
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("sep") )
			{
				EppXriServiceEndpoint sep = (EppXriServiceEndpoint) EppXriServiceEndpoint.fromXML(node);
				sepList.addElement(sep);
			}
		}
	}

	/**
	 * Converts a list of string objects into XML
	 *
	 * @param doc  the XML <code>Document</code> object
	 * @param body the XML <code>Element</code> object to which the list
	 *             of string objects is appended
	 * @param tag  the XML tag name for each string object
	 * @param child  the XML tag name for each string object, if it is a child element; or null
	 * @param list the list of string objects to be converted
	 */
	private void stringToXML( Document doc, Element body, Vector list, String tag, String child )
	{
		Element elm;
		if( list != null )
		{
			for( int i = 0; i < list.size(); i++ )
			{
				Object obj = list.elementAt(i);
				if( obj instanceof String )
				{
					elm = doc.createElement(tag);
					if( child == null )
					{
						elm.appendChild(doc.createTextNode((String) obj));
					}
					else
					{
						Element celm = doc.createElement(child);
						celm.appendChild(doc.createTextNode((String) obj));
						elm.appendChild(celm);
					}
					body.appendChild(elm);
				}
			}
		}
	}

	/**
	 * Converts a list of string objects from XML
	 *
	 * @param root the XML <code>Node</code> object containing the list
	 *             of string objects
	 * @param stringList the list of string objects to be stored
	 * @param tag  the XML tag name for each string object
	 * @param child  the XML tag name for each string object, if it is a child element; or null
	 */
	private void stringFromXML( Node root, Vector stringList, String tag, String child )
	{
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals(tag) )
			{
				if( child == null )
				{
					String s = EppUtil.getText(node);
					stringList.addElement(s);
				}
				else
				{
					NodeList clist = node.getChildNodes();
					for( int j = 0; j < clist.getLength(); j++ )
					{
						Node cnode = clist.item(j);
						String cname = cnode.getLocalName();
						if( cname == null )
						{
							continue;
						}
						if( cname.equals(child) )
						{
							String s = EppUtil.getText(cnode);
							stringList.addElement(s);
							break;
						}
					}
				}
			}
		}
	}

	/**
	 * Converts social data added to/removed from EPP XRI Authoruty objects from XML
	 *
	 * @param root the XML <code>Node</code> object containing the list
	 *             of EPP XRI Trustee objects
	 * @param addOrRemove the flag indicating if the social data is to be added or removed
	 */
	private void socialDataFromXML( Node root, boolean addOrRemove )
	{
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("socialData") )
			{
				if( addOrRemove == true )
				{
					EppXriSocialData data = (EppXriSocialData) EppXriSocialData.fromXML(node);
					this.setSocialData(data);
				}
				else
				{
					this.nullifySocialData();
				}
				break;
			}
		}
	}
}
