/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataCheckXriName.java,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
package com.neulevel.epp.xri.response;

import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.response.*;

/**
 * This <code>EppResponseDataCheckXriName</code> class implements EPP
 * Response Data entity for EPP Command Check of EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
public class EppResponseDataCheckXriName extends EppResponseDataCheck
{
	/**
	 * Checks an <code>EppResponseDataCheckXriName</code> object
	 */
	public EppResponseDataCheckXriName()
	{
	}

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCheckXriName</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for checking EPP XRI I-Name objects.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCheckXriName</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCheckXriName</code> object, or null
	 *         if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppResponseDataCheckXriName rsp = new EppResponseDataCheckXriName();
		rsp.fromXMLCommon(root, "iname");
		return rsp;
	}

	/**
	 * Converts an <code>EppResponseDataCheckXriName</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCheckXriName</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = doc.createElement(tag);
		Element data = EppUtil.createElementNS(doc, "xriINA", "chkData");
		body.appendChild(data);
		toXMLCommon(doc, data, "iname");

		return body;
	}
}
