/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppGreetingTest.java,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.command.*;
import com.neulevel.epp.core.response.*;

import org.w3c.dom.*;

/**
 * The <code>EppGreetingTest</code> class tests functions
 * of <code>EppGreeting</code> commands.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
public class EppGreetingTest
{
	public static void main( String argv[] )
	{
		System.out.println(new EppGreeting());

		EppServiceMenu menu = new EppServiceMenu();

		menu.addVersion("1.0");
		menu.addLanguage("en-US");
		menu.addService("contact");
		menu.addService("domain");
		menu.addService("host");
		menu.addService("svcsub");
		menu.addUnspec("obj1ext", "http://custom/obj1ext-1.0", "xml/obj1ext-1.0.xsd");

		EppGreeting greeting = new EppGreeting("NeuStar EPP TestServer", menu);
		System.out.println(greeting);

		EppParser parser = new EppParser(greeting.toString());
		if( parser.hasError() )
		{
			System.out.println(parser.getResult());
			System.exit(1);
		}

		Node epp = parser.getRootNode();
		EppGreeting cmd = (EppGreeting) EppGreeting.fromXML(epp);
		if( cmd == null )
		{
			System.out.println("Error in fromXML");
			System.exit(1);
		}
		System.out.println(cmd);
	}
}
