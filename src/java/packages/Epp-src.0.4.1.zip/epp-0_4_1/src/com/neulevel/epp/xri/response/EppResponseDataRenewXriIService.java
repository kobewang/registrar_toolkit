/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.xri.response;

import java.util.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.response.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;

/**
 * This <code>EppResponseDataRenewXriIService</code> class implements EPP
 * Response Data entity for EPP Command Renew of EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class EppResponseDataRenewXriIService extends EppResponseDataRenew
{
	private String   id;

	/**
	 * Creates an <code>EppResponseDataRenewXriIService</code> object
	 *
	 * @param id the identifier of the XRI i-service object renewed
	 */
	public EppResponseDataRenewXriIService( String id )
	{
		this.id = id;
		this.exDate = null;
	}

	/**
	 * Creates an <code>EppResponseDataRenewXriIService</code> object
	 *
	 * @param id the identifier of the XRI i-service object renewed
	 * @param exDate the expiration date of the XRI i-service
	 *               object renewed
	 */
	public EppResponseDataRenewXriIService( String id, Calendar exDate )
	{
		this.id = id;
		this.exDate = exDate;
	}

	/**
	 * Gets the identifier of the XRI i-service object
	*/
	public String getId()
	{
		return this.id;
	}

	/**
	 * Sets the identifier of the XRI i-service object
	 */
	public void setId( String id )
	{
		this.id = id;
	}

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataRenewXriIService</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XRI I-Service object
	 *
	 * @param root root node for an <code>EppResponseDataRenewXriIService</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataRenewXriIService</code> object,
	 *         or null if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		String i_service = null;
		Calendar exDate = null;
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			else if( name.equals("id") )
			{
				i_service = EppUtil.getText(node);
			}
			else if( name.equals("exDate") )
			{
				exDate = EppUtil.getDate(node);
			}
		}

		return new EppResponseDataRenewXriIService(i_service, exDate);
	}

	/**
	 * Converts an <code>EppResponseDataRenewXriIService</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataRenewXriIService</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = doc.createElement(tag);
		ElementNSImpl data = EppUtil.createElementNS(doc, "xriISV", "renData");
		body.appendChild(data);

		if( id != null )
		{
			elm = doc.createElement("id");
			elm.appendChild(doc.createTextNode(id));
			data.appendChild(elm);
		}
		if( exDate != null )
		{
			elm = doc.createElement("exDate");
			elm.appendChild(EppUtil.createTextNode(doc, exDate));
			data.appendChild(elm);
		}

		return body;
	}
}
