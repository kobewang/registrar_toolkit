/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.xri;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.EppEntity;
import com.neulevel.epp.core.EppObject;
import com.neulevel.epp.core.EppE164;
import com.neulevel.epp.core.EppStatus;
import com.neulevel.epp.core.EppAuthInfo;
import com.neulevel.epp.core.EppContactData;
import com.neulevel.epp.core.EppUtil;
import com.neulevel.epp.xri.command.*;

/**
 * This <code>EppXriAuthority</code> class implements EPP XRI Authority objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class EppXriAuthority extends EppObject
{
	/**
	 * Authority status - clientAssociateProhibited
	 */
	public static final String STATUS_CLIENT_ASSOCIATE_PROHIBITED = "clientAssociateProhibited";
	/**
	 * Authority status - clientDeleteProhibited
	 */
	public static final String STATUS_CLIENT_DELETE_PROHIBITED = "clientDeleteProhibited";
	/**
	 * Authority status - clientHold
	 */
	public static final String STATUS_CLIENT_HOLD = "clientHold";
	/**
	 * Authority status - clientTransferProhibited
	 */
	public static final String STATUS_CLIENT_TRANSFER_PROHIBITED = "clientTransferProhibited";
	/**
	 * Authority status - clientUpdateProhibited
	 */
	public static final String STATUS_CLIENT_UPDATE_PROHIBITED = "clientUpdateProhibited";
	/**
	 * Authority status - linked
	 */
	public static final String STATUS_LINKED = "linked";
	/**
	 * Authority status - ok
	 */
	public static final String STATUS_OK = "ok";
	/**
	 * Authority status - pendingCreate
	 */
	public static final String STATUS_PENDING_CREATE = "pendingCreate";
	/**
	 * Authority status - pendingDelete
	 */
	public static final String STATUS_PENDING_DELETE = "pendingDelete";
	/**
	 * Authority status - pendingINameTransfer
	 */
	public static final String STATUS_PENDING_INAME_TRANSFER = "pendingINameTransfer";
	/**
	 * Authority status - pendingTransfer
	 */
	public static final String STATUS_PENDING_TRANSFER = "pendingTransfer";
	/**
	 * Authority status - pendingUpdate
	 */
	public static final String STATUS_PENDING_UPDATE = "pendingUpdate";
	/**
	 * Authority status - serverAssociateProhibited
	 */
	public static final String STATUS_SERVER_ASSOCIATE_PROHIBITED = "serverAssociateProhibited";
	/**
	 * Authority status - serverDeleteProhibited
	 */
	public static final String STATUS_SERVER_DELETE_PROHIBITED = "serverDeleteProhibited";
	/**
	 * Authority status - serverHold
	 */
	public static final String STATUS_SERVER_HOLD = "serverHold";
	/**
	 * Authority status - serverTransferProhibited
	 */
	public static final String STATUS_SERVER_TRANSFER_PROHIBITED = "serverTransferProhibited";
	/**
	 * Authority status - serverUpdateProhibited
	 */
	public static final String STATUS_SERVER_UPDATE_PROHIBITED = "serverUpdateProhibited";

	private String           authId;
	private EppXriSocialData socialData;
	private Vector           trustee;
	private Vector           xs;
	private Vector           sep;
	private Vector           iname;
	private Vector           inumber;
	private Vector           iservice;

	/**
	 * Creates an <code>EppXriAuthority</code> object
	 */
	public EppXriAuthority()
	{
		this.authId     = null;
		this.socialData = null;
		this.trustee    = new Vector();
		this.xs         = new Vector();
		this.sep        = new Vector();
		this.iname      = new Vector();
		this.inumber    = new Vector();
		this.iservice   = new Vector();
	}

	/**
	 * Creates an <code>EppXriAuthority</code> object with an XRI authority identifier
	 */
	public EppXriAuthority( String authId )
	{
		this();
		this.authId = authId;
	}

	/**
	 * Gets the XRI authority identifier
	 */
	public String getAuthorityId()
	{
		return this.authId;
	}

	/**
	 * Sets the XRI authority identifier
	 */
	public void setAuthorityId( String authId )
	{
		this.authId = authId;
	}

	/**
	 * Gets the social data associated with the XRI authority object
	 */
	public EppXriSocialData getSocialData()
	{
		return this.socialData;
	}

	/**
	 * Gets the social data associated with the XRI authority object
	 */
	public void setSocialData( EppXriSocialData socialData )
	{
		this.socialData = socialData;
	}

	/**
	 * Gets a list of trustees associated with the XRI authority object
	 */
	public Vector getTrustee()
	{
		return this.trustee;
	}

	/**
	 * Adds a trustee associated with the XRI authority object
	 *
	 * <P><B>Note:</B> This method should be only called by the EPP server, and
	 *       an EPP client should not perform this operation.
	 */
	public void addTrustee( EppXriTrustee trustee )
	{
		this.trustee.addElement(trustee);
	}

	/**
	 * Gets a list of external synonyms (XS) associated with the XRI authority object
	 */
	public Vector getExternalSynonym()
	{
		return this.xs;
	}

	/**
	 * Adds an external synonym (XS) associated with the XRI authority object
	 *
	 * <P><B>Note:</B> This method should be only called by the EPP server, and
	 *       an EPP client should not perform this operation.
	 */
	public void addExternalSynonym( EppXriExternalSynonym xs )
	{
		this.xs.addElement(xs);
	}

	/**
	 * Gets a list of XRI service endpoint (SEP) associated with the XRI authority object
	 */
	public Vector getServiceEndpoint()
	{
		return this.sep;
	}

	/**
	 * Adds a XRI service service endpoint (SEP) associated with the XRI authority object
	 *
	 * <P><B>Note:</B> This method should be only called by the EPP server, and
	 *       an EPP client should not perform this operation.
	 */
	public void addServiceEndpoint( EppXriServiceEndpoint sep )
	{
		this.sep.addElement(sep);
	}

	/**
	 * Gets a list of i-names associated with the XRI authority object
	 *
	 * <P><B>Note:</B> This method should be only called by the EPP server, and
	 *       an EPP client should not perform this operation.
	 */
	public Vector getIName()
	{
		return this.iname;
	}

	/**
	 * Adds an i-name associated with the XRI authority object
	 *
	 * <P><B>Note:</B> This method should be only called by the EPP server, and
	 *       an EPP client should not perform this operation.
	 */
	public void addIName( String iname )
	{
		this.iname.addElement(iname);
	}

	/**
	 * Gets a list of i-numbers associated with the XRI authority object
	 */
	public Vector getINumber()
	{
		return this.inumber;
	}

	/**
	 * Adds an i-number associated with the XRI authority object
	 *
	 * <P><B>Note:</B> This method should be only called by the EPP server, and
	 *       an EPP client should not perform this operation.
	 */
	public void addINumber( String inumber )
	{
		EppXriINumberAttribute xin = new EppXriINumberAttribute();
		xin.setINumber(inumber);
		this.inumber.addElement(xin);
	}

	/**
	 * Adds an i-number associated with the XRI authority object
	 *
	 * <P><B>Note:</B> This method should be only called by the EPP server, and
	 *       an EPP client should not perform this operation.
	 */
	public void addINumber( String inumber, int priority )
	{
		EppXriINumberAttribute xin = new EppXriINumberAttribute();
		xin.setINumber(inumber);
		xin.setPriority(priority);
		this.inumber.addElement(xin);
	}

	/**
	 * Adds an i-number associated with the XRI authority object
	 *
	 * <P><B>Note:</B> This method should be only called by the EPP server, and
	 *       an EPP client should not perform this operation.
	 */
	public void addINumber( EppXriINumberAttribute xin )
	{
		this.inumber.addElement(xin);
	}

	/**
	 * Gets a list of identifiers of XRI I-Service objects associated with the XRI authority object
	 */
	public Vector getIService()
	{
		return this.iservice;
	}

	/**
	 * Adds the identifier of an XRI I-Service object associated with the XRI authority object
	 *
	 * <P><B>Note:</B> This method should be only called by the EPP server, and
	 *       an EPP client should not perform this operation.
	 */
	public void addIService( String iServiceId )
	{
		this.iservice.addElement(iServiceId);
	}

	/**
	 * Converts the <code>EppXriAuthority</code> object into an XML element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the <code>EppXriAuthority</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = EppUtil.createElementNS(doc, "xriAU", tag);
		boolean isCreate = tag.equals("create");

		// the order of the tags for create is:
		//
		// authId/socialData/authInfo
		//
		// the order of the tags for info is
		//
		// authId/roid/status/socialData/trustee/xs/sep/iname/inumber/iservice/clID/crID/crDate
		// upDate/trDate/authInfo
		//

		if( authId != null )
		{
			elm = doc.createElement("authId");
			elm.appendChild(doc.createTextNode(authId));
			body.appendChild(elm);
		}
		if( isCreate )
		{
			if( socialData != null )
			{
				body.appendChild(socialData.toXML(doc, "socialData"));
			}
			if( authInfo != null )
			{
				body.appendChild(authInfo.toXML(doc, "authInfo"));
			}

			return body;
		}
		if( roid != null )
		{
			elm = doc.createElement("roid");
			elm.appendChild(doc.createTextNode(roid));
			body.appendChild(elm);
		}
		if( status != null )
		{
			for( int i = 0; i < status.size(); i++ )
			{
				EppStatus s = (EppStatus) status.elementAt(i);
				body.appendChild(s.toXML(doc, "status"));
			}
		}
		if( socialData != null )
		{
			body.appendChild(socialData.toXML(doc, "socialData"));
		}
		if( trustee != null )
		{
			for( int i = 0; i < trustee.size(); i++ )
			{
				EppXriTrustee t = (EppXriTrustee) trustee.elementAt(i);
				body.appendChild(t.toXML(doc, "trustee"));
			}
		}
		if( xs != null )
		{
			for( int i = 0; i < xs.size(); i++ )
			{
				EppXriExternalSynonym t = (EppXriExternalSynonym) xs.elementAt(i);
				body.appendChild(t.toXML(doc, "xs"));
			}
		}
		if( sep != null )
		{
			for( int i = 0; i < sep.size(); i++ )
			{
				EppXriServiceEndpoint t = (EppXriServiceEndpoint) sep.elementAt(i);
				body.appendChild(t.toXML(doc, "sep"));
			}
		}
		if( iname != null )
		{
			for( int i = 0; i < iname.size(); i++ )
			{
				String s = (String) iname.elementAt(i);
				elm = doc.createElement("iname");
				elm.appendChild(doc.createTextNode(s));
				body.appendChild(elm);
			}
		}
		if( inumber != null )
		{
			for( int i = 0; i < inumber.size(); i++ )
			{
				EppXriINumberAttribute xin = (EppXriINumberAttribute) inumber.elementAt(i);
				body.appendChild(xin.toXML(doc, "inumber"));
			}
		}
		if( iservice != null )
		{
			for( int i = 0; i < iservice.size(); i++ )
			{
				String s = (String) iservice.elementAt(i);
				elm = doc.createElement("iservice");
				elm.appendChild(doc.createTextNode(s));
				body.appendChild(elm);
			}
		}

		toXMLCommon(doc, body);

		return body;
	}

	/**
	 * Converts an XML element into an <code>EppXriAuthority</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP Authority type.
	 *
	 * @param root root node for an <code>EppXriAuthority</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriAuthority</code> object, or null if the node
	 *         is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppXriAuthority authority = new EppXriAuthority();
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("authId") )
			{
				authority.setAuthorityId(EppUtil.getText(node));
			}
			else if( name.equals("socialData") )
			{
				EppXriSocialData socialData = (EppXriSocialData) EppXriSocialData.fromXML(node);
				if( socialData != null )
				{
					authority.setSocialData(socialData);
				}
			}
			else if( name.equals("trustee") )
			{
				EppXriTrustee trustee = (EppXriTrustee) EppXriTrustee.fromXML(node);
				if( trustee != null )
				{
					authority.addTrustee(trustee);
				}
			}
			else if( name.equals("xs") )
			{
				EppXriExternalSynonym xs = (EppXriExternalSynonym) EppXriExternalSynonym.fromXML(node);
				if( xs != null )
				{
					authority.addExternalSynonym(xs);
				}
			}
			else if( name.equals("sep") )
			{
				EppXriServiceEndpoint sep = (EppXriServiceEndpoint) EppXriServiceEndpoint.fromXML(node);
				if( sep != null )
				{
					authority.addServiceEndpoint(sep);
				}
			}
			else if( name.equals("iname") )
			{
				authority.addIName(EppUtil.getText(node));
			}
			else if( name.equals("inumber") )
			{
				EppXriINumberAttribute xin = (EppXriINumberAttribute) EppXriINumberAttribute.fromXML(node);
				if( xin != null )
				{
					authority.addINumber(xin);
				}
			}
			else if( name.equals("iservice") )
			{
				authority.addIService(EppUtil.getText(node));
			}
			else if( name.equals("authInfo") )
			{
				EppAuthInfo authInfo = (EppAuthInfo) EppAuthInfo.fromXML(node);
				if( authInfo != null )
				{
					authority.setAuthInfo(authInfo);
				}
			}
			else
			{
				authority.fromXMLCommon(node, name);
			}
		}

		return authority;
	}

	public String toString()
	{
		return toString("xriAU");
	}

	/**
	 * Creates an <code>EppCommandDeleteXriAuthority</code> object for
	 * deleting an EPP XRI Authority object from the registry.
	 *
	 * @param authId the identifier of the XRI authority object to be deleted
	 * @param xid    the client transaction id associated with the operation
	 */
	public static EppCommandDeleteXriAuthority delete( String authId, String xid )
	{
		return new EppCommandDeleteXriAuthority(authId, xid);
	}

	/**
	 * Creates an <code>EppCommandInfoXriAuthority</code> object for
	 * querying the details of an EPP XRI Authority object
	 *
	 * @param authId the identifier of the XRI authority object to be queried
	 * @param xid    the client transaction id associated with the operation
	 */
	public static EppCommandInfoXriAuthority info( String authId, String xid )
	{
		return new EppCommandInfoXriAuthority(authId, xid);
	}

	/**
	 * Creates an <code>EppCommandCheckXriAuthority</code> object for
	 * checking the existance of EPP XRI Authority objects in the registry.
	 * Identifiers of EPP XRI Authority objects can be added via the
	 * <code>add</code> or <code>addAuthorityId</code> methods.
	 *
	 * @param xid  the client transaction id associated with the operation
	 */
	public static EppCommandCheckXriAuthority check( String xid )
	{
		return new EppCommandCheckXriAuthority(xid);
	}

	/**
	 * Creates an <code>EppCommandTransferXriAuthority</code> object for
	 * transfering an EPP XRI Authority object in the registry. The operation
	 * type, transfer token, target authority and authorization information associated
	 * with the operation should be specified via <code>setOperation</code>,
	 * <code>setTransferToken</code>, <code>setTarget</code>, and <code>setAuthInfo</code> method.
	 *
	 * @param authId the identifier of the XRI authority object to be transferred
	 * @param xid    the client transaction id associated with the operation
	 */
	public static EppCommandTransferXriAuthority transfer( String authId, String xid )
	{
		return new EppCommandTransferXriAuthority(authId, xid);
	}

	/**
	 * Creates an <code>EppCommandUpdateXriAuthority</code> object for
	 * updating an EPP Authority object in the registry. The actual update
	 * information should be specified via the various methods defined
	 * for the <code>EppCommandUpdateXriAuthority</code> object.
	 *
	 * @param authId the identifier of the XRI authority object to be updated
	 * @param xid    the client transaction id associated with the operation
	 */
	public static EppCommandUpdateXriAuthority update( String authId, String xid )
	{
		return new EppCommandUpdateXriAuthority(authId, xid);
	}
}
