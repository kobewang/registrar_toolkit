/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.core;

import org.w3c.dom.*;
import org.apache.xerces.dom.*;

/**
 * The <code>EppEntity</code> class is the base class for all entities/objects
 * defined for EPP. All subclasses of <code>EppEntity</code> need to implement
 * the following three methods:
 * <UL>
 * <LI><code>fromXML</code></LI>
 * <LI><code>toXML</code></LI>
 * <LI><code>toString</code></LI>
 * </UL>
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
abstract public class EppEntity
{
	/**
	 * Converts an XML element into an <code>EppEntity</code> object.
	 * The caller of this method must make sure that the root node is
	 * of an EPP entity.
	 *
	 * @param root root node for an <code>EppEntity</code> object in
	 *             XML format
	 *
	 * @return an <code>EppEntity</code> object, or null if the node
	 *         is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		return null;
	}

	/**
	 * Converts the <code>EppEntity</code> object into an XML element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the <code>EppEntity</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	abstract public Element toXML( Document doc, String tag );

	/**
	 * Converts the <code>EppEntity</code> object into plain XML text string
	 *
	 * @param tag XML tag name for the root node
	 *
	 * @return a text string representing the <code>EppEntity</code> object
	 *         in XML format
	 */
	protected String toString( String tag )
	{
		Document doc = new DocumentImpl();
		Element elm = this.toXML(doc, tag);
		doc.appendChild(elm);
		return EppUtil.toString(doc);
	}

	/*
	 * Converts the <code>EppEntity</code> object into plain XML text string
	 * by using the default root tag name
	 *
	 * @return a text string representing the <code>EppEntity</code> object
	 *         in XML format
	 */
	abstract public String toString();
}
