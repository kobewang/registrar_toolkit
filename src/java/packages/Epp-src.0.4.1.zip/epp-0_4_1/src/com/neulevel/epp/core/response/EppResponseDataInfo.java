/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.core.response;

import org.w3c.dom.*;
import com.neulevel.epp.core.*;

/**
 * This <code>EppResponseDataInfo</code> class implements EPP Response
 * Data entity for EPP Command Info.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class EppResponseDataInfo extends EppResponseData
{
	private EppObject object;

	/**
	 * Creates an <code>EppResponseDataInfo</code> object
	 */
	public EppResponseDataInfo( EppObject object )
	{
		this.object = object;
	}

	/**
	 * Gets the <code>EppObject</code> returned by the EPP info command
	 */
	public EppObject getObject()
	{
		return this.object;
	}

	/**
	 * Sets the <code>EppObject</code> returned by the EPP info command
	 */
	public void setObject( EppObject object )
	{
		this.object = object;
	}

	/**
	 * Converts the <code>EppResponseDataInfo</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the <code>EppResponse</code>
	 *            object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm = object.toXML(doc, "infData"); 
		Element body = doc.createElement(tag);
		body.appendChild(elm);

		return body;
	}

	/**
	 * Converts an XML element into an <code>EppResponseDataInfo</code>
	 * object. The caller of this method must make sure that the root
	 * node is of the EPP infDataType.
	 *
	 * @param root root node for an <code>EppResponseDataInfo</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataInfo</code> object, or null
	 *         if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppObject object = (EppObject) EppObject.fromXML(root);
		if( object != null )
		{
			return new EppResponseDataInfo(object);
		}

		return null;
	}
}
