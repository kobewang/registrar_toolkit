/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.xri.response;

import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.response.*;

/**
 * This <code>EppResponseDataCheckXriINumber</code> class implements EPP
 * Response Data entity for EPP Command Check of EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class EppResponseDataCheckXriINumber extends EppResponseDataCheck
{
	/**
	 * Checks an <code>EppResponseDataCheckXriINumber</code> object
	 */
	public EppResponseDataCheckXriINumber()
	{
	}

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCheckXriINumber</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for checking EPP XRI I-Number objects.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCheckXriINumber</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCheckXriINumber</code> object, or null
	 *         if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppResponseDataCheckXriINumber rsp = new EppResponseDataCheckXriINumber();
		rsp.fromXMLCommon(root, "inumber");
		return rsp;
	}

	/**
	 * Converts an <code>EppResponseDataCheckXriINumber</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCheckXriINumber</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = doc.createElement(tag);
		Element data = EppUtil.createElementNS(doc, "xriINU", "chkData");
		body.appendChild(data);
		toXMLCommon(doc, data, "inumber");

		return body;
	}
}
