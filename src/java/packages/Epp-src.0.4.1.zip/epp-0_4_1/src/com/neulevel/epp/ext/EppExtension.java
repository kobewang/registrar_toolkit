/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.ext;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.ext.command.*;
import com.neulevel.epp.ext.response.*;

/**
 * This <code>EppExtension</code> class implements EPP Extension entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
abstract public class EppExtension extends EppEntity
{
	/**
	 * Converts an XML element into an <code>EppExtension</code> object.
	 * The caller of this method must make sure that the root node is a
	 * child node of an EPP extension tag
	 *
	 * @param root root node for an <code>EppExtension</code> object in XML
	 *             format
	 *
	 * @return an <code>EppEntity</code> object, or null if the node
	 *         is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		if( root == null )
		{
			return null;
		}

		String prefix = root.getPrefix();
		String name   = root.getLocalName();

		if( (prefix == null) || (name == null) )
		{
			return null;
		}

		EppEntity entity = null;

		if( prefix.equals("secDNS") )
		{
			if( name.equals("create") )
			{
				entity = EppCommandCreateSecDns.fromXML(root);
			}
			else if( name.equals("update") )
			{
				entity = EppCommandUpdateSecDns.fromXML(root);
			}
			else if( name.equals("infData") )
			{
				entity = EppResponseDataInfoSecDns.fromXML(root);
			}
		}

		return entity;
	}
}
