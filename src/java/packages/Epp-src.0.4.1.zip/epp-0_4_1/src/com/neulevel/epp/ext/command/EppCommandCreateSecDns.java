/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.ext.command;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.ext.*;

/**
 * This <code>EppCommandCreateSecDns</code> class implements the EPP
 * create command for EPP DNS Security Extension
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class EppCommandCreateSecDns extends EppExtension
{
	private Vector	dsDataList;

	/**
	 * Creates an <code>EppCommandCreateSecDns</code> object
	 */
	public EppCommandCreateSecDns()
	{
		dsDataList = new Vector();
	}

	/**
	 * Adds DS Data to the list to be attached to a domain name
	 */
	public void add( EppSecDnsDsData dsData )
	{
		this.dsDataList.addElement(dsData);
	}

	/**
	 * Gets the list of DS data to be attached to a domain name
	 */
	public Vector getDsData()
	{
		return this.dsDataList;
	}

	/**
	 * Converts an XML element into an <code>EppCommandCreateSecDns</code> object.
	 * The caller of this method must make sure that the root node is of
	 * EPP SECDNS createType
	 *
	 * @param root root node for an <code>EppCommandCreateSecDns</code> object in XML format
	 *
	 * @return an <code>EppCommandCreateSecDns</code> object, or null if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppCommandCreateSecDns cmd  = new EppCommandCreateSecDns();
		NodeList list  = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("dsData") )
			{
				EppSecDnsDsData ds = (EppSecDnsDsData) EppSecDnsDsData.fromXML(node);
				if( ds != null )
				{
					cmd.add(ds);
				}
			}
			else if( name.equals("keyData") )
			{
				// FIXME(zhang) not supported
			}
		}

		return cmd;
	}

	/**
	 * Converts the <code>EppCommandCreateSecDns</code> object into an XML element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the <code>EppCommandCreateSecDns</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		if( tag == null )
		{
			tag = "create";
		}
		Element body = EppUtil.createElementNS(doc, "secDNS", tag);
		for( int i = 0; i < dsDataList.size(); i++ )
		{
			Object obj = dsDataList.elementAt(i);
			if( (obj != null) && (obj instanceof EppSecDnsDsData) )
			{
				EppSecDnsDsData ds = (EppSecDnsDsData) obj;
				Element elm = ds.toXML(doc, "dsData");
				body.appendChild(elm);
			}
		}
		return body;
	}

	public String toString()
	{
		return toString("create");
	}
}
