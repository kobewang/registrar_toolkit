/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.core.command;

import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.xri.*;

/**
 * This <code>EppCommandCreate</code> class implements EPP Command Create
 * entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class EppCommandCreate extends EppCommand
{
	private EppObject object;

	/**
	 * Creates an <code>EppCommandCreate</code> object
	 *
	 * @param object the <code>EppObject</code> to be processed
	 */
	public EppCommandCreate( EppObject object )
	{
		this.object = object;
	}

	/**
	 * Creates an <code>EppCommandCreate</code> object
	 *
	 * @param object the <code>EppObject</code> to be processed
	 * @param xid    the client transaction id associated with the
	 *               operation
	 */
	public EppCommandCreate( EppObject object, String xid )
	{
		this.object = object;
		this.clTRID = xid;
	}


	/**
	 * Gets the object to be processed
	 */
	public EppObject getObject()
	{
		return this.object;
	}

	/**
	 * Sets the object to be processed
	 */
	public void setObject( EppObject object )
	{
		this.object = object;
	}

	/**
	 * Converts the <code>EppCommandCreate</code> object into an XML element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the <code>EppCommandCreate</code>
	 *            object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		return toXMLCommon(doc, tag, object);
	}

	/**
	 * Converts an XML element into an <code>EppCommandCreate</code> object.
	 * The caller of this method must make sure that the root node is of an
	 * EPP Command Create entity.
	 *
	 * @param root root node for an <code>EppCommandCreate</code> object
	 *             in XML format
	 *
	 * @return an <code>EppCommandCreate</code> object, or null if the node
	 *         is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		String command = root.getLocalName();
		NodeList list = root.getChildNodes();
		EppObject object = null;
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String prefix = node.getPrefix();
			String name = node.getLocalName();
			if( (prefix == null) || (name == null) )
			{
				continue;
			}
			if( name.equals(command) )
			{
				if( prefix.equals("contact") )
				{
					object = (EppObject) EppContact.fromXML(node);
				}
				else if( prefix.equals("domain") )
				{
					object = (EppObject) EppDomain.fromXML(node);
				}
				else if( prefix.equals("host") )
				{
					object = (EppObject) EppHost.fromXML(node);
				}
				else if( prefix.equals("svcsub") )
				{
					object = (EppSvcsub) EppSvcsub.fromXML(node);
				}
				else if( prefix.equals("xriAU") )
				{
					object = (EppXriAuthority) EppXriAuthority.fromXML(node);
				}
				else if( prefix.equals("xriINU") )
				{
					object = (EppXriINumber) EppXriINumber.fromXML(node);
				}
				else if( prefix.equals("xriINA") )
				{
					object = (EppXriIName) EppXriIName.fromXML(node);
				}
				else if( prefix.equals("xriISV") )
				{
					object = (EppXriIService) EppXriIService.fromXML(node);
				}
				if( object != null )
				{
					return new EppCommandCreate(object);
				}
			}
		}

		return null;
	}

	public String toString()
	{
		return toString("create");
	}
}
