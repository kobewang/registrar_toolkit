/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.core.response;

import org.w3c.dom.*;
import com.neulevel.epp.core.*;

/**
 * This <code>EppResponseDataCheckContact</code> class implements EPP
 * Response Data entity for EPP Command Check of EPP Contact objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class EppResponseDataCheckContact extends EppResponseDataCheck
{
	/**
	 * Checks an <code>EppResponseDataCheckContact</code> object
	 */
	public EppResponseDataCheckContact()
	{
	}

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCheckContact</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for checking EPP Contact objects.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCheckContact</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCheckContact</code> object, or null
	 *         if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppResponseDataCheckContact rsp = new EppResponseDataCheckContact();
		rsp.fromXMLCommon(root, "id");
		return rsp;
	}

	/**
	 * Converts an <code>EppResponseDataCheckContact</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCheckContact</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = doc.createElement(tag);
		Element data = EppUtil.createElementNS(doc, "contact", "chkData");
		body.appendChild(data);
		toXMLCommon(doc, data, "id");

		return body;
	}
}
