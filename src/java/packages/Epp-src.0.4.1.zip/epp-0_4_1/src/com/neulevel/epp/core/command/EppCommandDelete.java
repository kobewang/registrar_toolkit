/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.core.command;

import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.xri.command.*;

/**
 * This <code>EppCommandDelete</code> class implements EPP Command Delete
 * entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
abstract public class EppCommandDelete extends EppCommand
{
	/**
	 * Converts an XML element into an <code>EppCommandDelete</code> object.
	 * The caller of this method must make sure that the root node is of an
	 * EPP Command Delete entity.
	 *
	 * @param root root node for an <code>EppCommandDelete</code> object
	 *             in XML format
	 *
	 * @return an <code>EppCommandDelete</code> object, or null if the node
	 *         is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		String command = root.getLocalName();
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String prefix = node.getPrefix();
			String name = node.getLocalName();
			if( (prefix == null) || (name == null) )
			{
				continue;
			}
			if( name.equals(command) )
			{
				if( prefix.equals("contact") )
				{
					return EppCommandDeleteContact.fromXML(node);
				}
				else if( prefix.equals("domain") )
				{
					return EppCommandDeleteDomain.fromXML(node);
				}
				else if( prefix.equals("host") )
				{
					return EppCommandDeleteHost.fromXML(node);
				}
				else if( prefix.equals("svcsub") )
				{
					return EppCommandDeleteSvcsub.fromXML(node);
				}
				else if( prefix.equals("xriAU") )
				{
					return EppCommandDeleteXriAuthority.fromXML(node);
				}
				else if( prefix.equals("xriINU") )
				{
					return EppCommandDeleteXriINumber.fromXML(node);
				}
				else if( prefix.equals("xriINA") )
				{
					return EppCommandDeleteXriIName.fromXML(node);
				}
				else if( prefix.equals("xriISV") )
				{
					return EppCommandDeleteXriIService.fromXML(node);
				}
			}
		}

		return null;
	}

	public String toString()
	{
		return toString("delete");
	}
}
