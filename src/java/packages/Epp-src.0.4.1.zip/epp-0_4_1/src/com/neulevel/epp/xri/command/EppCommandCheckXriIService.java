/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.xri.command;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.command.*;

/**
 * This <code>EppCommandCheckXriIService</code> class implements EPP Command Check
 * entity for EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class EppCommandCheckXriIService extends EppCommandCheck
{
	private Vector ids;

	/**
	 * Creates an <code>EppCommandCheckXriIService</code> object
	 */
	public EppCommandCheckXriIService()
	{
		this(null);
	}

	/**
	 * Creates an <code>EppCommandCheckXriIService</code> object, given a
	 * client transaction id associated with the operation
	 */
	public EppCommandCheckXriIService( String xid )
	{
		this.ids = new Vector();
		this.clTRID = xid;
	}

	/**
	 * Gets the list of the identifiers of the XRI i-service objects to be checked
	 */
	public Vector getId()
	{
		return this.ids;
	}

	/**
	 * Gets the list of the identifiers of the XRI i-service objects to be checked.
	 *
	 * <P><B>Note:</B> This is an alias for <code>getId</code>
	 */
	public Vector get()
	{
		return this.getId();
	}

	/**
	 * Adds the identifier of an XRI i-service object to the list of identifiers of XRI i-service
	 * objects be checked
	 */
	public void addId( String id )
	{
		this.ids.addElement(id);
	}

	/**
	 * Adds the identifier of an XRI i-service object to the list of identifiers of XRI i-service
	 * objects be checked.
	 *
	 * <P><B>Note:</B> This is an alias for <code>addId</code>
	 */
	public void add( String id )
	{
		this.addId(id);
	}

	/**
	 * Converts the <code>EppCommandCheckXriIService</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandCheckXriIService</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = EppUtil.createElementNS(doc, "xriISV", tag);

		if( ids != null )
		{
			for( int i = 0; i < ids.size(); i++ )
			{
				String id = (String) ids.get(i);
				elm = doc.createElement("id");
				elm.appendChild(doc.createTextNode(id));
				body.appendChild(elm);
			}
		}

		return toXMLCommon(doc, tag, body);
	}

	/**
	 * Converts an XML element into an <code>EppCommandCheckXriIService</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Check entity for EPP XriIService objects.
	 *
	 * @param root root node for an <code>EppCommandCheckXriIService</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandCheckXriIService</code> object, or null
	 *         if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppCommandCheckXriIService cmd = new EppCommandCheckXriIService();
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("id") )
			{
				String id = EppUtil.getText(node);
				cmd.addId(id);
			}
		}

		return cmd;
	}
}
