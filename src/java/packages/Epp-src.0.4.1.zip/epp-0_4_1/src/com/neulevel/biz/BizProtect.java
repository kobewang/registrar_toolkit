/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.biz;

/**
 * This <code>BizProtect</code> class defines various services ids
 * in the BIZprotect product suite.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class BizProtect
{
	/**
	 * Service ID for BIZ Account
	 */
	public static final String BIZ_ACCOUNT = "BIZaccount";

	/**
	 * Service ID for BIZ Lock
	 */
	public static final String BIZ_LOCK = "BIZlock";
}
