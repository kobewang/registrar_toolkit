/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.xri.response;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.response.*;

/**
 * This <code>EppResponseDataCreateXriIName</code> class implements EPP
 * Response Data entity for EPP Command Create of EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class EppResponseDataCreateXriIName extends EppResponseDataCreate
{
	private String   iname;
	private Calendar exDate;

	/**
	 * Creates an <code>EppResponseDataCreateXriIName</code> object,
	 * with the current date as the creation date.
	 *
         * @param iname the i-name of the EPP XRI i-name object created
	 */
	public EppResponseDataCreateXriIName( String iname )
	{
		this(iname, null, Calendar.getInstance());
	}

	/**
	 * Creates an <code>EppResponseDataCreateXriIName</code> object,
	 * given the i-name of the XRI i-name object, and an expiration date,
	 * with the current date as the creation date
	 *
         * @param iname the i-name of the EPP XRI i-name object created
         * @param exDate  the expiration date of the XRI i-name object created
	 */
	public EppResponseDataCreateXriIName( String iname, Calendar exDate )
	{
		this(iname, exDate, Calendar.getInstance());
	}

	/**
	 * Creates an <code>EppResponseDataCreateXriIName</code> object,
	 * given the i-name of the XRI i-name object, a reference id,
	 * and an expiration date,
	 * with the current date as the creation date
	 *
         * @param iname the i-name of the EPP XRI i-name object created
         * @param exDate  the expiration date of the XRI i-name object created
         * @param crDate  the creation date of the XRI i-name object created
	 */
	public EppResponseDataCreateXriIName( String iname, Calendar exDate, Calendar crDate )
	{
		this.iname  = iname;
		this.exDate = exDate;
		this.crDate = crDate;
	}

	/**
	 * Sets the i-name
	 */
	public void setIName( String iname )
	{
		this.iname = iname;
	}

	/**
	 * Gets the i-name
	 */
	public String getIName()
	{
		return this.iname;
	}

	/**
	 * Gets expiration date of the XRI i-name object created
	 */
	public Calendar getDateExpired()
	{
		return this.exDate;
	}

	/**
	 * Sets expiration date of the XRI i-name object created
	 */
	public void setDateExpired( Calendar exDate )
	{
		this.exDate = exDate;
	}

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCreateXriIName</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XriIName object.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCreateXriIName</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCreateXriIName</code> object, or null
	 *         if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		String   i_name    = null;
		Calendar create_date = null;
		Calendar expire_date = null;
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("iname") )
			{
				String id = EppUtil.getText(node);
				if( (id != null) && (id.length() > 0) )
				{
					i_name = id;
				}
			}
			else if( name.equals("crDate") )
			{
				Calendar d = EppUtil.getDate(node);
				if( d != null )
				{
					create_date = d;
				}
			}
			else if( name.equals("exDate") )
			{
				Calendar d = EppUtil.getDate(node);
				if( d != null )
				{
					expire_date = d;
				}
			}
		}

		return new EppResponseDataCreateXriIName(i_name, expire_date, create_date);
	}

	/**
	 * Converts an <code>EppResponseDataCreateXriIName</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCreateXriIName</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = doc.createElement(tag);
		Element data = EppUtil.createElementNS(doc, "xriINA", "creData");
		body.appendChild(data);
		if( iname != null )
		{
			elm = doc.createElement("iname");
			elm.appendChild(doc.createTextNode(iname));
			data.appendChild(elm);
		}
		if( crDate != null )
		{
			elm = doc.createElement("crDate");
			elm.appendChild(EppUtil.createTextNode(doc, crDate));
			data.appendChild(elm);
		}
		if( exDate != null )
		{
			elm = doc.createElement("exDate");
			elm.appendChild(EppUtil.createTextNode(doc, exDate));
			data.appendChild(elm);
		}

		return body;
	}
}
