/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.xri.response;

import java.util.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.response.*;
import org.w3c.dom.*;
import org.apache.xerces.dom.*;

/**
 * This <code>EppResponseDataPendingXriIName</code> class implements EPP
 * Response Data entity for EPP Pending Actions of EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class EppResponseDataPendingXriIName extends EppResponseDataPending
{
	private String   iname;

	/**
	 * Creates an <code>EppResponseDataPendingXriIName</code> object
	 *
	 * @param iname the i-name of the <code>EppXriIName</code> object associated with the pending action
	 */
	public EppResponseDataPendingXriIName( String iname )
	{
		this.iname = iname;
		this.paResult = false;
		this.paTRID = null;
		this.paDate = null;
	}

	/**
	 * Creates an <code>EppResponseDataPendingXriIName</code> object
	 *
	 * @param iname the i-name of the <code>EppXriIName</code> object associated with the pending action
	 * @param result the boolean flag indicating if the pending action is a success or a failure
	 */
	public EppResponseDataPendingXriIName( String iname, boolean result )
	{
		this.iname = iname;
		this.paResult = result;
		this.paTRID = null;
		this.paDate = null;
	}

	/**
	 * Gets the i-name of the XRI i-name object associated with the pending action
	*/
	public String getIName()
	{
		return this.iname;
	}

	/**
	 * Sets the i-name of the XRI i-name object associated with the pending action
	 */
	public void setIName( String iname )
	{
		this.iname = iname;
	}

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataPendingXriIName</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for an pending action of an EPP XRI IName object
	 *
	 * @param root root node for an <code>EppResponseDataPendingXriIName</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataPendingXriIName</code> object,
	 *         or null if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppResponseDataPendingXriIName res = null;
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			else if( name.equals("iname") )
			{
				String iname = EppUtil.getText(node);
				if( res == null )
				{
					res = new EppResponseDataPendingXriIName(iname);
					String cd = ((Element) node).getAttribute("paResult");
					if(    (cd != null)
					    && (    cd.equals("0")
						 || cd.equalsIgnoreCase("f")
						 || cd.equalsIgnoreCase("false") ) )
					{
						res.setResult(false);
					}
					else
					{
						res.setResult(true);
					}
				}
			}
			else if( res != null )
			{
				res.fromXMLCommon(node, name);
			}
		}

		return res;
	}

	/**
	 * Converts an <code>EppResponseDataPendingXriIName</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataPendingXriIName</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = doc.createElement(tag);
		ElementNSImpl data = EppUtil.createElementNS(doc, "xriINA", "panData");
		body.appendChild(data);

		if( iname != null )
		{
			elm = doc.createElement("iname");
			elm.appendChild(doc.createTextNode(iname));
			if( paResult == true )
			{
				elm.setAttribute("paResult", "1");
			}
			else
			{
				elm.setAttribute("paResult", "0");
			}
			data.appendChild(elm);
		}

		toXMLCommon(doc, data);

		return body;
	}
}
