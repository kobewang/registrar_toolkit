/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.biz;

/**
 * This <code>BizContact</code> class defines various constants and methods
 * related to EPP Contact objects associated with the BIZprotect product suite.
 * <P>
 * Please note the following rules regarding associating a contact object with
 * a BIZprotect service:
 * <P>
 * If a contact object is to be associated with a <code>BIZaccount</code>
 * or <code>BIZlock</code> service, it cannot be used as registrant or contacts
 * for a domain object.  
 * <P>
 * In addition, the <code>BIZ_USERID</code> field must be specified in the
 * &lt;unspec&gt; element when the contact object is created. A notification
 * via email or other channels will be sent out with the initial
 * <code>BIZ_PASSWORD</code> value. The fields <code>BIZ_USERID</code> and
 * <code>BIZ_PASSWORD</code> must be specified in the <unspec> element when
 * a contact object used for <code>BIZaccount</code> or <code>BIZlock</code>
 * is updated.
 * <P>
 * The following optional fields can also be supplied in the &lt;unspec&gt;
 * element in a create or update command:
 * <UL>
 *     <LI>BIZ_CONTACT_TITLE</LI>
 *     <LI>BIZ_CONTACT_PAGER</LI>
 *     <LI>BIZ_CONTACT_PHONE</LI>
 *     <LI>BIZ_CONTACT_PHONEEXT</LI>
 *     <LI>BIZ_CONTACT_EMAIL</LI>
 * </UL>
 * And the following optional fields can also be supplied in the &lt;unspec&gt;
 * element in an update command:
 * <UL>
 *     <LI>BIZ_NEWPASSWORD</LI>
 * </UL>
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class BizContact
{
	/**
	 * Owner user id to be supplied in various create or update commands
	 * related to contact objects, supplied in the &lt;unspec&gt; field
	 */
	public static final String BIZ_USERID = "UserId";
	/**
	 * Owner user password to be supplied in various update commands
	 * related to contact objects, supplied in the &lt;unspec&gt; field
	 */
	public static final String BIZ_PASSWORD = "Password";
	/**
	 * Owner user new password to be supplied in various update commands
	 * related to contact objects, supplied in the &lt;unspec&gt; field
	 */
	public static final String BIZ_NEWPASSWORD = "NewPassword";
	/**
	 * Title to be associated with a contact object
	 */
	public static final String BIZ_CONTACT_TITLE = "Title";
	/**
	 * Pager to be associated with a contact object
	 */
	public static final String BIZ_CONTACT_PAGER = "Pager";
	/**
	 * Secondary phone to be associated with a contact object. Its value
	 * follows the E164 format defined in the EPP specification.
	 */
	public static final String BIZ_CONTACT_PHONE = "SecondaryPhone";
	/**
	 * Secondary phone extenstion to be associated with a contact object.
	 */
	public static final String BIZ_CONTACT_PHONEEXT = "SecondaryPhoneExtension";
	/**
	 * Secondary email to be associated with a contact object
	 */
	public static final String BIZ_CONTACT_EMAIL = "SecondaryEmail";
}
