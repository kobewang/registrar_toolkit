/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.xri;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.EppEntity;
import com.neulevel.epp.core.EppUtil;

/**
 * This <code>EppXriExternalSynonym</code> class defines external synonym
 * information associated with XRI authority objects.  It
 * implements XRI xsAddType and xsInfType defined
 * in the XRI authority schema file.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class EppXriExternalSynonym extends EppEntity
{
	/**
	 * Default priority value - 10
	 */
	public static final int     DEFAULT_PRIORITY = 10;

	private int     priority;
	private String  xs;

	/**
	 * Creates an <code>EppXriExternalSynonym</code> object
	 */
	public EppXriExternalSynonym()
	{
		this(null);
	}

	/**
	 * Creates an <code>EppXriExternalSynonym</code> object with an extenal synonym
	 * and the default priority value
	 */
	public EppXriExternalSynonym( String xs )
	{
		this(xs, DEFAULT_PRIORITY);
	}

	/**
	 * Creates an <code>EppXriExternalSynonym</code> object with an extenal synonym
	 * and a priority value
	 */
	public EppXriExternalSynonym( String xs, int priority )
	{
		this.priority = priority;
		this.xs       = xs;
	}

	/**
	 * Gets the priority value for this external synonym
	 */
	public int getPriority()
	{
		return this.priority;
	}

	/**
	 * Sets the priority value for this external synonym
	 */
	public void setPriority( int priority )
	{
		this.priority = priority;
	}

	/**
	 * Gets the XRI string of the external synonym
	 */
	public String getExternalSynonym()
	{
		return this.xs;
	}

	/**
	 * Sets the XRI string of the external synonym
	 */
	public void setExternalSynonym( String xs )
	{
		this.xs = xs;
	}

	/**
         * Converts the <code>EppXriExternalSynonym</code> object into an XML element
         *
         * @param doc the XML <code>Document</code> object
         * @param tag the tag/element name for the <code>EppXriExternalSynonym</code> object
         *
         * @return an <code>Element</code> object
         */
	public Element toXML( Document doc, String tag )
	{
		Element body = doc.createElement(tag);

		body.appendChild(doc.createTextNode(this.xs));
		body.setAttribute("priority", "" + this.priority);

		return body;
	}

	/**
	 * Converts an XML element into an <code>EppXriExternalSynonym</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP XRI xsAddType or xsInfType.
	 *
	 * @param root root node for an <code>EppXriExternalSynonym</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriExternalSynonym</code> object, or null if the node is
	 *         invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppXriExternalSynonym xs       = new EppXriExternalSynonym();
		String   flag     = null;

		xs.setExternalSynonym(EppUtil.getText(root));

		flag = ((Element) root).getAttribute("priority");
		if( flag != null )
		{
			try
			{
				int priority = Integer.parseInt(flag);
				xs.setPriority(priority);
			}
			catch( NumberFormatException e )
			{
			}
		}
		return xs;
	}

	public String toString()
	{
		return toString("xs");
	}
}
