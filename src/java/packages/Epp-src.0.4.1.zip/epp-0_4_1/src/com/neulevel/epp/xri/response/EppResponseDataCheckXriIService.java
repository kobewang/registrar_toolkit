/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.xri.response;

import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.response.*;

/**
 * This <code>EppResponseDataCheckXriIService</code> class implements EPP
 * Response Data entity for EPP Command Check of EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class EppResponseDataCheckXriIService extends EppResponseDataCheck
{
	/**
	 * Checks an <code>EppResponseDataCheckXriIService</code> object
	 */
	public EppResponseDataCheckXriIService()
	{
	}

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCheckXriIService</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for checking EPP XRI I-Service objects.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCheckXriIService</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCheckXriIService</code> object, or null
	 *         if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppResponseDataCheckXriIService rsp = new EppResponseDataCheckXriIService();
		rsp.fromXMLCommon(root, "id");
		return rsp;
	}

	/**
	 * Converts an <code>EppResponseDataCheckXriIService</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCheckXriIService</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = doc.createElement(tag);
		Element data = EppUtil.createElementNS(doc, "xriISV", "chkData");
		body.appendChild(data);
		toXMLCommon(doc, data, "id");

		return body;
	}
}
