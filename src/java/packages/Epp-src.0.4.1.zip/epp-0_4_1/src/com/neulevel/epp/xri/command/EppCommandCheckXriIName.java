/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.xri.command;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.command.*;

/**
 * This <code>EppCommandCheckXriIName</code> class implements EPP Command Check
 * entity for EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class EppCommandCheckXriIName extends EppCommandCheck
{
	private Vector inames;

	/**
	 * Creates an <code>EppCommandCheckXriIName</code> object
	 */
	public EppCommandCheckXriIName()
	{
		this(null);
	}

	/**
	 * Creates an <code>EppCommandCheckXriIName</code> object, given a
	 * client transaction id associated with the operation
	 */
	public EppCommandCheckXriIName( String xid )
	{
		this.inames = new Vector();
		this.clTRID = xid;
	}

	/**
	 * Gets the list of the i-names of the XRI i-name objects to be checked
	 */
	public Vector getIName()
	{
		return this.inames;
	}

	/**
	 * Gets the list of the i-names of the XRI i-name objects to be checked.
	 *
	 * <P><B>Note:</B> This is an alias for <code>getIName</code>
	 */
	public Vector get()
	{
		return this.getIName();
	}

	/**
	 * Adds the i-name of an XRI i-name object to the list of i-names of XRI i-name
	 * objects be checked
	 */
	public void addIName( String iname )
	{
		this.inames.addElement(iname);
	}

	/**
	 * Adds the i-name of an XRI i-name object to the list of i-names of XRI i-name
	 * objects be checked.
	 *
	 * <P><B>Note:</B> This is an alias for <code>addIName</code>
	 */
	public void add( String iname )
	{
		this.addIName(iname);
	}

	/**
	 * Converts the <code>EppCommandCheckXriIName</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandCheckXriIName</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = EppUtil.createElementNS(doc, "xriINA", tag);

		if( inames != null )
		{
			for( int i = 0; i < inames.size(); i++ )
			{
				String id = (String) inames.get(i);
				elm = doc.createElement("iname");
				elm.appendChild(doc.createTextNode(id));
				body.appendChild(elm);
			}
		}

		return toXMLCommon(doc, tag, body);
	}

	/**
	 * Converts an XML element into an <code>EppCommandCheckXriIName</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Check entity for EPP XriIName objects.
	 *
	 * @param root root node for an <code>EppCommandCheckXriIName</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandCheckXriIName</code> object, or null
	 *         if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppCommandCheckXriIName cmd = new EppCommandCheckXriIName();
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("iname") )
			{
				String iname = EppUtil.getText(node);
				cmd.addIName(iname);
			}
		}

		return cmd;
	}
}
