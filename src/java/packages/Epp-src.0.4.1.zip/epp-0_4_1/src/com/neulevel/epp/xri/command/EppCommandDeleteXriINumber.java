/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.xri.command;

import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.command.*;

/**
 * This <code>EppCommandDelete</code> class implements EPP Command Delete
 * entity for EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class EppCommandDeleteXriINumber extends EppCommandDelete
{
	private String inumber;

	/**
	 * Creates an <code>EppCommandDeleteXriINumber</code> object for
	 * deleting an XRI i-number based on its i-number
	 */
	public EppCommandDeleteXriINumber( String inumber )
	{
		this.inumber = inumber;
	}

	/**
	 * Creates an <code>EppCommandDeleteXriINumber</code> object for
	 * deleting an XRI i-number based on its i-number, given a client
	 * transaction id associated with the operation
	 */
	public EppCommandDeleteXriINumber( String inumber, String xid )
	{
		this.inumber = inumber;
		this.clTRID = xid;
	}

	/**
	 * Gets the i-number of the XRI i-number object to be deleted
	 */
	public String getINumber()
	{
		return this.inumber;
	}

	/**
	 * Sets the i-number of the XRI i-number object to be deleted
	 */
	public void setINumber( String inumber )
	{
		this.inumber = inumber;
	}

	/**
	 * Converts the <code>EppCommandDeleteXriINumber</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandDeleteXriINumber</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = EppUtil.createElementNS(doc, "xriINU", tag);

		if( inumber != null )
		{
			elm = doc.createElement("inumber");
			elm.appendChild(doc.createTextNode(inumber));
			body.appendChild(elm);
		}

		return toXMLCommon(doc, tag, body);
	}

	/**
	 * Converts an XML element into an <code>EppCommandDeleteXriINumber</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Delete entity for EPP XriINumber object.
	 *
	 * @param root root node for an <code>EppCommandDeleteXriINumber</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandDeleteXriINumber</code> object, or null
	 *         if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppCommandDeleteXriINumber cmd = null;
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("inumber") )
			{
				String inumber = EppUtil.getText(node);
				if( cmd == null )
				{
					cmd = new EppCommandDeleteXriINumber(inumber);
				}
				else
				{
					cmd.setINumber(inumber);
				}
			}
		}

		return cmd;
	}
}
