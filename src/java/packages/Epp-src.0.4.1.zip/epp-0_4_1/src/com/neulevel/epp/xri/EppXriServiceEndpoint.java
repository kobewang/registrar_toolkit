/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.xri;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.EppEntity;
import com.neulevel.epp.core.EppUtil;

/**
 * This <code>EppXriServiceEndpoint</code> class defines local access URI
 * information associated with XRI authority objects.  It
 * implements XRI sepAddType and sepInfType defined
 * in the XRI authority schema file.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class EppXriServiceEndpoint extends EppEntity
{
	/**
	 * Default priority value - 10
	 */
	public static final int     DEFAULT_PRIORITY = 10;

	private String  id;
	private int     priority;
	private String  authority;
	private Vector  type;
	private Vector  uri;
	private Vector  mediaType;

	/**
	 * Creates an <code>EppXriServiceEndpoint</code> object
	 */
	public EppXriServiceEndpoint()
	{
		this(null);
	}

	/**
	 * Creates an <code>EppXriServiceEndpoint</code> object with an identifier
	 */
	public EppXriServiceEndpoint( String id )
	{
		this.id        = id;
		this.priority  = DEFAULT_PRIORITY;
		this.authority = null;
		this.type      = new Vector();
		this.uri       = new Vector();
		this.mediaType = new Vector();
	}

	/**
	 * Gets the identifier of this XRI Service Endpoint object
	 */
	public String getId()
	{
		return this.id;
	}

	/**
	 * Sets the identifier of this XRI Service Endpoint object
	 */
	public void setId( String id )
	{
		this.id = id;
	}

	/**
	 * Gets the priority value for this XRI Service Endpoint object
	 */
	public int getPriority()
	{
		return this.priority;
	}

	/**
	 * Sets the priority value for this XRI Service Endpoint object
	 */
	public void setPriority( int priority )
	{
		this.priority = priority;
	}

	/**
	 * Gets the identifier of the authority that provides the services of this XRI Service Endpoint object
	 */
	public String getAuthority()
	{
		return this.authority;
	}

	/**
	 * Sets the identifier of the authority that provides the services of this XRI Service Endpoint object
	 */
	public void setAuthority( String authority )
	{
		this.authority = authority;
	}

	/**
	 * Gets the list of service types of this XRI Service Endpoint object
	 */
	public Vector getType()
	{
		return this.type;
	}

	/**
	 * Add a service type to the service type list of this XRI Service Endpoint object
	 */
	public void addType( String type )
	{
		this.type.addElement(type);
	}

	/**
	 * Gets the URIs associated with this XRI Service Endpoint object
	 */
	public Vector getURI()
	{
		return this.uri;
	}

	/**
	 * Adds a URI to be associated with this XRI Service Endpoint object with the default priority value
	 */
	public void addURI( String uri )
	{
		EppXriURI t = new EppXriURI(uri);
		this.uri.addElement(t);
	}

	/**
	 * Adds a URI to be associated with this XRI Service Endpoint object with a priority value
	 */
	public void addURI( String uri, int priority )
	{
		EppXriURI t = new EppXriURI(uri, priority);
		this.uri.addElement(t);
	}

	/**
	 * Adds a URI to be associated with this XRI Service Endpoint object
	 */
	public void addURI( EppXriURI uri )
	{
		this.uri.addElement(uri);
	}

	/**
	 * Gets the media types associated with this XRI Service Endpoint object
	 */
	public Vector getMediaType()
	{
		return this.mediaType;
	}

	/**
	 * Adds a media type to be associated with this XRI Service Endpoint object
	 */
	public void addMediaType( String mediaType )
	{
		this.mediaType.addElement(mediaType);
	}

	/**
         * Converts the <code>EppXriServiceEndpoint</code> object into an XML element
         *
         * @param doc the XML <code>Document</code> object
         * @param tag the tag/element name for the <code>EppXriServiceEndpoint</code> object
         *
         * @return an <code>Element</code> object
         */
	public Element toXML( Document doc, String tag )
	{
		Element body = doc.createElement(tag);
		Element elm;

		if( this.id != null )
		{
			elm = doc.createElement("id");
			elm.appendChild(doc.createTextNode(this.id));
			body.appendChild(elm);
		}
		elm = doc.createElement("priority");
		elm.appendChild(doc.createTextNode("" + this.priority));
		body.appendChild(elm);
		if( this.authority != null )
		{
			elm = doc.createElement("authority");
			elm.appendChild(doc.createTextNode(this.authority));
			body.appendChild(elm);
		}
		if( this.type != null )
		{
			for( int i = 0; i < this.type.size(); i++ )
			{
				String s = (String) this.type.elementAt(i);
				elm = doc.createElement("type");
				elm.appendChild(doc.createTextNode(s));
				body.appendChild(elm);
			}
		}
		if( this.uri != null )
		{
			for( int i = 0; i < this.uri.size(); i++ )
			{
				EppXriURI s = (EppXriURI) this.uri.elementAt(i);
				body.appendChild(s.toXML(doc, "uri"));
			}
		}
		if( this.mediaType != null )
		{
			for( int i = 0; i < this.mediaType.size(); i++ )
			{
				String s = (String) this.mediaType.elementAt(i);
				elm = doc.createElement("mediaType");
				elm.appendChild(doc.createTextNode(s));
				body.appendChild(elm);
			}
		}

		return body;
	}

	/**
	 * Converts an XML element into an <code>EppXriServiceEndpoint</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP XRI sepAddType or sepInfType.
	 *
	 * @param root root node for an <code>EppXriServiceEndpoint</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriServiceEndpoint</code> object, or null if the node is
	 *         invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppXriServiceEndpoint sep = new EppXriServiceEndpoint();

		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("id") )
			{
				sep.setId(EppUtil.getText(node));
			}
			else if( name.equals("priority") )
			{
				String flag = EppUtil.getText(node);
				if( flag != null )
				{
					try
					{
						int priority = Integer.parseInt(flag);
						sep.setPriority(priority);
					}
					catch( NumberFormatException e )
					{
					}
				}
			}
			else if( name.equals("authority") )
			{
				sep.setAuthority(EppUtil.getText(node));
			}
			else if( name.equals("type") )
			{
				sep.addType(EppUtil.getText(node));
			}
			else if( name.equals("uri") )
			{
				EppXriURI s = (EppXriURI) EppXriURI.fromXML(node);
				sep.addURI(s);
			}
			else if( name.equals("mediaType") )
			{
				sep.addMediaType(EppUtil.getText(node));
			}
		}

		return sep;
	}

	public String toString()
	{
		return toString("sep");
	}
}
