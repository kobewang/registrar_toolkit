/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.xri.command;

import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.command.*;

/**
 * This <code>EppCommandInfo</code> class implements EPP Command Info
 * entity for EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class EppCommandInfoXriIService extends EppCommandInfo
{
	private String id;

	/**
	 * Creates an <code>EppCommandInfoXriIService</code> object for
	 * querying an XRI i-service object based on its identifier
	 */
	public EppCommandInfoXriIService( String id )
	{
		this.id = id;
	}

	/**
	 * Creates an <code>EppCommandInfoXriIService</code> object for
	 * querying an XRI i-service object based on its identifier, given a client
	 * transaction id associated with the operation
	 */
	public EppCommandInfoXriIService( String id, String xid )
	{
		this.id = id;
		this.clTRID = xid;
	}

	/**
	 * Gets the identifier of the XRI i-service object to be queried
	 */
	public String getId()
	{
		return this.id;
	}

	/**
	 * Sets the identifier of the XRI i-service object to be queried
	 */
	public void setId( String id )
	{
		this.id = id;
	}

	/**
	 * Converts the <code>EppCommandInfoXriIService</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandInfoXriIService</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = EppUtil.createElementNS(doc, "xriISV", tag);

		if( id != null )
		{
			elm = doc.createElement("id");
			elm.appendChild(doc.createTextNode(id));
			body.appendChild(elm);
		}

		return toXMLCommon(doc, tag, body);
	}

	/**
	 * Converts an XML element into an <code>EppCommandInfoXriIService</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Info entity for EPP XriIService object.
	 *
	 * @param root root node for an <code>EppCommandInfoXriIService</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandInfoXriIService</code> object, or null
	 *         if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		EppCommandInfoXriIService cmd = null;
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("id") )
			{
				String id = EppUtil.getText(node);
				if( cmd == null )
				{
					cmd = new EppCommandInfoXriIService(id);
				}
				else
				{
					cmd.setId(id);
				}
			}
		}

		return cmd;
	}
}
