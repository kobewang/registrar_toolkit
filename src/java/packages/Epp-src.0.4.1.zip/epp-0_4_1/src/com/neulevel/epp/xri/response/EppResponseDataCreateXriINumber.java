/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.xri.response;

import java.util.*;
import org.w3c.dom.*;
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.response.*;

/**
 * This <code>EppResponseDataCreateXriINumber</code> class implements EPP
 * Response Data entity for EPP Command Create of EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class EppResponseDataCreateXriINumber extends EppResponseDataCreate
{
	private String   inumber;
	private String   refId;
	private Calendar exDate;

	/**
	 * Creates an <code>EppResponseDataCreateXriINumber</code> object,
	 * with the current date as the creation date.
	 *
         * @param inumber the i-number of the EPP XRI i-number object created
	 */
	public EppResponseDataCreateXriINumber( String inumber )
	{
		this(inumber, null, null, Calendar.getInstance());
	}

	/**
	 * Creates an <code>EppResponseDataCreateXriINumber</code> object,
	 * given the i-number of the XRI i-number object, and an expiration date,
	 * with the current date as the creation date
	 *
         * @param inumber the i-number of the EPP XRI i-number object created
         * @param exDate  the expiration date of the XRI i-number object created
	 */
	public EppResponseDataCreateXriINumber( String inumber, Calendar exDate )
	{
		this(inumber, null, exDate, Calendar.getInstance());
	}

	/**
	 * Creates an <code>EppResponseDataCreateXriINumber</code> object,
	 * given the i-number of the XRI i-number object, a reference id,
	 * and an expiration date,
	 * with the current date as the creation date
	 *
         * @param inumber the i-number of the EPP XRI i-number object created
         * @param refId   the reference id of the XRI i-number object created
         * @param exDate  the expiration date of the XRI i-number object created
	 */
	public EppResponseDataCreateXriINumber( String inumber, String refId, Calendar exDate )
	{
		this(inumber, refId, exDate, Calendar.getInstance());
	}

	/**
	 * Creates an <code>EppResponseDataCreateXriINumber</code> object,
	 * given the i-number of the XRI i-number object, a reference id,
	 * and an expiration date,
	 * with the current date as the creation date
	 *
         * @param inumber the i-number of the EPP XRI i-number object created
         * @param refId   the reference id of the XRI i-number object created
         * @param exDate  the expiration date of the XRI i-number object created
         * @param crDate  the creation date of the XRI i-number object created
	 */
	public EppResponseDataCreateXriINumber( String inumber, String refId, Calendar exDate, Calendar crDate )
	{
		this.inumber = inumber;
		this.refId   = refId;
		this.exDate  = exDate;
		this.crDate  = crDate;
	}

	/**
	 * Sets the i-number
	 */
	public void setINumber( String inumber )
	{
		this.inumber = inumber;
	}

	/**
	 * Gets the i-number
	 */
	public String getINumber()
	{
		return this.inumber;
	}

	/**
	 * Gets expiration date of the XRI i-number object created
	 */
	public Calendar getDateExpired()
	{
		return this.exDate;
	}

	/**
	 * Sets expiration date of the XRI i-number object created
	 */
	public void setDateExpired( Calendar exDate )
	{
		this.exDate = exDate;
	}

	/**
	 * Gets the reference identifier used in generating the i-number, if any
	 */
	public String getReferenceId()
	{
		return this.refId;
	}

	/**
	 * Gets the reference identifier used in generating the i-number, if any
	 */
	public void setReferenceId( String refId )
	{
		this.refId = refId;
	}

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCreateXriINumber</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XriINumber object.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCreateXriINumber</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCreateXriINumber</code> object, or null
	 *         if the node is invalid
	 */
	public static EppEntity fromXML( Node root )
	{
		String   i_number    = null;
		String   ref_id      = null;
		Calendar create_date = null;
		Calendar expire_date = null;
		NodeList list = root.getChildNodes();
		for( int i = 0; i < list.getLength(); i++ )
		{
			Node node = list.item(i);
			String name = node.getLocalName();
			if( name == null )
			{
				continue;
			}
			if( name.equals("inumber") )
			{
				String id = EppUtil.getText(node);
				if( (id != null) && (id.length() > 0) )
				{
					i_number = id;
				}
			}
			else if( name.equals("refId") )
			{
				String id = EppUtil.getText(node);
				if( (id != null) && (id.length() > 0) )
				{
					ref_id = id;
				}
			}
			else if( name.equals("crDate") )
			{
				Calendar d = EppUtil.getDate(node);
				if( d != null )
				{
					create_date = d;
				}
			}
			else if( name.equals("exDate") )
			{
				Calendar d = EppUtil.getDate(node);
				if( d != null )
				{
					expire_date = d;
				}
			}
		}

		return new EppResponseDataCreateXriINumber(i_number, ref_id, expire_date, create_date);
	}

	/**
	 * Converts an <code>EppResponseDataCreateXriINumber</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCreateXriINumber</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	public Element toXML( Document doc, String tag )
	{
		Element elm;
		Element body = doc.createElement(tag);
		Element data = EppUtil.createElementNS(doc, "xriINU", "creData");
		body.appendChild(data);
		if( inumber != null )
		{
			elm = doc.createElement("inumber");
			elm.appendChild(doc.createTextNode(inumber));
			data.appendChild(elm);
		}
		if( refId != null )
		{
			elm = doc.createElement("refId");
			elm.appendChild(doc.createTextNode(refId));
			data.appendChild(elm);
		}
		if( crDate != null )
		{
			elm = doc.createElement("crDate");
			elm.appendChild(EppUtil.createTextNode(doc, crDate));
			data.appendChild(elm);
		}
		if( exDate != null )
		{
			elm = doc.createElement("exDate");
			elm.appendChild(EppUtil.createTextNode(doc, exDate));
			data.appendChild(elm);
		}

		return body;
	}
}
