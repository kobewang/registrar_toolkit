/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
package com.neulevel.epp.core.response;

import java.util.*;
import com.neulevel.epp.core.*;

/**
 * This <code>EppResponseDataCreate</code> class implements EPP Response
 * Data entity for EPP Command Create.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
abstract public class EppResponseDataCreate extends EppResponseData
{
	/**
	 * The ROID associated with the response data after creating
	 * an object sucessfully
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	protected String roid;

	/**
         * The creation date of the object created.
         *
	 * <P><B>Note:</B> The default value is the date when the <I>EppResponseDataCreate</I> object is created
	 *
         * @since EPP-1.0
	 */
	protected Calendar crDate;

	/**
	 * Gets ROID associated with the creation of an <code>EppObject</code>
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	public String getRoid()
	{
		return this.roid;
	}

	/**
	 * Sets ROID associated with the creation of an <code>EppObject</code>
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	public void setRoid( String roid )
	{
		this.roid = roid;
	}

	/**
	 * Gets creation date of the object created
	 *
         * @since EPP-1.0
	 */
	public Calendar getDateCreated()
	{
		return this.crDate;
	}

	/**
	 * Sets creation date of the object created
	 */
	public void setDateCreated( Calendar crDate )
	{
		this.crDate = crDate;
	}
}
