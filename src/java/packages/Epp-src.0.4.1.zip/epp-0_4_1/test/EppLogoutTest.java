/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.command.*;
import com.neulevel.epp.core.response.*;

import org.w3c.dom.*;

/**
 * The <code>EppLogoutTest</code> class tests functions of
 * <code>EppCommandLogout</code> commands.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class EppLogoutTest
{
	public static void main( String argv[] )
	{
		EppCommandLogout logout = new EppCommandLogout();
		System.out.println(logout);

		logout.setClientTransactionId("ABC-DEF-12345");
		System.out.println(logout);

		EppParser parser = new EppParser(logout.toString());

		if( parser.hasError() )
		{
			System.out.println(parser.getResult());
			System.exit(1);
		}

		Node epp = parser.getRootNode();
		EppCommand cmd = (EppCommand) EppCommand.fromXML(epp);
		if( cmd == null )
		{
			System.out.println("Error in fromXML");
			System.exit(1);
		}
		System.out.println(cmd);
	}
}
