/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
import com.neulevel.epp.core.*;
import com.neulevel.epp.core.command.*;
import com.neulevel.epp.core.response.*;

import org.w3c.dom.*;

/**
 * The <code>EppCheckTest</code> class tests functions of
 * <code>EppCommandCheck</code> commands.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
public class EppCheckTest
{
	public static void main( String argv[] )
	{
		testContact();
		testDomain();
		testHost();
		testSvcsub();
	}

	private static void testContact()
	{
		Node epp;
		EppCommandCheckContact cmd;
		EppCommandCheckContact newcmd;

		cmd = new EppCommandCheckContact();
		cmd.setClientTransactionId("ABC-DEF-12345");
		cmd.addId("CONTACT1-12345");
		cmd.addId("CONTACT2-12345");
		cmd.addId("CONTACT3-12345");
		cmd.addId("CONTACT4-12345");
		cmd.addId("CONTACT5-12345");
		System.out.println(cmd);

		EppParser parser = new EppParser(cmd.toString());
		if( parser.hasError() )
		{
			System.out.println(parser.getResult());
			System.exit(1);
		}

		epp = parser.getRootNode();
		newcmd = (EppCommandCheckContact) EppCommand.fromXML(epp);
		if( newcmd == null )
		{
			System.out.println("Error in fromXML");
			System.exit(1);
		}
		System.out.println(newcmd);
	}

	private static void testDomain()
	{
		Node epp;
		EppCommandCheckDomain cmd;
		EppCommandCheckDomain newcmd;

		cmd = new EppCommandCheckDomain();
		cmd.addName("example1.biz");
		cmd.addName("example2.biz");
		cmd.addName("example3.biz");
		cmd.addName("example4.biz");
		cmd.addName("example5.biz");
		cmd.setClientTransactionId("ABC-DEF-12345");
		System.out.println(cmd);

		EppParser parser = new EppParser(cmd.toString());
		if( parser.hasError() )
		{
			System.out.println(parser.getResult());
			System.exit(1);
		}

		epp = parser.getRootNode();
		newcmd = (EppCommandCheckDomain) EppCommand.fromXML(epp);
		if( newcmd == null )
		{
			System.out.println("Error in fromXML");
			System.exit(1);
		}
		System.out.println(newcmd);
	}

	private static void testHost()
	{
		Node epp;
		EppCommandCheckHost cmd;
		EppCommandCheckHost newcmd;

		cmd = new EppCommandCheckHost();
		cmd.addName("ns1.example.biz");
		cmd.addName("ns2.example.biz");
		cmd.addName("ns3.example.biz");
		cmd.addName("ns4.example.biz");
		cmd.addName("ns5.example.biz");
		cmd.setClientTransactionId("ABC-DEF-12345");
		System.out.println(cmd);

		EppParser parser = new EppParser(cmd.toString());
		if( parser.hasError() )
		{
			System.out.println(parser.getResult());
			System.exit(1);
		}

		epp = parser.getRootNode();
		newcmd = (EppCommandCheckHost) EppCommand.fromXML(epp);
		if( newcmd == null )
		{
			System.out.println("Error in fromXML");
			System.exit(1);
		}
		System.out.println(newcmd);
	}

	private static void testSvcsub()
	{
		Node epp;
		EppCommandCheckSvcsub cmd;
		EppCommandCheckSvcsub newcmd;

		cmd = new EppCommandCheckSvcsub();
		cmd.setClientTransactionId("ABC-DEF-12345");
		cmd.addId("SVCSUB1-12345");
		cmd.addId("SVCSUB2-12345");
		cmd.addId("SVCSUB3-12345");
		cmd.addId("SVCSUB4-12345");
		cmd.addId("SVCSUB5-12345");
		System.out.println(cmd);

		EppParser parser = new EppParser(cmd.toString());
		if( parser.hasError() )
		{
			System.out.println(parser.getResult());
			System.exit(1);
		}

		epp = parser.getRootNode();
		newcmd = (EppCommandCheckSvcsub) EppCommand.fromXML(epp);
		if( newcmd == null )
		{
			System.out.println("Error in fromXML");
			System.exit(1);
		}
		System.out.println(newcmd);
	}
}
