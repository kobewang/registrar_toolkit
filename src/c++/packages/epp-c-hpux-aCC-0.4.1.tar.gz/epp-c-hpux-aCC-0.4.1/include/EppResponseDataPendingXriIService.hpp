#if ! defined(EPPRESPONSEDATAPENDINGXRIISERVICE_HPP)	/* { */
#define	      EPPRESPONSEDATAPENDINGXRIISERVICE_HPP		   1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppResponseDataPending.hpp"

/**
 * This <code>EppResponseDataPendingXriIService</code> class implements EPP
 * Response Data entity for EPP Pending Actions of EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppResponseDataPendingXriIService : public EppResponseDataPending
{
private:
	DOMString   id;

public:
	/**
	 * Creates an <code>EppResponseDataPendingXriIService</code> object
	 *
	 * @param id the identifier of the <code>EppXriIService</code> object associated with the pending action
	 */
	EppResponseDataPendingXriIService( DOMString id )
	{
		this->id = id;
		this->paResult = false;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataPendingXriIService</code> object
	 *
	 * @param id the identifier of the <code>EppXriIService</code> object associated with the pending action
	 * @param result the boolean flag indicating if the pending action is a success or a failure
	 */
	EppResponseDataPendingXriIService( DOMString id, bool result )
	{
		this->id = id;
		this->paResult = result;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = null;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataPendingXriIService() {};

	/**
	 * Gets the identifier of the XRI i-service object associated with the pending action
	*/
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the identifier of the XRI i-service object associated with the pending action
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataPendingXriIService;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataPendingXriIService</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XRI I-Service object
	 *
	 * @param root root node for an <code>EppResponseDataPendingXriIService</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataPendingXriIService</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataPendingXriIService * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataPendingXriIService</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataPendingXriIService</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif	/*    EPPRESPONSEDATAPENDINGXRIISERVICE_HPP */	/* } */
