#if ! defined(EPPCOMMANDRENEW_HPP)    /* { */
#define       EPPCOMMANDRENEW_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include <time.h>
#include "EppCommand.hpp"
#include "EppPeriod.hpp"

/**
 * This <code>EppCommandRenew</code> class implements EPP Command Renew
 * entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppCommandRenew : public EppCommand
{
protected:
	/**
	 * The current expiration date of the registration for the EPP object
	 * to be renewed
	 */
	time_t      curExpDate;
	/**
	 * The new registration period for the the EPP object to be renewed
	 */
	EppPeriod * period;

public:
	/**
	 * Creates an <code>EppCommandRenew</code> object
	 */
	EppCommandRenew()
	{
		this->curExpDate = null;
		this->period = null;
	};

	/**
	 * Destructor
	 */
	virtual ~EppCommandRenew()
	{
		if( this->period != null )
		{
			delete this->period;
			this->period = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandRenew;
	};

	/**
	 * Gets the current expiration date of the object to be renewed
	 */
	time_t getCurrentExpireDate()
	{
		return this->curExpDate;
	};

	/**
	 * Sets the current expiration date of the object to be renewed
	 */
	void setCurrentExpireDate( time_t curExpDate )
	{
		this->curExpDate = curExpDate;
	};

	/**
	 * Gets the <code>EppPeriod</code> object containing the period
	 * to be renewed for the object
	 */
	EppPeriod * getPeriod()
	{
		return this->period;
	};

	/**
	 * Sets the <code>EppPeriod</code> object containing the period
	 * to be renewed for the object
	 */
	void setPeriod( EppPeriod& period )
	{
		if( this->period == null )
		{
			this->period = new EppPeriod();
		}
		*(this->period) = period;
	};

	/**
	 * Converts an XML element into an <code>EppCommandInfo</code> object.
	 * The caller of this method must make sure that the root node is of an
	 * EPP Command Info entity.
	 *
	 * @param root root node for an <code>EppCommandInfo</code> object
	 *             in XML format
	 *
	 * @return an <code>EppCommandInfo</code> object, or null if the node
	 *         is invalid
	 */
	static EppCommandRenew * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("renew"));
	};
};

#endif     /* EPPCOMMANDRENEW_HPP */  /* } */
