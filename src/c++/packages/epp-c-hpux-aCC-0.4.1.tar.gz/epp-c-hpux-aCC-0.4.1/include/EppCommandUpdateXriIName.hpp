#if ! defined(EPPCOMMANDUPDATEXRIINAME_HPP)    /* { */
#define       EPPCOMMANDUPDATEXRIINAME_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandUpdate.hpp"

/**
 * This <code>EppCommandUpdateXriIName</code> class implements EPP Command Update
 * entity for EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppCommandUpdateXriIName : public EppCommandUpdate
{
private:
	DOMString iname;

public:
	/**
	 * Creates an <code>EppCommandUpdateXriIName</code>
	 */
	EppCommandUpdateXriIName()
	{
		this->iname = null;
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandUpdateXriIName</code> given the
	 * i-name of the XRI i-name object
	 */
	EppCommandUpdateXriIName( DOMString iname )
	{
		this->iname = iname;
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandUpdateXriIName</code> given the
	 * i-name of the XRI i-name object and a client transaction id
	 */
	EppCommandUpdateXriIName( DOMString iname, DOMString xid )
	{
		this->iname = iname;
		this->clTRID = xid;
	};

	/**
	 * Destricutor
	 */
	~EppCommandUpdateXriIName() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandUpdateXriIName;
	};

	/**
	 * Gets the i-name of the XRI i-name object to be updated
	 */
	DOMString getIName()
	{
		return this->iname;
	};

	/**
	 * Sets the i-name of the XRI i-name object to be updated
	 */
	void setIName( DOMString iname )
	{
		this->iname = iname;
	};

	/**
	 * Converts the <code>EppCommandUpdateXriIName</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the 
	 *            <code>EppCommandUpdateXriIName</code> object
	 *
	 * @return an <code>DOM_Element</code> object 
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandUpdateXriIName</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Update entity for an EPP XRI I-Name object.
	 *
	 * @param root root node for an <code>EppCommandUpdateXriIName</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandUpdateXriIName</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandUpdateXriIName * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDUPDATEXRIINAME_HPP */  /* } */
