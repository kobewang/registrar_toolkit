#if ! defined(EPPCOMMANDTRANSFERSVCSUB_HPP)    /* { */
#define       EPPCOMMANDTRANSFERSVCSUB_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandTransfer.hpp"
#include "EppPeriod.hpp"

/**
 * This <code>EppCommandTransferSvcsub</code> class implements EPP Command
 * Transfer entity for EPP Svcsub objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $
 */
class EPP_EXPORT EppCommandTransferSvcsub : public EppCommandTransfer
{
private:
	DOMString id;
	DOMString userid;
	EppPeriod * period;
	DOMString service;

public:
	/**
	 * Creates an <code>EppCommandTransferSvcsub</code> object
	 */
	EppCommandTransferSvcsub()
	{
		this->id = null;
		this->userid = null;
		this->period = null;
		this->service = null;
	};

	/**
	 * Creates an <code>EppCommandTransferSvcsub</code> object for
	 * transfering a subscription object based on its id
	 */
	EppCommandTransferSvcsub( DOMString id )
	{
		this->id = id;
		this->userid = null;
		this->period = null;
		this->service = null;
	};

	/**
	 * Creates an <code>EppCommandTransferSvcsub</code> object for
	 * transfering a subscription object based on its id, given a client
	 * transaction id associated with operation
	 */
	EppCommandTransferSvcsub( DOMString id, DOMString xid )
	{
		this->id = id;
		this->userid = null;
		this->period = null;
		this->clTRID = xid;
		this->service = null;
	};

	/**
	 * Creates an <code>EppCommandTransferSvcsub</code> object for
	 * transfering a subscription object based on its id and with an
	 * extended expiration period
	 */
	EppCommandTransferSvcsub( DOMString id, EppPeriod& period )
	{
		this->id = id;
		this->userid = null;
		this->period = null;
		this->setPeriod(period);
		this->service = null;
	};

	/**
	 * Creates an <code>EppCommandTransferSvcsub</code> object for
	 * transfering a subscription object based on its id and with an
	 * extended expiration period and a client transaction id
	 * associated with operation
	 */
	EppCommandTransferSvcsub( DOMString id, EppPeriod& period, DOMString xid )
	{
		this->id = id;
		this->userid = null;
		this->period = null;
		this->clTRID = xid;
		this->setPeriod(period);
		this->service = null;
	};

	/**
	 * Destructor
	 */
	~EppCommandTransferSvcsub()
	{
		if( this->period != null )
		{
			delete this->period;
			this->period = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandTransferSvcsub;
	};

	/**
	 * Gets the id of the subscription object to be transferred
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the id of the subscription object to be transferred
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Gets the registration period of the domain object to be transferred
	 */
	EppPeriod * getPeriod()
	{
		return this->period;
	};

	/**
	 * Sets the registration period of the domain object to be transferred
	 */
	void setPeriod( EppPeriod& period )
	{
		if( this->period == null )
		{
			this->period = new EppPeriod();
		}
		*(this->period) = period;
	};

	/**
	 * Gets the user id that can be used for authorization purpose
	 */
	DOMString getUserId()
	{
		return this->userid;
	};

	/**
	 * Sets the user id that can be used for authorization purpose
	 */
	void setUserId( DOMString userid )
	{
		this->userid = userid;
	};

        /**
	 * Gets the service name
	 */
	DOMString getService()
	{
		return this->service;
	};

	/**
	 * Sets the service name
	 */
	void setService( DOMString service )
	{
		this->service = service;
	};

	/**
	 * Converts the <code>EppCommandTransferSvcsub</code> object into
	 * an XML element for an <code>EppPollable</code> object
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandTransferSvcsub</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXMLPoll( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts the <code>EppCommandTransferSvcsub</code> object into
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandTransferSvcsub</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an
	 * <code>EppCommandTransferSvcsub</code> object. The caller of this
	 * method must make sure that the root node is of an EPP Command
	 * Transfer entity for EPP Svcsub object.
	 *
	 * @param root root node for an <code>EppCommandTransferSvcsub</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandTransferSvcsub</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandTransferSvcsub * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDTRANSFERSVCSUB_HPP */  /* } */
