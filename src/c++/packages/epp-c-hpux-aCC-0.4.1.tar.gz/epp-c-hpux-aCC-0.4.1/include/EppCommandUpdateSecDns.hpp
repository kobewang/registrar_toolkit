#if ! defined(EPPCOMMANDUPDATESECDNS_HPP)    /* { */
#define       EPPCOMMANDUPDATESECDNS_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppExtension.hpp"
#include "EppSecDnsDsData.hpp"
#include <util/ValueVectorOf.hpp>

#define MAX_NUM_OF_DS_DATA	4

/**
 * This <code>EppCommandSecDns</code> class implements EPP CommandSecDns entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppCommandUpdateSecDns : public EppExtension
{
private:
	ValueVectorOf<EppSecDnsDsData> * addDsDataList;
	ValueVectorOf<EppSecDnsDsData> * chgDsDataList;
	ValueVectorOf<int>             * remKeyTagList;
	bool				 urgent;

	static const int		 OP_ADD;
	static const int		 OP_CHG;
	static const int		 OP_REM;

	/**
	 * Converts an XML element into an <code>EppSecDnsDsData</code> object list,
	 * or <code>key tag</code> list, The caller of this method must make sure that
	 * the root node contains a list of EPP SECDNS dsDataType objects
	 *
	 * @param root root node for a <code>add</code>, <code>chg</code> or <code>rem</code> tag
	 *        op flag indicating one of the operations: OP_ADD, OP_CHG, OP_REM.
	 *
	 * @return none
	 */
	void fromXML( const DOM_Node& root, const int op );

       /**
         * Converts a list of object into an XML format
         *
         * @param doc the XML <code>Document</code> object
         * @param root the element for attaching the child element, such as, "add", "chg", or "rem"
         * @param tag the tag/element name for the object, "add", "chg", or "rem"
         * @param dsDataList the list of <code>EppSecDnsDsData</code> objects
         * @param keyTagList the list of <code>Kay Tag</code> integers
         *
         * @return true if a child element is added
         */
	bool toXML( DOM_Document& doc, DOM_Element& root, const DOMString& tag, ValueVectorOf<EppSecDnsDsData> * dsDataList, ValueVectorOf<int> * keyTagList );

public:
	/**
	 * Creates an <code>EppCommandSecDns</code> object
	 */
	EppCommandUpdateSecDns()
	{
		this->addDsDataList = new ValueVectorOf<EppSecDnsDsData>(MAX_NUM_OF_DS_DATA);
		this->chgDsDataList = new ValueVectorOf<EppSecDnsDsData>(MAX_NUM_OF_DS_DATA);
		this->remKeyTagList = new ValueVectorOf<int>            (MAX_NUM_OF_DS_DATA);
		this->urgent        = false;
	};

	/**
	 * Destructor
	 */
	~EppCommandUpdateSecDns()
	{
		if( this->addDsDataList != null )
		{
			delete this->addDsDataList;
			this->addDsDataList = null;
		}
		if( this->chgDsDataList != null )
		{
			delete this->chgDsDataList;
			this->chgDsDataList = null;
		}
		if( this->remKeyTagList != null )
		{
			delete this->remKeyTagList;
			this->remKeyTagList = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandUpdateSecDns;
	};

	/**
	 * Gets the urgent update boolean flag
	 */
	bool getUrgentFlag()
	{
		return this->urgent;
	};

	/**
	 * Sets the urgent update boolean flag
	 */
	void setUrgentFlag( bool urgent )
	{
		this->urgent = urgent;
	};

	/**
	 * Adds DS Data to the list to be attached to a domain name
	 */
	void add( EppSecDnsDsData& dsData )
	{
                this->addDsDataList->addElement(dsData);
	};

	/**
	 * Gets the list of DS data to be attached to a domain name
	 */
	ValueVectorOf<EppSecDnsDsData> * getDsDataAdded()
	{
        	return this->addDsDataList;
	};

	/**
	 * Changes DS Data to the list to be attached to a domain name
	 */
	void change( EppSecDnsDsData& dsData )
	{
                this->chgDsDataList->addElement(dsData);
	};

	/**
	 * Gets the list of DS data to be changed to a domain name
	 */
	ValueVectorOf<EppSecDnsDsData> * getDsDataChanged()
	{
        	return this->chgDsDataList;
	};

	/**
	 * Adds key tag to the list of DS data to be detached from a domain name
	 */
	void remove( int keyTag )
	{
		keyTag = keyTag & 0xFFFF;
		this->remKeyTagList->addElement(keyTag);
	};

	/**
	 * Gets the list of key tags of DS data to be detached from a domain name
	 */
	ValueVectorOf<int> * getKeyTagRemoved()
	{
		return this->remKeyTagList;
	};

	/**
	 * Converts an XML element into an <code>EppCommandUpdateSecDns</code> object.
	 * The caller of this method must make sure that the root node is of
	 * EPP SECDNS updateType
	 *
	 * @param root root node for an <code>EppCommandUpdateSecDns</code> object in XML format
	 *
	 * @return an <code>EppCommandUpdateSecDns</code> object, or null if the node is invalid
	 */
	static EppCommandUpdateSecDns * fromXML( const DOM_Node& root );

	/**
	 * Converts the <code>EppCommandUpdateSecDns</code> object into an XML element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the <code>EppCommandUpdateSecDns</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("update"));
	};
};

#endif     /* EPPCOMMANDUPDATESECDNS_HPP */  /* } */
