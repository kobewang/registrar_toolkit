#if ! defined(EPPAUTHINFO_HPP)    /* { */
#define       EPPAUTHINFO_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppEntity.hpp"

/**
 * This <code>EppAuthInfo</code> class implements EPP AuthInfo entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppAuthInfo : public EppEntity
{
private:
	DOMString type;
	DOMString roid;
	DOMString value;

public:
	/**
	 * Authorization type "pw" for password
	 */
	static const char * TYPE_PW;
	/**
	 * Authorization type "ext" for extension (Not implemented yet)
	 */
	static const char * TYPE_EXT;

	/**
	 * Creates an <code>EppAuthInfo</code> object
	 */
	EppAuthInfo()
	{
		this->type = null;
		this->value = null;
		this->roid = null;
	};

	/**
	 * Creates an <code>EppAuthInfo</code> object
	 *
	 * @note the only type value is "pw", for password
	 */
	EppAuthInfo( DOMString type, DOMString value )
	{
		this->type = type;
		this->value = value;
		this->roid = null;
	};

	/**
	 * Creates an <code>EppAuthInfo</code> object with a ROID.
	 *
	 * @note the only type value is "pw", for password
	 */
	EppAuthInfo( DOMString type, DOMString value, DOMString roid )
	{
		this->type = type;
		this->value = value;
		this->roid = roid;
	};

	/**
	 * Destructor
	 */
	~EppAuthInfo() {};

	/**
	 * Gets the value associated with the authorization information
	 */
	DOMString getValue()
	{
		return this->value;
	};

	/**
	 * Gets the value associated with the authorization information
	 */
	void setValue( DOMString value )
	{
		this->value = value;
	};

	/**
	 * Gets the ROID of the authorization information
	 */
	DOMString getRoid()
	{
		return this->roid;
	};

	/**
	 * Sets the ROID of the authorization information
	 */
	void setRoid( DOMString roid )
	{
		this->roid = roid;
	};

	/**
	 * Gets the type of the authorization information
	 */
	DOMString getType()
	{
		return this->type;
	};

	/**
	 * Sets the type of the authorization information
	 */
	void setType( DOMString type )
	{
		this->type = type;
	};

	/**
 	 * Converts the <code>EppAuthInfo</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the <code>EppAuthInfo</code>
	 *            object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppAuthInfo</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP AuthInfo type.
	 *
	 * @param root root node for an <code>EppAuthInfo</code> object
	 *             in XML format
	 *
	 * @return an <code>EppAuthInfo</code> object, or null if the node
	 *         is invalid
	 */
	static EppAuthInfo * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("authInfo"));
	};
};

#endif     /* EPPAUTHINFO_HPP */  /* } */
