#if ! defined(EPPXRIEXTERNALSYNONYM_HPP)    /* { */
#define       EPPXRIEXTERNALSYNONYM_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppEntity.hpp"

/**
 * This <code>EppXriExternalSynonym</code> class defines external synonym
 * information associated with XRI authority objects.  It
 * implements XRI xsAddType and xsInfType defined
 * in the XRI authority schema file.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppXriExternalSynonym : public EppEntity
{
private:
	unsigned short int priority;
	DOMString          xs;

public:
	/**
	 * Default priority value - 10
	 */
	static const unsigned short int DEFAULT_PRIORITY;

	/**
	 * Creates an <code>EppXriExternalSynonym</code> object
	 */
	EppXriExternalSynonym()
	{
		this->priority = DEFAULT_PRIORITY;
		this->xs       = null;
	};

	/**
	 * Creates an <code>EppXriExternalSynonym</code> object with an extenal synonym
	 * and the default priority value
	 */
	EppXriExternalSynonym( DOMString xs )
	{
		this->priority = DEFAULT_PRIORITY;
		this->xs       = xs;
	};

	/**
	 * Creates an <code>EppXriExternalSynonym</code> object with an extenal synonym
	 * and a priority value
	 */
	EppXriExternalSynonym( DOMString xs, unsigned short int priority )
	{
		this->priority = priority;
		this->xs       = xs;
	};

	/**
	 * Destructor
	 */
	~EppXriExternalSynonym() {} ;

	/**
	 * Gets the priority value for this external synonym
	 */
	unsigned short int getPriority()
	{
		return this->priority;
	};

	/**
	 * Sets the priority value for this external synonym
	 */
	void setPriority( unsigned short int priority )
	{
		this->priority = priority;
	};

	/**
	 * Gets the XRI string of the external synonym
	 */
	DOMString getExternalSynonym()
	{
		return this->xs;
	}

	/**
	 * Sets the XRI string of the external synonym
	 */
	void setExternalSynonym( DOMString xs )
	{
		this->xs = xs;
	};

	/**
         * Converts the <code>EppXriExternalSynonym</code> object into an XML element
         *
         * @param doc the XML <code>DOM_Document</code> object
         * @param tag the tag/element name for the <code>EppXriExternalSynonym</code> object
         *
         * @return an <code>DOM_Element</code> object
         */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppXriExternalSynonym</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP XRI xsAddType or xsInfType.
	 *
	 * @param root root node for an <code>EppXriExternalSynonym</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriExternalSynonym</code> object, or null if the node is
	 *         invalid
	 */
	static EppXriExternalSynonym * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("xs"));
	};
};

#endif     /* EPPXRIEXTERNALSYNONYM_HPP */  /* } */
