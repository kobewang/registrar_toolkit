#if ! defined(EPPXRIISERVICE_HPP)    /* { */
#define       EPPXRIISERVICE_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppEntity.hpp"
#include "EppObject.hpp"
#include "EppPeriod.hpp"

/**
 * This <code>EppXriIService</code> class implements EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppXriIService : public EppObject
{
private:
	DOMString                  id;
	DOMString                  type;
	DOMString                  authId;
	EppPeriod                * period; 
	ValueVectorOf<DOMString> * uri;

public:
	/**
	 * I-Service status - clientDeleteProhibited
	 */
	static const char * STATUS_CLIENT_DELETE_PROHIBITED;
	/**
	 * I-Service status - clientHold
	 */
	static const char * STATUS_CLIENT_HOLD;
	/**
	 * I-Service status - clientRenewProhibited
	 */
	static const char * STATUS_CLIENT_RENEW_PROHIBITED;
	/**
	 * I-Service status - clientUpdateProhibited
	 */
	static const char * STATUS_CLIENT_UPDATE_PROHIBITED;
	/**
	 * I-Service status - ok
	 */
	static const char * STATUS_OK;
	/**
	 * I-Service status - pendingCreate
	 */
	static const char * STATUS_PENDING_CREATE;
	/**
	 * I-Service status - pendingDelete
	 */
	static const char * STATUS_PENDING_DELETE;
	/**
	 * I-Service status - pendingTransfer
	 */
	static const char * STATUS_PENDING_TRANSFER;
	/**
	 * I-Service status - pendingUpdate
	 */
	static const char * STATUS_PENDING_UPDATE;
	/**
	 * I-Service status - serverDeleteProhibited
	 */
	static const char * STATUS_SERVER_DELETE_PROHIBITED;
	/**
	 * I-Service status - serverHold
	 */
	static const char * STATUS_SERVER_HOLD;
	/**
	 * I-Service status - serverRenewProhibited
	 */
	static const char * STATUS_SERVER_RENEW_PROHIBITED;
	/**
	 * I-Service status - serverUpdateProhibited
	 */
	static const char * STATUS_SERVER_UPDATE_PROHIBITED;

	/**
	 * Creates an <code>EppXriIService</code> object
	 */
	EppXriIService()
	{
		this->id         = null;
		this->type       = null;
		this->authId     = null;
		this->period     = null;
		this->uri        = new ValueVectorOf<DOMString>(3);
	};

	/**
	 * Creates an <code>EppXriIService</code> object with an XRI i-service identifier
	 */
	EppXriIService( DOMString id )
	{
		this->id         = id;
		this->type       = null;
		this->authId     = null;
		this->period     = null;
		this->uri        = new ValueVectorOf<DOMString>(3);
	};

	/**
	 * Destructor
	 */
	~EppXriIService()
	{
		EppObject::freeCommon();
		if( this->period != null )
		{
			delete this->period;
			this->period = null;
		}
		if( this->uri != null )
		{
			delete this->uri;
			this->uri = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
        virtual int getEntityType()
	{
		return EppEntity::TYPE_EppXriIService;
	};

	/**
	 * Gets the i-service identifier
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the i-service identifier
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Sets the identifier of the superorindate XRI authority object,
	 * and authInfo associated with the authority, if any
	 */
	void setAuthority( DOMString authId, EppAuthInfo authInfo )
	{
		this->authId   = authId;
		this->setAuthInfo(authInfo);
	};

	/**
	 * Gets the identifier of the superordinate XRI authority object
	 */
	DOMString getAuthorityId()
	{
		return this->authId;
	};

	/**
	 * Sets the identifier of the superordinate XRI authority object
	 */
	void setAuthorityId( DOMString authId )
	{
		this->authId = authId;
	};

	/**
	 * Gets i-service type
	 */
	DOMString getType()
	{
		return this->type;
	};

	/**
	 * Sets i-service type
	 */
	void setType( DOMString type )
	{
		this->type = type;
	};

	/**
	 * Gets the list of URIs associated with the XRI i-service object
	 */
	ValueVectorOf<DOMString> * getURI()
	{
		return this->uri;
	};

	/**
	 * Adds a URL to the list of URIs associated with the XRI i-service object
	 */
	void addURI( DOMString uri )
	{
		this->uri->addElement(uri);
	};

	/**
	 * Gets registration period for the i-service
	 */
	EppPeriod * getPeriod()
	{
		return this->period;
	};

	/**
	 * Sets registration period for the i-service
	 */
	void setPeriod( EppPeriod period )
	{
		if( this->period == null )
		{
			this->period = new EppPeriod();
		}
		*(this->period) = period;
	};

	/**
	 * Converts the <code>EppXriIService</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the <code>EppXriIService</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppXriIService</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP I-Service type.
	 *
	 * @param root root node for an <code>EppXriIService</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriIService</code> object, or null if the node
	 *         is invalid
	 */
	static EppXriIService * fromXML( const DOM_Node& root );

#if 0
	/**
	 * Creates an <code>EppCommandDeleteXriIService</code> object for
	 * deleting an EPP XRI I-Service object from the registry.
	 *
	 * @param id  the identifier of the XRI i-service object to be deleted
	 * @param xid the client transaction id associated with the operation
	 */
	public static EppCommandDeleteXriIService delete( String id, String xid )
	{
		return new EppCommandDeleteXriIService(id, xid);
	}

	/**
	 * Creates an <code>EppCommandInfoXriIService</code> object for
	 * querying the details of an EPP XRI I-Service object
	 *
	 * @param id  the identifier of the XRI i-service object to be queried
	 * @param xid the client transaction id associated with the operation
	 */
	public static EppCommandInfoXriIService info( String id, String xid )
	{
		return new EppCommandInfoXriIService(id, xid);
	}

	/**
	 * Creates an <code>EppCommandCheckXriIService</code> object for
	 * checking the existance of EPP XRI I-Service objects in the registry.
	 * Identifiers of EPP XRI I-Service objects can be added via the
	 * <code>add</code> or <code>addIService</code> methods.
	 *
	 * @param xid  the client transaction id associated with the operation
	 */
	public static EppCommandCheckXriIService check( String xid )
	{
		return new EppCommandCheckXriIService(xid);
	}

	/**
	 * Creates an <code>EppCommandRenewXriIService</code> object for
	 * renewing the registration of an EPP XRI I-Service object in the registry.
	 *
	 * @param id         the identifier of the XRI i-service object to be renewed
	 * @param curExpDate the current expiration date of the svcsub object
	 * @param period     the new registration period of the svcsub object,
	 *                   or null if using the value specified by the
	 *                   registry
	 * @param xid        the client transaction id associated with the
	 *                   operation
	 */
	public static EppCommandRenewXriIService renew( String id, Calendar curExpDate, EppPeriod period, String xid )
	{
		return new EppCommandRenewXriIService(id, curExpDate, period, xid);
	}

	/**
	 * Creates an <code>EppCommandUpdateXriIService</code> object for
	 * updating an EPP I-Service object in the registry. The actual update
	 * information should be specified via the various methods defined
	 * for the <code>EppCommandUpdateXriIService</code> object.
	 *
	 * @param id  the identifier of the XRI i-service object to be updated
	 * @param xid the client transaction id associated with the operation
	 */
	public static EppCommandUpdateXriIService update( String id, String xid )
	{
		return new EppCommandUpdateXriIService(id, xid);
	}
#endif

	DOMString toString()
	{
		return EppEntity::toString(DOMString("xriISV"));
	};
};

#endif     /* EPPXRIISERVICE_HPP */  /* } */
