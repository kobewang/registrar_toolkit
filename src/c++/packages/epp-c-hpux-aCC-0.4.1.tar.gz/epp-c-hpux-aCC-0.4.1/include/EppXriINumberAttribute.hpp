#if ! defined(EPPXRIINUMBERATTRIBUTE_HPP)    /* { */
#define       EPPXRIINUMBERATTRIBUTE_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppEntity.hpp"

/**
 * This <code>EppXriINumberAttribute</code> class defines i-numbers
 * information associated with XRI authority objects.  It
 * implements XRI inumberType defined
 * in the XRI authority schema file.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppXriINumberAttribute : public EppEntity
{
protected:
	/**
	 * Default priority value - 10
	 */
	static const unsigned short int DEFAULT_PRIORITY;

private:
	DOMString          inumber;
	unsigned short int priority;

public:
	/**
	 * Creates an <code>EppXriINumberAttribute</code> object
	 */
	EppXriINumberAttribute()
	{
		this->inumber  = null;
		this->priority = DEFAULT_PRIORITY;
	};

	/**
	 * Creates an <code>EppXriINumberAttribute</code> object with an identifier
	 */
	EppXriINumberAttribute( DOMString inumber, unsigned short int priority )
	{
		this->inumber  = inumber;
		this->priority = priority;
	};

	/**
	 * Destructor
	 */
	~EppXriINumberAttribute() {} ;

	/**
	 * Gets the i-number
	 */
	DOMString getINumber()
	{
		return this->inumber;
	};

	/**
	 * Sets the i-number
	 */
	void setINumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Gets the priority value for this i-number
	 */
	unsigned short int getPriority()
	{
		return this->priority;
	};

	/**
	 * Sets the priority value for this i-number
	 */
	void setPriority( unsigned short int priority )
	{
		this->priority = priority;
	};

	/**
         * Converts the <code>EppXriINumberAttribute</code> object into an XML element
         *
         * @param doc the XML <code>DOM_Document</code> object
         * @param tag the tag/element name for the <code>EppXriINumberAttribute</code> object
         *
         * @return an <code>DOM_Element</code> object
         */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppXriINumberAttribute</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP XRI xriAU:inumberType.
	 *
	 * @param root root node for an <code>EppXriINumberAttribute</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriINumberAttribute</code> object, or null if the node is
	 *         invalid
	 */
	static EppXriINumberAttribute * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("inumber"));
	};
};

#endif     /* EPPXRIINUMBERATTRIBUTE_HPP */  /* } */
