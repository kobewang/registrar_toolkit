#if        ! defined(BIZACCOUNT_HPP)    /* { */
#define              BIZACCOUNT_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#if ! defined(EPP_EXPORT)    /* { */
#define       EPP_EXPORT
#endif     /* EPP_EXPORT) */ /* } */

/**
 * This <code>BizAccount</code> class defines various constants and methods
 * related to the BIZaccount service.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $
 */
class EPP_EXPORT BizAccount
{
public:
	/**
	 * Service ID for BIZ Account
	 */
	static const char * ID;
	/**
	 * Service parameter for distribution list, which is a list of
	 * email addresses
	 *
	 * @note this &lt;param&gt; can have zero or multiple instances. It can
	 *       be supplied via the &lt;create&gt; command and can be added
	 *       or removed via the &lt;update&gt; command
	 */
	static const char * PARAM_DISTLIST;
	/**
	 * Service parameter for the preferred language used in service
	 * notification. The value associated with this parameter is defined
	 * by the registry. The following is a list of languages supported:
	 * <UL>
	 *     <LI>English</LI>
	 *     <LI>Chinese</LI>
	 *     <LI>French</LI>
	 *     <LI>German</LI>
	 *     <LI>Japanese</LI>
	 *     <LI>Korean</LI>
	 *     <LI>Spanish</LI>
	 *     <!--LI>Arabic</LI>
	 *     <LI>Danish</LI>
	 *     <LI>Italian</LI>
	 *     <LI>Norwegian</LI>
	 *     <LI>Portugese</LI-->
	 * </UL>
	 *
	 * @note this &lt;param&gt; can have only one instance. It is required
	 *       in the &lt;create&gt; command and can be changed by removing
	 *       and adding this &lt;param&gt; in a single &lt;update&gt; command 
	 */
	static const char * PARAM_LANGPREF;
	/**
	 * Service parameter for other services associated with the account.
	 * This parameter value is to be set by the registry server only
	 *
	 * @note this &lt;param&gt; can have zero or multiple instances and can be
	 *       returned in the response of an &lt;info&gt; command
	 */
	static const char * PARAM_SVCLIST;
};

#endif  /* ! defined(BIZACCOUNT_HPP) */ /* } */
