#if ! defined(EPPCOMMANDUPDATEXRIISERVICE_HPP)    /* { */
#define       EPPCOMMANDUPDATEXRIISERVICE_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandUpdate.hpp"

/**
 * This <code>EppCommandUpdateXriIService</code> class implements EPP Command Update
 * entity for EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppCommandUpdateXriIService : public EppCommandUpdate
{
private:
	DOMString id;

public:
	/**
	 * Creates an <code>EppCommandUpdateXriIService</code>
	 */
	EppCommandUpdateXriIService()
	{
		this->id = null;
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandUpdateXriIService</code> given the
	 * identifier of the XRI i-service object
	 */
	EppCommandUpdateXriIService( DOMString id )
	{
		this->id = id;
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandUpdateXriIService</code> given the
	 * identifier of the XRI i-service object and a client transaction id
	 */
	EppCommandUpdateXriIService( DOMString id, DOMString xid )
	{
		this->id = id;
		this->clTRID = xid;
	};

	/**
	 * Destricutor
	 */
	~EppCommandUpdateXriIService() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandUpdateXriIService;
	};

	/**
	 * Gets the identifier of the XRI i-service object to be updated
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the identifier of the XRI i-service object to be updated
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Converts the <code>EppCommandUpdateXriIService</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the 
	 *            <code>EppCommandUpdateXriIService</code> object
	 *
	 * @return an <code>DOM_Element</code> object 
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandUpdateXriIService</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Update entity for an EPP XRI I-Service object.
	 *
	 * @param root root node for an <code>EppCommandUpdateXriIService</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandUpdateXriIService</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandUpdateXriIService * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDUPDATEXRIISERVICE_HPP */  /* } */
