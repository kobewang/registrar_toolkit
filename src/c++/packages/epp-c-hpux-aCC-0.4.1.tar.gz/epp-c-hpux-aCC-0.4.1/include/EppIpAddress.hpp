#if ! defined(EPPIPADDRESS_HPP)    /* { */
#define       EPPIPADDRESS_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppEntity.hpp"

/**
 * This <code>EppIpAddress</code> class implements EPP IP Address entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppIpAddress : public EppEntity
{
private:
	DOMString ip;
	DOMString address;

public:
	/**
	 * IP address type for "v4"
	 */
	static const char * TYPE_V4;

	/**
	 * IP address type for "v6"
	 */
	static const char * TYPE_V6;

	/**
	 * Creates an <code>EppAddress</code> object
	 */
	EppIpAddress()
	{
		this->address = null;
		this->ip = null;
	};

	/**
	 * Creates an <code>EppAddress</code> object with the default
	 * address type, "v4"
	 */
	EppIpAddress( DOMString address )
	{
		this->address = address;
		this->ip = null;
	};

	/**
	 * Creates an <code>EppAddress</code> object with an address type,
	 * either "v4" (default) or "v6"
	 */
	EppIpAddress( DOMString address, DOMString type )
	{
		this->address = address;
		this->ip = type;
	};

	/**
	 * Destructor
	 */
	~EppIpAddress() {};

	/**
	 * Gets the IP address type, either "v4" or "v6"
	 */
	DOMString getType()
	{
		return this->ip;
	};

	/**
	 * Sets the IP address type, either "v4" or "v6"
	 */
	void setType( DOMString type )
	{
		this->ip = type;
	};

	/**
	 * Gets the IP address
	 */
	DOMString getAddress()
	{
		return this->address;
	};

	/**
	 * Sets the IP address
	 */
	void setAddress( DOMString address )
	{
		this->address = address;
	};

	/**
	 * Converts the <code>EppIpAddress</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the <code>EppIpAddress</code>
	 *              object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppIpAddress</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP IP Address type.
	 *
	 * @param root root node for an <code>EppIpAddress</code> object
	 *             in XML format
	 *
	 * @return an <code>EppIpAddress</code> object, or null if the node
	 *         is invalid
	 */
	static EppIpAddress * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("address"));
	};
};

#endif     /* EPPIPADDRESS_HPP */  /* } */
