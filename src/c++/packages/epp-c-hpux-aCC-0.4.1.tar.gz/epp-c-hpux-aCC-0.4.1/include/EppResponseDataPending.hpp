#if ! defined(EPPRESPONSEDATAPENDING_HPP)	/* { */
#define	      EPPRESPONSEDATAPENDING_HPP	   1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include <time.h>
#include "EppResponseData.hpp"
#include "EppTransactionId.hpp"

/**
 * This <code>EppResponseDataPending</code> class implements EPP
 * Response Data entity for EPP Pending Actions on EPP objects.
 *
 * @since EPP-1.0
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppResponseDataPending : public EppResponseData
{
protected:
	/**
	 * The result of the pending action, true for success, false for failure
	 */
	bool             paResult;

	/**
	 * The transaction id associated with the pending action
	 */
	EppTransactionId paTRID;

	/**
	 * The date when the pending action is processed
	 */
	time_t           paDate;

	/**
	 * Converts shared <code>EppResponseDataPending</code> component into
	 * XML elements
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param body the XML <code>DOM_Element</code> to be attached
	 */
	void toXMLCommon( DOM_Document& doc, DOM_Element& body );

	/**
	 * Converts shared <code>EppResponseDataPending</code> components from
	 * XML format.
	 * 
	 * @param node the node of a shared component
	 * @param name the name of the node of a shared component
	 * @param ns   the object namespace of a shared component
	 */
	void fromXMLCommon( const DOM_Node& node, const DOMString& name, const DOMString& ns );

public:
	/**
	 * Constructor
	 */
	EppResponseDataPending()
	{
		this->paResult	= false;
		this->paDate	= 0;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
	};

	/**
	 * Destructor
	 */
	virtual ~EppResponseDataPending() {};

	/**
	 * Gets the pending action result, true for success, false for failure
	 */
	bool getResult()
	{
		return this->paResult;
	};

	/**
	 * Gets the pending action result, true for success, false for failure
	 */
	void setResult( bool paResult )
	{
		this->paResult = paResult;
	};
	
	/**
	 * Gets the transaction id asssociated with the pending action
	 */
	EppTransactionId getTransactionId()
	{
		return this->paTRID;
	};

	/**
	 * Sets the transaction id asssociated with the pending action
	 */
	void setTransactionId( EppTransactionId paTRID )
	{
		this->paTRID = paTRID;
	};

	/**
	 * Gets the date when the pending action is processed
	 */
	time_t getDate()
	{
		return this->paDate;
	};

	/**
	 * Sets the date when the pending action is processed
	 */
	void setDate( time_t paDate )
	{
		this->paDate = paDate;
	};
};

#endif	/*    EPPRESPONSEDATAPENDING_HPP */	/* } */
