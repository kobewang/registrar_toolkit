#if ! defined(EPPTRANSACTIONID_HPP)    /* { */
#define       EPPTRANSACTIONID_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppEntity.hpp"

/**
 * This <code>EppTransactionId</code> class implements EPP trIDType entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppTransactionId : public EppEntity
{
private:
	DOMString clTRID;
	DOMString svTRID;

public:
	/**
	 * Creates an <code>EppTransactionId</code> object
	 */
	EppTransactionId()
	{
		this->clTRID = null;
		this->svTRID = null;
	};

	/**
	 * Creates an <code>EppTransactionId</code> object, given only
	 * service transaction id
	 *
	 * @param serviceXID service transaction id
	 */
	EppTransactionId( DOMString serviceXID )
	{
		this->clTRID = null;
		this->svTRID = serviceXID;
	};

	/**
	 * Creates an <code>EppTransactionId</code> object, given the client
	 * transaction id and service transaction id
	 *
	 * @param clientXID client transaction id
	 * @param serviceXID service transaction id
	 */
	EppTransactionId( DOMString clientXID, DOMString serviceXID )
	{
		this->clTRID = clientXID;
		this->svTRID = serviceXID;
	};

	/**
	 * Destructor
	 */
	~EppTransactionId() {};

	/**
	 * Gets client transaction id
	 */
	DOMString getClientTransactionId()
	{
		return this->clTRID;
	};

	/**
	 * Sets client transaction id
	 */
	void setClientTransactionId( DOMString clientXID )
	{
		this->clTRID = clientXID;
	};

	/**
	 * Gets service transaction id
	 */
	DOMString getServiceTransactionId()
	{
		return this->svTRID;
	};

	/**
	 * Sets service transaction id
	 */
	void setServiceTransactionId( DOMString serviceXID )
	{
		this->svTRID = serviceXID;
	};

	/**
	 * Converts the <code>EppTransactionId</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the <code>EppTransactionId</code>
	 *            object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag )
	{
		return toXML(doc, tag, false);
	};

	/**
	 * Converts the <code>EppTransactionId</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the <code>EppTransactionId</code>
	 *            object
	 * @param nsflag the flag indicating if "epp" name space prefix is reqired
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag, bool nsflag );

	/**
	 * Converts an XML element into an <code>EppTransactionId</code> object.
	 * The caller of this method must make sure that the root node is of the
	 * EPP trIDType
	 *
	 * @param root root node for an <code>EppTransactionId</code> object
	 *             in XML format
	 *
	 * @return an <code>EppTransactionId</code> object, or null if the node
	 *         is invalid
	 */
	static EppTransactionId * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("trID"));
	};
};

#endif     /* EPPTRANSACTIONID_HPP */  /* } */
