#if ! defined(EPPRESPONSEDATAPENDINGSVCSUB_HPP)	/* { */
#define	      EPPRESPONSEDATAPENDINGSVCSUB_HPP		   1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppResponseDataPending.hpp"

/**
 * This <code>EppResponseDataPendingSvcsub</code> class implements EPP
 * Response Data entity for EPP Pending Actions of EPP Svcsub objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppResponseDataPendingSvcsub : public EppResponseDataPending
{
private:
	DOMString   id;
	DOMString   service;

public:
	/**
	 * Creates an <code>EppResponseDataPendingSvcsub</code> object
	 *
	 * @param id the id of the <code>EppSvcsub</code> object associated with the pending action
	 */
	EppResponseDataPendingSvcsub( DOMString id )
	{
		this->id = id;
		this->service = null;
		this->paResult = false;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataPendingSvcsub</code> object
	 *
	 * @param id the id of the <code>EppSvcsub</code> object associated with the pending action
	 * @param result the boolean flag indicating if the pending action is a success or a failure
	 */
	EppResponseDataPendingSvcsub( DOMString id, bool result )
	{
		this->id = id;
		this->service = null;
		this->paResult = result;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = null;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataPendingSvcsub() {};

	/**
	 * Gets the id of the svcsub object associated with the pending action
	*/
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the id of the svcsub object associated with the pending action
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

        /**
	 * Gets the service name
	 */
	DOMString getService()
	{
		return this->service;
	};

	/**
	 * Sets the service name
	 */
	void setService( DOMString service )
	{
		this->service = service;
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataPendingSvcsub;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataPendingSvcsub</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP Svcsub object
	 *
	 * @param root root node for an <code>EppResponseDataPendingSvcsub</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataPendingSvcsub</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataPendingSvcsub * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataPendingSvcsub</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataPendingSvcsub</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif	/*    EPPRESPONSEDATAPENDINGSVCSUB_HPP */	/* } */
