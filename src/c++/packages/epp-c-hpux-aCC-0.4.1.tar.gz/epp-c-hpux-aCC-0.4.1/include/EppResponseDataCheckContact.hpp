#if ! defined(EPPRESPONSEDATACHECKCONTACT_HPP)    /* { */
#define       EPPRESPONSEDATACHECKCONTACT_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppResponseDataCheck.hpp"

/**
 * This <code>EppResponseDataCheckContact</code> class implements EPP
 * Response Data entity for EPP Command Check of EPP Contact objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppResponseDataCheckContact : public EppResponseDataCheck
{
public:
	/**
	 * Creates an <code>EppResponseDataCheckContact</code> object
	 */
	EppResponseDataCheckContact() {};

	/**
	 * Destructor
	 */
	~EppResponseDataCheckContact() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCheckContact;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCheckContact</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP Contact object.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCheckContact</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCheckContact</code> object, or null
	 *         if the node is invalid
	 */
	static EppResponseDataCheckContact * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataCheckContact</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCheckContact</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATACHECKCONTACT_HPP */  /* } */
