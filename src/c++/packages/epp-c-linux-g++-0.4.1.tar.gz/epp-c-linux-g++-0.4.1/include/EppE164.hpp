#if ! defined(EPPE164_HPP)    /* { */
#define       EPPE164_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppEntity.hpp"

/**
 * This <code>EppE164</code> class implements EPP e164Type, which is
 * the ITU E.164 format for telephone numbers, plus extension.
 *
 * <P>An E.164 telephone number consists of 4 parts, with a maximum length
 * of 17 characters:
 * <UL>
 * <LI>A leading plus ("+") sign,</LI>
 * <LI>A up to 3-dight country code,</LI>
 * <LI>A period (".") sign</LI>
 * <LI>A up to 12-dight phoner number (for EPP-04, it is a 10-digit, and is extended by NeuLevel to 12)</LI>
 * </UL>
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppE164 : public EppEntity
{
private:
	DOMString number;
	DOMString extension;

public:
	/**
	 * Creates an <code>EppE164</code> object
	 */
	EppE164()
	{
		this->number = null;
		this->extension = null;
	};

	/**
	 * Creates an <code>EppE164</code> object without an extension
	 */
	EppE164( DOMString number )
	{
		this->number = number;
		this->extension = null;
	};

	/**
	 * Creates an <code>EppE164</code> object with an extension
	 */
	EppE164( DOMString number, DOMString extension )
	{
		this->number = number;
		this->extension = extension;
	};

	/**
	 * Destructor
	 */
	~EppE164() {};

	/**
	 * Gets the phone number
	 */
	DOMString getNumber()
	{
		return this->number;
	};

	/**
	 * Sets the phone number
	 */
	void setNumber( DOMString number )
	{
		this->number = number;
	};

	/**
	 * Gets the extension of the phone number, if any
	 */
	DOMString getExtension()
	{
		return this->extension;
	};

	/**
	 * Sets the extension of the phone number
	 */
	void setExtension( DOMString extension )
	{
		this->extension = extension;
	};

	/**
	 * Converts the <code>EppE164</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the <code>EppE164</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppE164</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP E164 type.
	 *
	 * @param root root node for an <code>EppE164</code> object
	 *             in XML format
	 *
	 * @return an <code>EppE164</code> object, or null if the node
	 *         is invalid
	 */
	static EppE164 * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("e164"));
	};
};

#endif     /* EPPE164_HPP */  /* } */
