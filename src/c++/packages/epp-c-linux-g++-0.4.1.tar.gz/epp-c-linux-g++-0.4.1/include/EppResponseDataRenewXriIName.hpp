#if ! defined(EPPRESPONSEDATARENEWINAME_HPP)    /* { */
#define       EPPRESPONSEDATARENEWINAME_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include <time.h>
#include "EppResponseDataRenew.hpp"

/**
 * This <code>EppResponseDataRenewXriIName</code> class implements EPP
 * Response Data entity for EPP Command Renew of EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppResponseDataRenewXriIName : public EppResponseDataRenew
{
private:
	DOMString iname;
	time_t    exDate;

public:
	/**
	 * Creates an <code>EppResponseDataRenewXriIName</code> object
	 *
	 * @param iname the i-name of the XRI i-name object renewed
	 */
	EppResponseDataRenewXriIName()
	{
		this->iname = null;
		this->roid = null;
		this->exDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataRenewXriIName</code> object
	 *
	 * @param iname the i-name of the XRI i-name object renewed
	 */
	EppResponseDataRenewXriIName( DOMString iname )
	{
		this->iname = iname;
		this->roid = null;
		this->exDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataRenewXriIName</code> object
	 *
	 * @param iname the i-name of the XRI i-name object renewed
	 * @param exDate the expiration date of the XRI i-name
	 *               object renewed
	 */
	EppResponseDataRenewXriIName( DOMString iname, time_t exDate )
	{
		this->iname = iname;
		this->roid = null;
		this->exDate = exDate;
	};

	/**
	 * Renews an <code>EppResponseDataRenewXriIName</code> object
	 *
	 * @param iname the iname of the <code>EppXriIName</code> object renewed
	 * @param roid the ROID of the <code>EppXriIName</code> object renewed
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	EppResponseDataRenewXriIName( DOMString iname, DOMString roid )
	{
		this->iname = iname;
		this->roid = roid;
		this->exDate = 0;
	};

	/**
	 * Renews an <code>EppResponseDataRenewXriIName</code> object
	 *
	 * @param iname   the iname of the <code>EppXriIName</code> object renewed
	 * @param roid   the ROID of the <code>EppXriIName</code> object renewed
	 * @param exDate the expiration date of the <code>EppXriIName</code>
	 *               object renewed
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	EppResponseDataRenewXriIName( DOMString iname, DOMString roid, time_t exDate )
	{
		this->iname = iname;
		this->roid = roid;
		this->exDate = exDate;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataRenewXriIName() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataRenewXriIName;
	};

	/**
	 * Gets the iname of the XRI i-name renewed
	 */
	DOMString getIName()
	{
		return this->iname;
	};

	/**
	 * Sets the iname of the XRI i-name renewed
	 */
	void setIName( DOMString iname )
	{
		this->iname = iname;
	};

	/**
	 * Gets expiration date of the XRI i-name renewed
	 */
	time_t getDateExpired()
	{
		return this->exDate;
	};

	/**
	 * Sets expiration date of the XRI i-name renewed
	 */
	void setDateExpired( time_t exDate )
	{
		this->exDate = exDate;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataRenewXriIName</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XRI I-Name object
	 *
	 * @param root root node for an <code>EppResponseDataRenewXriIName</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataRenewXriIName</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataRenewXriIName * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataRenewXriIName</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataRenewXriIName</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATARENEWINAME_HPP */  /* } */
