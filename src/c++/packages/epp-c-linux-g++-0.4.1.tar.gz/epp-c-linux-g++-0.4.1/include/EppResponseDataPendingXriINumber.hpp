#if ! defined(EPPRESPONSEDATAPENDINGXRIINUMBER_HPP)	/* { */
#define	      EPPRESPONSEDATAPENDINGXRIINUMBER_HPP		   1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppResponseDataPending.hpp"

/**
 * This <code>EppResponseDataPendingXriINumber</code> class implements EPP
 * Response Data entity for EPP Pending Actions of EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppResponseDataPendingXriINumber : public EppResponseDataPending
{
private:
	DOMString   inumber;

public:
	/**
	 * Creates an <code>EppResponseDataPendingXriINumber</code> object
	 *
	 * @param inumber the i-number of the <code>EppXriINumber</code> object associated with the pending action
	 */
	EppResponseDataPendingXriINumber( DOMString inumber )
	{
		this->inumber = inumber;
		this->paResult = false;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataPendingXriINumber</code> object
	 *
	 * @param inumber the i-number of the <code>EppXriINumber</code> object associated with the pending action
	 * @param result the boolean flag indicating if the pending action is a success or a failure
	 */
	EppResponseDataPendingXriINumber( DOMString inumber, bool result )
	{
		this->inumber = inumber;
		this->paResult = result;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = null;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataPendingXriINumber() {};

	/**
	 * Gets the i-number of the XRI i-number object associated with the pending action
	*/
	DOMString getINumber()
	{
		return this->inumber;
	};

	/**
	 * Sets the i-number of the XRI i-number object associated with the pending action
	 */
	void setINumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataPendingXriINumber;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataPendingXriINumber</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XRI I-Number object
	 *
	 * @param root root node for an <code>EppResponseDataPendingXriINumber</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataPendingXriINumber</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataPendingXriINumber * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataPendingXriINumber</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataPendingXriINumber</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif	/*    EPPRESPONSEDATAPENDINGXRIINUMBER_HPP */	/* } */
