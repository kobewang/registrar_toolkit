#if ! defined(EPPCOMMANDCHECKXRIISERVICE_HPP)    /* { */
#define       EPPCOMMANDCHECKXRIISERVICE_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandCheck.hpp"

#define	MAX_NUM_OF_XRIISERVICES	16

/**
 * This <code>EppCommandCheckXriIService</code> class implements EPP Command Check
 * entity for EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppCommandCheckXriIService : public EppCommandCheck
{
private:
	ValueVectorOf<DOMString> * ids;

public:
	/**
	 * Creates an <code>EppCommandCheckXriIService</code> object
	 */
	EppCommandCheckXriIService()
	{
		this->ids = new ValueVectorOf<DOMString>(MAX_NUM_OF_XRIISERVICES);
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandCheckXriIService</code> object, given a
	 * client transaction id associated with the operation
	 */
	EppCommandCheckXriIService( DOMString xid )
	{
		this->ids = new ValueVectorOf<DOMString>(MAX_NUM_OF_XRIISERVICES);
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandCheckXriIService()
	{
		if( this->ids != null )
		{
			delete this->ids;
			this->ids = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandCheckXriIService;
	};

	/**
	 * Gets the list of the identifiers of the XRI i-service objects to be checked
	 */
	ValueVectorOf<DOMString> * getId()
	{
		return this->ids;
	};

	/**
	 * Gets the list of the identifiers of the XRI i-service objects to be checked.
	 *
	 * <P><B>Note:</B> This is an alias for <code>getId</code>
	 */
	ValueVectorOf<DOMString> * get()
	{
		return this->getId();
	};

	/**
	 * Adds the identifier f an XRI i-service object to the list of identifiers of XRI i-service
	 * objects be checked
	 */
	void addId( DOMString id )
	{
		this->ids->addElement(id);
	};

	/**
	 * Adds the identifier of an XRI i-service object to the list of identifiers of XRI i-service
	 * objects be checked.
	 *
	 * <P><B>Note:</B> This is an alias for <code>addId</code>
	 */
	void add( DOMString id )
	{
		this->addId(id);
	};

	/**
	 * Converts the <code>EppCommandCheckXriIService</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandCheckXriIService</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandCheckXriIService</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Check entity for EPP XriIService objects.
	 *
	 * @param root root node for an <code>EppCommandCheckXriIService</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandCheckXriIService</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandCheckXriIService * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDCHECKXRIISERVICE_HPP */  /* } */
