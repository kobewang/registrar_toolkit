#if ! defined(EPPCOMMANDRENEWXRIINUMBER_HPP)    /* { */
#define       EPPCOMMANDRENEWXRIINUMBER_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandRenew.hpp"

/**
 * This <code>EppCommandRenewXriINumber</code> class implements EPP Command Renew
 * entity for EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppCommandRenewXriINumber : public EppCommandRenew
{
private:
	 DOMString inumber;

public:
	/**
	 * Creates an <code>EppCommandRenewXriINumber</code> object
	 */
	EppCommandRenewXriINumber()
	{
		this->inumber = null;
	};

	/**
	 * Creates an <code>EppCommandRenewXriINumber</code> object with a
	 * default expiration period, specified by the registry
	 */
	EppCommandRenewXriINumber( DOMString inumber, time_t curExpDate )
	{
		this->inumber = inumber;
		this->curExpDate = curExpDate;
	};

	/**
	 * Creates an <code>EppCommandRenewXriINumber</code> object with a
	 * client transaction id associated with the operation. The current
	 * date of expiration would be the current date.
	 */
	EppCommandRenewXriINumber( DOMString inumber, DOMString xid )
	{
		this->inumber = inumber;
		this->clTRID = xid;
	};

	/**
	 * Creates an <code>EppCommandRenewXriINumber</code> object with a
	 * default expiration period, specified by the registry, and a
	 * client transaction id associated with the operation
	 */
	EppCommandRenewXriINumber( DOMString inumber, time_t curExpDate, DOMString xid )
	{
		this->inumber = inumber;
		this->curExpDate = curExpDate;
		this->clTRID = xid;
	};

	/**
	 * Creates an <code>EppCommandRenewXriINumber</code> object with a
	 * specified expiration period, and a client transaction id associated
	 * with the operation
	 */
	EppCommandRenewXriINumber( DOMString inumber, time_t curExpDate, EppPeriod period, DOMString xid )
	{
		this->inumber = inumber;
		this->curExpDate = curExpDate;
		this->clTRID = xid;
		this->setPeriod(period);
	};

	/**
	 * Destructor
	 */
	~EppCommandRenewXriINumber() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandRenewXriINumber;
	};

	/**
	 * Gets the i-number of the XRI i-number object to be renewed
	 */
	DOMString getINumber()
	{
		return this->inumber;
	};

	/**
	 * Sets the i-number of the XRI i-number object to be renewed
	 */
	void setINumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Converts the <code>EppCommandRenewXriINumber</code> object into
	 *		an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *		<code>EppCommandRenewXriINumber</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandRenewXriINumber</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Renew entity for EPP XRI I-Number object
	 *
	 * @param root root node for an <code>EppCommandRenewXriINumber</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandRenewXriINumber</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandRenewXriINumber * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDRENEWXRIINUMBER_HPP */  /* } */
