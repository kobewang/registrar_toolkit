#if ! defined(EPPCOMMANDRENEWXRIISERVICE_HPP)    /* { */
#define       EPPCOMMANDRENEWXRIISERVICE_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandRenew.hpp"

/**
 * This <code>EppCommandRenewXriIService</code> class implements EPP Command Renew
 * entity for EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppCommandRenewXriIService : public EppCommandRenew
{
private:
	 DOMString id;

public:
	/**
	 * Creates an <code>EppCommandRenewXriIService</code> object
	 */
	EppCommandRenewXriIService()
	{
		this->id = null;
	};

	/**
	 * Creates an <code>EppCommandRenewXriIService</code> object with a
	 * default expiration period, specified by the registry
	 */
	EppCommandRenewXriIService( DOMString id, time_t curExpDate )
	{
		this->id = id;
		this->curExpDate = curExpDate;
	};

	/**
	 * Creates an <code>EppCommandRenewXriIService</code> object with a
	 * client transaction id associated with the operation. The current
	 * date of expiration would be the current date.
	 */
	EppCommandRenewXriIService( DOMString id, DOMString xid )
	{
		this->id = id;
		this->clTRID = xid;
	};

	/**
	 * Creates an <code>EppCommandRenewXriIService</code> object with a
	 * default expiration period, specified by the registry, and a
	 * client transaction id associated with the operation
	 */
	EppCommandRenewXriIService( DOMString id, time_t curExpDate, DOMString xid )
	{
		this->id = id;
		this->curExpDate = curExpDate;
		this->clTRID = xid;
	};

	/**
	 * Creates an <code>EppCommandRenewXriIService</code> object with a
	 * specified expiration period, and a client transaction id associated
	 * with the operation
	 */
	EppCommandRenewXriIService( DOMString id, time_t curExpDate, EppPeriod period, DOMString xid )
	{
		this->id = id;
		this->curExpDate = curExpDate;
		this->clTRID = xid;
		this->setPeriod(period);
	};

	/**
	 * Destructor
	 */
	~EppCommandRenewXriIService() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandRenewXriIService;
	};

	/**
	 * Gets the identifier of the XRI i-service object to be renewed
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the identifier of the XRI i-service object to be renewed
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Converts the <code>EppCommandRenewXriIService</code> object into
	 *		an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *		<code>EppCommandRenewXriIService</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandRenewXriIService</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Renew entity for EPP XRI I-Service object
	 *
	 * @param root root node for an <code>EppCommandRenewXriIService</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandRenewXriIService</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandRenewXriIService * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDRENEWXRIISERVICE_HPP */  /* } */
