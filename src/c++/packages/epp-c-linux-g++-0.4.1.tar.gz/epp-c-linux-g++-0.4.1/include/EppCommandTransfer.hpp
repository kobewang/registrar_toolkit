#if ! defined(EPPCOMMANDTRANSFER_HPP)    /* { */
#define       EPPCOMMANDTRANSFER_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommand.hpp"
#include "EppPollable.hpp"
#include "EppAuthInfo.hpp"

/**
 * This <code>EppCommandTransfer</code> class implements EPP Command Transfer
 * entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2002/05/08 15:39:35 $
 */
class EPP_EXPORT EppCommandTransfer : public EppCommand, public EppPollable
{
protected:
	/**
	 * The type of the transfer operation
	 */
	DOMString     op;
	/**
	 * The authorization information associated with the transfer operation
	 */
	EppAuthInfo * authInfo;

public:
	/**
	 * Transfer operation type for approving a transfer request
	 */
	static const char * OPTYPE_APPROVE;
	/**
	 * Transfer operation type for canceling a transfer request
	 */
	static const char * OPTYPE_CANCEL;
	/**
	 * Transfer operation type for querying the status of a transfer request
	 */
	static const char * OPTYPE_QUERY;
	/**
	 * Transfer operation type for rejecting a transfer request
	 */
	static const char * OPTYPE_REJECT;
	/**
	 * Transfer operation type for requesting an object transfer
	 */
	static const char * OPTYPE_REQUEST;

	/**
	 * Creates an <code>EppCommandTransfer</code> object
	 */
	EppCommandTransfer()
	{
		this->op = null;
		this->authInfo = null;
	};

	/**
	 * Destructor
	 */
	virtual ~EppCommandTransfer()
	{
		if( this->authInfo != null )
		{
			delete this->authInfo;
			this->authInfo = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandTransfer;
	};

	/**
	 * Gets the authorization info for the transfer operation
	 */
	EppAuthInfo * getAuthInfo()
	{
		return this->authInfo;
	};

	/**
	 * Sets the authorization info for the transfer operation
	 */
	void setAuthInfo( EppAuthInfo& authInfo )
	{
		if( this->authInfo == null )
		{
			this->authInfo = new EppAuthInfo();
		}
		*(this->authInfo) = authInfo;
	};

	/**
	 * Gets the operation related to the transfer.
	 */
	DOMString getOperation()
	{
		return this->op;
	}

	/**
	 * Sets the operation related to the transfer. Valid operations are:
	 * <UL>
	 * <LI>approve</LI>
	 * <LI>cancel</LI>
	 * <LI>query</LI>
	 * <LI>reject</LI>
	 * <LI>request</LI>
	 * </UL>
	 */
	void setOperation( DOMString operation )
	{
		this->op = operation;
	};

	/**
	 * Converts an XML element into an <code>EppCommandTransfer</code>
	 * object. The caller of this method must make sure that the root
	 * node is of an EPP Object transferType entity. This method is
	 * for the interface defined in <code>EppPollable</code>
	 *
	 * @param root root node for an <code>EppCommandTransfer</code> object
	 *             in XML format
	 *
	 * @return an <code>EppCommandTransfer</code> object, or null if the
	 *         node is invalid
	 */
	static EppCommandTransfer * fromXMLPoll( const DOM_Node& root );

	/**
	 * Converts an XML element into an <code>EppCommandTransfer</code>
	 * object. The caller of this method must make sure that the root
	 * node is of an EPP Command Transfer entity.
	 *
	 * @param root root node for an <code>EppCommandTransfer</code> object
	 *             in XML format
	 *
	 * @return an <code>EppCommandTransfer</code> object, or null if the
	 *         node is invalid
	 */
	static EppCommandTransfer * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("transfer"));
	};
};

#endif     /* EPPCOMMANDTRANSFER_HPP */  /* } */
