#if ! defined(EPPCOMMANDDELETEXRIINUMBER_HPP)    /* { */
#define       EPPCOMMANDDELETEXRIINUMBER_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandDelete.hpp"

/**
 * This <code>EppCommandDelete</code> class implements EPP Command Delete
 * entity for EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppCommandDeleteXriINumber : public EppCommandDelete
{
private:
	DOMString inumber;

public:
	/**
	 * Creates an <code>EppCommandDeleteXriINumber</code> object for
	 * deleting an XRI i-number based on its i-number
	 */
	EppCommandDeleteXriINumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Creates an <code>EppCommandDeleteXriINumber</code> object for
	 * deleting an XRI i-number based on its i-number, given a client
	 * transaction id associated with the operation
	 */
	EppCommandDeleteXriINumber( DOMString inumber, DOMString xid )
	{
		this->inumber = inumber;
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandDeleteXriINumber() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandDeleteXriINumber;
	};

	/**
	 * Gets the i-number of the XRI i-number object to be deleted
	 */
	DOMString getINumber()
	{
		return this->inumber;
	};

	/**
	 * Sets the i-number of the XRI i-number object to be deleted
	 */
	void setINumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Converts the <code>EppCommandDeleteXriINumber</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandDeleteXriINumber</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandDeleteXriINumber</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Delete entity for EPP XriINumber object.
	 *
	 * @param root root node for an <code>EppCommandDeleteXriINumber</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandDeleteXriINumber</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandDeleteXriINumber * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDDELETEXRIINUMBER_HPP */  /* } */
