#if ! defined(EPPXRIINUMBER_HPP)    /* { */
#define       EPPXRIINUMBER_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppEntity.hpp"
#include "EppObject.hpp"
#include "EppPeriod.hpp"

/**
 * This <code>EppXriINumber</code> class implements EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppXriINumber : public EppObject
{
private:
	DOMString   inumber;
	DOMString   refId;
	DOMString   authId;
	int         priority;
	EppPeriod * period; 

public:
	/**
	 * Default priority value - 10
	 */
	static const unsigned short int DEFAULT_PRIORITY;

	/**
	 * I-Number status - clientDeleteProhibited
	 */
	static const char * STATUS_CLIENT_DELETE_PROHIBITED;
	/**
	 * I-Number status - clientHold
	 */
	static const char * STATUS_CLIENT_HOLD;
	/**
	 * I-Number status - clientRenewProhibited
	 */
	static const char * STATUS_CLIENT_RENEW_PROHIBITED;
	/**
	 * I-Number status - clientUpdateProhibited
	 */
	static const char * STATUS_CLIENT_UPDATE_PROHIBITED;
	/**
	 * I-Number status - ok
	 */
	static const char * STATUS_OK;
	/**
	 * I-Number status - pendingCreate
	 */
	static const char * STATUS_PENDING_CREATE;
	/**
	 * I-Number status - pendingDelete
	 */
	static const char * STATUS_PENDING_DELETE;
	/**
	 * I-Number status - pendingTransfer
	 */
	static const char * STATUS_PENDING_TRANSFER;
	/**
	 * I-Number status - pendingUpdate
	 */
	static const char * STATUS_PENDING_UPDATE;
	/**
	 * I-Number status - serverDeleteProhibited
	 */
	static const char * STATUS_SERVER_DELETE_PROHIBITED;
	/**
	 * I-Number status - serverHold
	 */
	static const char * STATUS_SERVER_HOLD;
	/**
	 * I-Number status - serverRenewProhibited
	 */
	static const char * STATUS_SERVER_RENEW_PROHIBITED;
	/**
	 * I-Number status - serverUpdateProhibited
	 */
	static const char * STATUS_SERVER_UPDATE_PROHIBITED;
	/**
	 * I-Number status - terminated
	 */
	static const char * STATUS_TERMINATED;

	/**
	 * Creates an <code>EppXriINumber</code> object
	 */
	EppXriINumber()
	{
		this->inumber    = null;
		this->refId      = null;
		this->authId     = null;
//		this->priority   = DEFAULT_PRIORITY;
		this->priority   = -1;
		this->period     = null;
	};

	/**
	 * Creates an <code>EppXriINumber</code> object with an XRI i-number
	 */
	EppXriINumber( DOMString inumber )
	{
		this->inumber    = inumber;
		this->refId      = null;
		this->authId     = null;
//		this->priority   = DEFAULT_PRIORITY;
		this->priority   = -1;
		this->period     = null;
	};

	/**
	 * Destructor
	 */
	~EppXriINumber()
	{
		EppObject::freeCommon();
		if( this->period != null )
		{
			delete this->period;
			this->period = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
        virtual int getEntityType()
	{
		return EppEntity::TYPE_EppXriINumber;
	};

	/**
	 * Gets the i-number
	 */
	DOMString getINumber()
	{
		return this->inumber;
	};

	/**
	 * Sets the i-number
	 */
	void setINumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Sets the identifier of the superorindate XRI authority object,
	 * and authInfo associated with the authority, if any
	 */
	void setAuthority( DOMString authId, EppAuthInfo authInfo )
	{
		this->authId   = authId;
		this->setAuthInfo(authInfo);
	};

	/**
	 * Gets the identifier of the superordinate XRI authority object
	 */
	DOMString getAuthorityId()
	{
		return this->authId;
	};

	/**
	 * Sets the identifier of the superordinate XRI authority object
	 */
	void setAuthorityId( DOMString authId )
	{
		this->authId = authId;
	};

	/**
	 * Gets the reference identifier used in generating the i-number, if any
	 */
	DOMString getReferenceId()
	{
		return this->refId;
	};

	/**
	 * Gets the reference identifier used in generating the i-number, if any
	 */
	void setReferenceId( DOMString refId )
	{
		this->refId = refId;
	};

	/**
	 * Gets the priority value for this XRI i-number
	 */
	unsigned short int getPriority()
	{
		if( this->priority != -1 )
		{
			return (unsigned short int) (this->priority & 0xFFFF);
		}
		return DEFAULT_PRIORITY;
	};

	/**
	 * Sets the priority value for this XRI i-number
	 */
	void setPriority( unsigned short  int priority )
	{
		this->priority = priority;
	};

	/**
	 * Gets registration period for the i-number
	 */
	EppPeriod * getPeriod()
	{
		return this->period;
	};

	/**
	 * Sets registration period for the i-number
	 */
	void setPeriod( EppPeriod period )
	{
		if( this->period == null )
		{
			this->period = new EppPeriod();
		}
		*(this->period) = period;
	};

	/**
	 * Converts the <code>EppXriINumber</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the <code>EppXriINumber</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppXriINumber</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP I-Number type.
	 *
	 * @param root root node for an <code>EppXriINumber</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriINumber</code> object, or null if the node
	 *         is invalid
	 */
	static EppXriINumber * fromXML( const DOM_Node& root );

#if 0
	/**
	 * Creates an <code>EppCommandDeleteXriINumber</code> object for
	 * deleting an EPP XRI I-Number object from the registry.
	 *
	 * @param inumber the i-number of the XRI i-number object to be deleted
	 * @param xid     the client transaction id associated with the operation
	 */
	public static EppCommandDeleteXriINumber delete( String inumber, String xid )
	{
		return new EppCommandDeleteXriINumber(inumber, xid);
	}

	/**
	 * Creates an <code>EppCommandInfoXriINumber</code> object for
	 * querying the details of an EPP XRI I-Number object
	 *
	 * @param inumber the i-number of the XRI i-number object to be queried
	 * @param xid     the client transaction id associated with the operation
	 */
	public static EppCommandInfoXriINumber info( String inumber, String xid )
	{
		return new EppCommandInfoXriINumber(inumber, xid);
	}

	/**
	 * Creates an <code>EppCommandCheckXriINumber</code> object for
	 * checking the existance of EPP XRI I-Number objects in the registry.
	 * Identifiers of EPP XRI I-Number objects can be added via the
	 * <code>add</code> or <code>addINumber</code> methods.
	 *
	 * @param xid  the client transaction id associated with the operation
	 */
	public static EppCommandCheckXriINumber check( String xid )
	{
		return new EppCommandCheckXriINumber(xid);
	}

	/**
	 * Creates an <code>EppCommandRenewXriINumber</code> object for
	 * renewing the registration of an EPP XRI I-Number object in the registry.
	 *
	 * @param inumber    the inumber of the XRI i-number object to be renewed
	 * @param curExpDate the current expiration date of the svcsub object
	 * @param period     the new registration period of the svcsub object,
	 *                   or null if using the value specified by the
	 *                   registry
	 * @param xid        the client transaction id associated with the
	 *                   operation
	 */
	public static EppCommandRenewXriINumber renew( String inumber, Calendar curExpDate, EppPeriod period, String xid )
	{
		return new EppCommandRenewXriINumber(inumber, curExpDate, period, xid);
	}

	/**
	 * Creates an <code>EppCommandUpdateXriINumber</code> object for
	 * updating an EPP I-Number object in the registry. The actual update
	 * information should be specified via the various methods defined
	 * for the <code>EppCommandUpdateXriINumber</code> object.
	 *
	 * @param inumber the i-number of the XRI i-number object to be updated
	 * @param xid    the client transaction id associated with the operation
	 */
	public static EppCommandUpdateXriINumber update( String inumber, String xid )
	{
		return new EppCommandUpdateXriINumber(inumber, xid);
	}
#endif

	DOMString toString()
	{
		return EppEntity::toString(DOMString("xriINU"));
	};
};

#endif     /* EPPXRIINUMBER_HPP */  /* } */
