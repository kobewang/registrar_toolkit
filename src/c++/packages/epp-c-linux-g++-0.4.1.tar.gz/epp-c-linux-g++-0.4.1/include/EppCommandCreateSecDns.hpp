#if ! defined(EPPCOMMANDCREATESECDNS_HPP)    /* { */
#define       EPPCOMMANDCREATESECDNS_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppExtension.hpp"
#include "EppSecDnsDsData.hpp"
#include <util/ValueVectorOf.hpp>

#define MAX_NUM_OF_DS_DATA	4

/**
 * This <code>EppCommandSecDns</code> class implements EPP CommandSecDns entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppCommandCreateSecDns : public EppExtension
{
private:
	ValueVectorOf<EppSecDnsDsData> * dsDataList;

public:
	/**
	 * Creates an <code>EppCommandSecDns</code> object
	 */
	EppCommandCreateSecDns()
	{
		this->dsDataList = new ValueVectorOf<EppSecDnsDsData>(MAX_NUM_OF_DS_DATA);
	};

	/**
	 * Destructor
	 */
	~EppCommandCreateSecDns()
	{
		if( this->dsDataList != null )
		{
			delete this->dsDataList;
			this->dsDataList = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandCreateSecDns;
	};

	/**
	 * Adds DS Data to the list to be attached to a domain name
	 */
	void add( EppSecDnsDsData& dsData )
	{
                this->dsDataList->addElement(dsData);
	};

	/**
	 * Gets the list of DS data to be attached to a domain name
	 */
	ValueVectorOf<EppSecDnsDsData> * getDsData()
	{
        	return this->dsDataList;
	};

	/**
	 * Converts an XML element into an <code>EppCommandCreateSecDns</code> object.
	 * The caller of this method must make sure that the root node is of
	 * EPP SECDNS createType
	 *
	 * @param root root node for an <code>EppCommandCreateSecDns</code> object in XML format
	 *
	 * @return an <code>EppCommandCreateSecDns</code> object, or null if the node is invalid
	 */
	static EppCommandCreateSecDns * fromXML( const DOM_Node& root );

	/**
	 * Converts the <code>EppCommandCreateSecDns</code> object into an XML element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the <code>EppCommandCreateSecDns</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("create"));
	};
};

#endif     /* EPPCOMMANDCREATESECDNS_HPP */  /* } */
