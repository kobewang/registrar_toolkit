#if ! defined(EPPRESPONSEDATACREATEXRIINAME_HPP)    /* { */
#define       EPPRESPONSEDATACREATEXRIINAME_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppResponseDataCreate.hpp"

/**
 * This <code>EppResponseDataCreateXriIName</code> class implements EPP
 * Response Data entity for EPP Command Create of EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppResponseDataCreateXriIName : public EppResponseDataCreate
{
private:
	DOMString iname;
	time_t    exDate;

public:
	/**
	 * Creates an <code>EppResponseDataCreateXriIName</code> object
	 */
	EppResponseDataCreateXriIName()
	{
		this->iname  = null;
		this->crDate = time(0);
		this->exDate = time(0);
	};

	/**
	 * Creates an <code>EppResponseDataCreateXriIName</code> object,
	 * with the current date as the creation date.
	 *
         * @param iname the i-name of the EPP XRI i-name object created
	 */
	EppResponseDataCreateXriIName( DOMString iname )
	{
		this->iname  = iname;
		this->crDate = time(0);
		this->exDate = time(0);
	};

	/**
	 * Creates an <code>EppResponseDataCreateXriIName</code> object,
	 * given the i-name of the XRI i-name object, and an expiration date,
	 * with the current date as the creation date
	 *
         * @param iname the i-name of the EPP XRI i-name object created
         * @param exDate  the expiration date of the XRI i-name object created
	 */
	EppResponseDataCreateXriIName( DOMString iname, time_t exDate )
	{
		this->iname  = iname;
		this->crDate = time(0);
		this->exDate = exDate;
	};

	/**
	 * Creates an <code>EppResponseDataCreateXriIName</code> object,
	 * given the i-name of the XRI i-name object, a reference id,
	 * and an expiration date,
	 * with the current date as the creation date
	 *
         * @param iname the i-name of the EPP XRI i-name object created
         * @param exDate  the expiration date of the XRI i-name object created
         * @param crDate  the creation date of the XRI i-name object created
	 */
	EppResponseDataCreateXriIName( DOMString iname, time_t exDate, time_t crDate )
	{
		this->iname  = iname;
		this->crDate = crDate;
		this->exDate = exDate;
	};

	/**
	 * Sets the i-name
	 */
	void setIName( DOMString iname )
	{
		this->iname = iname;
	};

	/**
	 * Gets the i-name
	 */
	DOMString getIName()
	{
		return this->iname;
	};

	/**
	 * Gets expiration date of the XRI i-name object created
	 */
	time_t getDateExpired()
	{
		return this->exDate;
	};

	/**
	 * Sets expiration date of the XRI i-name object created
	 */
	void setDateExpired( time_t exDate )
	{
		this->exDate = exDate;
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCreateXriIName;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCreateXriIName</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XriIName object.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCreateXriIName</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCreateXriIName</code> object, or null
	 *         if the node is invalid
	 */
	static EppResponseDataCreateXriIName * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataCreateXriIName</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCreateXriIName</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATACREATEXRIINAME_HPP */  /* } */
