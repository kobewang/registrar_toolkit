#if ! defined(EPPRESPONSEDATARENEWISERVICE_HPP)    /* { */
#define       EPPRESPONSEDATARENEWISERVICE_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include <time.h>
#include "EppResponseDataRenew.hpp"

/**
 * This <code>EppResponseDataRenewXriIService</code> class implements EPP
 * Response Data entity for EPP Command Renew of EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppResponseDataRenewXriIService : public EppResponseDataRenew
{
private:
	DOMString id;
	time_t    exDate;

public:
	/**
	 * Creates an <code>EppResponseDataRenewXriIService</code> object
	 *
	 * @param id the identifier of the XRI i-service object renewed
	 */
	EppResponseDataRenewXriIService()
	{
		this->id = null;
		this->roid = null;
		this->exDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataRenewXriIService</code> object
	 *
	 * @param id the identifier of the XRI i-service object renewed
	 */
	EppResponseDataRenewXriIService( DOMString id )
	{
		this->id = id;
		this->roid = null;
		this->exDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataRenewXriIService</code> object
	 *
	 * @param id     the identifier of the XRI i-service object renewed
	 * @param exDate the expiration date of the XRI i-service
	 *               object renewed
	 */
	EppResponseDataRenewXriIService( DOMString id, time_t exDate )
	{
		this->id = id;
		this->roid = null;
		this->exDate = exDate;
	};

	/**
	 * Renews an <code>EppResponseDataRenewXriIService</code> object
	 *
	 * @param id the id of the <code>EppXriIService</code> object renewed
	 * @param roid the ROID of the <code>EppXriIService</code> object renewed
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	EppResponseDataRenewXriIService( DOMString id, DOMString roid )
	{
		this->id = id;
		this->roid = roid;
		this->exDate = 0;
	};

	/**
	 * Renews an <code>EppResponseDataRenewXriIService</code> object
	 *
	 * @param id   the id of the <code>EppXriIService</code> object renewed
	 * @param roid   the ROID of the <code>EppXriIService</code> object renewed
	 * @param exDate the expiration date of the <code>EppXriIService</code>
	 *               object renewed
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	EppResponseDataRenewXriIService( DOMString id, DOMString roid, time_t exDate )
	{
		this->id = id;
		this->roid = roid;
		this->exDate = exDate;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataRenewXriIService() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataRenewXriIService;
	};

	/**
	 * Gets the identifier of the XRI i-service object renewed
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the identifier of the XRI i-service object renewed
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Gets expiration date of the XRI i-service object renewed
	 */
	time_t getDateExpired()
	{
		return this->exDate;
	};

	/**
	 * Sets expiration date of the XRI i-service object renewed
	 */
	void setDateExpired( time_t exDate )
	{
		this->exDate = exDate;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataRenewXriIService</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XRI I-Service object
	 *
	 * @param root root node for an <code>EppResponseDataRenewXriIService</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataRenewXriIService</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataRenewXriIService * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataRenewXriIService</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataRenewXriIService</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATARENEWISERVICE_HPP */  /* } */
