#if ! defined(EPPRESPONSEDATACREATEXRIINUMBER_HPP)    /* { */
#define       EPPRESPONSEDATACREATEXRIINUMBER_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppResponseDataCreate.hpp"

/**
 * This <code>EppResponseDataCreateXriINumber</code> class implements EPP
 * Response Data entity for EPP Command Create of EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppResponseDataCreateXriINumber : public EppResponseDataCreate
{
private:
	DOMString inumber;
	DOMString refId;
	time_t    exDate;

public:
	/**
	 * Creates an <code>EppResponseDataCreateXriINumber</code> object
	 */
	EppResponseDataCreateXriINumber()
	{
		this->inumber= null;
		this->refId  = null;
		this->crDate = time(0);
		this->exDate = time(0);
	};

	/**
	 * Creates an <code>EppResponseDataCreateXriINumber</code> object,
	 * with the current date as the creation date.
	 *
         * @param inumber the i-number of the EPP XRI i-number object created
	 */
	EppResponseDataCreateXriINumber( DOMString inumber )
	{
		this->inumber= inumber;
		this->refId  = null;
		this->crDate = time(0);
		this->exDate = time(0);
	};

	/**
	 * Creates an <code>EppResponseDataCreateXriINumber</code> object,
	 * given the i-number of the XRI i-number object, and an expiration date,
	 * with the current date as the creation date
	 *
         * @param inumber the i-number of the EPP XRI i-number object created
         * @param exDate  the expiration date of the XRI i-number object created
	 */
	EppResponseDataCreateXriINumber( DOMString inumber, time_t exDate )
	{
		this->inumber= inumber;
		this->refId  = null;
		this->crDate = time(0);
		this->exDate = exDate;
	};

	/**
	 * Creates an <code>EppResponseDataCreateXriINumber</code> object,
	 * given the i-number of the XRI i-number object, a reference id,
	 * and an expiration date,
	 * with the current date as the creation date
	 *
         * @param inumber the i-number of the EPP XRI i-number object created
         * @param refId   the reference id of the XRI i-number object created
         * @param exDate  the expiration date of the XRI i-number object created
	 */
	EppResponseDataCreateXriINumber( DOMString inumber, DOMString refId, time_t exDate )
	{
		this->inumber= inumber;
		this->refId  = refId;
		this->crDate = time(0);
		this->exDate = exDate;
	};

	/**
	 * Creates an <code>EppResponseDataCreateXriINumber</code> object,
	 * given the i-number of the XRI i-number object, a reference id,
	 * and an expiration date,
	 * with the current date as the creation date
	 *
         * @param inumber the i-number of the EPP XRI i-number object created
         * @param refId   the reference id of the XRI i-number object created
         * @param exDate  the expiration date of the XRI i-number object created
         * @param crDate  the creation date of the XRI i-number object created
	 */
	EppResponseDataCreateXriINumber( DOMString inumber, DOMString refId, time_t exDate, time_t crDate )
	{
		this->inumber= inumber;
		this->refId  = refId;
		this->crDate = crDate;
		this->exDate = exDate;
	};

	/**
	 * Sets the i-number
	 */
	void setINumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Gets the i-number
	 */
	DOMString getINumber()
	{
		return this->inumber;
	};

	/**
	 * Gets expiration date of the XRI i-number object created
	 */
	time_t getDateExpired()
	{
		return this->exDate;
	};

	/**
	 * Sets expiration date of the XRI i-number object created
	 */
	void setDateExpired( time_t exDate )
	{
		this->exDate = exDate;
	};

	/**
	 * Gets the reference identifier used in generating the i-number, if any
	 */
	DOMString getReferenceId()
	{
		return this->refId;
	};

	/**
	 * Sets the reference identifier used in generating the i-number, if any
	 */
	void setReferenceId( DOMString refId )
	{
		this->refId = refId;
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCreateXriINumber;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCreateXriINumber</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XriINumber object.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCreateXriINumber</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCreateXriINumber</code> object, or null
	 *         if the node is invalid
	 */
	static EppResponseDataCreateXriINumber * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataCreateXriINumber</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCreateXriINumber</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATACREATEXRIINUMBER_HPP */  /* } */
