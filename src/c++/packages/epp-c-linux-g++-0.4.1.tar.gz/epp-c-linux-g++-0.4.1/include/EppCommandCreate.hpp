#if ! defined(EPPCOMMANDCREATE_HPP)    /* { */
#define       EPPCOMMANDCREATE_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommand.hpp"
#include "EppObject.hpp"

/**
 * This <code>EppCommandCreate</code> class implements EPP Command Create
 * entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppCommandCreate : public EppCommand
{
private:
	EppObject * object;
	bool        freeable;

public:
	/**
	 * Creates an <code>EppCommandCreate</code> object
	 */
	EppCommandCreate()
	{
		this->object = null;
		this->freeable = false;
	};

	/**
	 * Creates an <code>EppCommandCreate</code> object
	 *
	 * @param object the <code>EppObject</code> to be processed
	 *
         * @note the memory associated with the object data will not be
         *       freed by this class. The caller of this method should be
         *       responsible to free the memory, if needed.
	 */
	EppCommandCreate( EppObject * object )
	{
		this->object = object;
		this->freeable = false;
	};

	/**
	 * Creates an <code>EppCommandCreate</code> object
	 *
	 * @param object the <code>EppObject</code> to be processed
	 * @param xid    the client transaction id associated with the
	 *               operation
	 */
	EppCommandCreate( EppObject * object, DOMString xid )
	{
		this->object = object;
		this->freeable = false;
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandCreate()
	{
		if( this->freeable )
		{
			if( this->object != null )
			{
				delete this->object;
			}
		}
		this->object = null;
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandCreate;
	};

	/**
	 * Gets the object to be processed
	 */
	EppObject * getObject()
	{
		return this->object;
	};

	/**
	 * Sets the object to be processed
	 *
         * @note the memory associated with the object data will not be
         *       freed by this class. The caller of this method should be
         *       responsible to free the memory, if needed.
	 */
	void setObject( EppObject * object )
	{
		if( this->freeable )
		{
			if( this->object != null )
			{
				delete this->object;
			}
			this->freeable = false;
		}
		this->object = object;
	};

	/**
	 * Converts the <code>EppCommandCreate</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the <code>EppCommandCreate</code>
	 *            object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandCreate</code> object.
	 * The caller of this method must make sure that the root node is of an
	 * EPP Command Create entity.
	 *
	 * @param root root node for an <code>EppCommandCreate</code> object
	 *             in XML format
	 *
	 * @return an <code>EppCommandCreate</code> object, or null if the node
	 *         is invalid
	 */
	static EppCommandCreate * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("create"));
	};
};

#endif     /* EPPCOMMANDCREATE_HPP */  /* } */
