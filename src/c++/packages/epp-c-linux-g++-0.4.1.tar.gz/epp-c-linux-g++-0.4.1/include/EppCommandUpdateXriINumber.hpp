#if ! defined(EPPCOMMANDUPDATEXRIINUMBER_HPP)    /* { */
#define       EPPCOMMANDUPDATEXRIINUMBER_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandUpdate.hpp"
#include "EppXriINumber.hpp"

/**
 * This <code>EppCommandUpdateXriINumber</code> class implements EPP Command Update
 * entity for EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppCommandUpdateXriINumber : public EppCommandUpdate
{
private:
	DOMString inumber;
	int       newPriority;

	/**
	 * Adds elements included in the &lt;chg&gt tag of the update command
	 * for an XRI i-number object
	 *
	 * @param root the root <code>DOM_Node</code> of the &lt;chg&gt; tag
	 */
	void addNewStuff( DOM_Node root );

public:
	/**
	 * Creates an <code>EppCommandUpdateXriINumber</code>
	 */
	EppCommandUpdateXriINumber()
	{
		this->inumber = null;
		this->clTRID = null;
		this->newPriority = -1;
	};

	/**
	 * Creates an <code>EppCommandUpdateXriINumber</code> given the
	 * i-number of the XRI i-number object
	 */
	EppCommandUpdateXriINumber( DOMString inumber )
	{
		this->inumber = inumber;
		this->clTRID = null;
		this->newPriority = -1;
	};

	/**
	 * Creates an <code>EppCommandUpdateXriINumber</code> given the
	 * i-number of the XRI i-number object and a client transaction id
	 */
	EppCommandUpdateXriINumber( DOMString inumber, DOMString xid )
	{
		this->inumber = inumber;
		this->clTRID = xid;
		this->newPriority = -1;
	};

	/**
	 * Destricutor
	 */
	~EppCommandUpdateXriINumber() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandUpdateXriINumber;
	};

	/**
	 * Gets the i-number of the XRI i-number object to be updated
	 */
	DOMString getINumber()
	{
		return this->inumber;
	};

	/**
	 * Sets the i-number of the XRI i-number object to be updated
	 */
	void setINumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Gets the new priority value for this i-number
	 */
	unsigned short int getNewPriority()
	{
		if( this->newPriority != -1 )
		{
			return (unsigned short int) (this->newPriority & 0xFFFF);
		}
                return EppXriINumber::DEFAULT_PRIORITY;
	};

	/**
	 * Sets the priority value for this i-number
	 */
	void setNewPriority( unsigned short int newPriority )
	{
		this->newPriority = newPriority;
	};

	/**
	 * Checks if the a new priority value is set for this i-number
	 */
	bool isNewPrioritySet()
	{
		if( this->newPriority != -1 )
		{
			return true;
		}
		return false;
	};

	/**
	 * Converts the <code>EppCommandUpdateXriINumber</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the 
	 *            <code>EppCommandUpdateXriINumber</code> object
	 *
	 * @return an <code>DOM_Element</code> object 
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandUpdateXriINumber</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Update entity for an EPP XRI I-Number object.
	 *
	 * @param root root node for an <code>EppCommandUpdateXriINumber</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandUpdateXriINumber</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandUpdateXriINumber * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDUPDATEXRIINUMBER_HPP */  /* } */
