#if ! defined(EPPRESPONSEDATACREATEXRIAUTHORITY_HPP)    /* { */
#define       EPPRESPONSEDATACREATEXRIAUTHORITY_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppResponseDataCreate.hpp"

/**
 * This <code>EppResponseDataCreateXriAuthority</code> class implements EPP
 * Response Data entity for EPP Command Create of EPP XRI Authority objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppResponseDataCreateXriAuthority : public EppResponseDataCreate
{
private:
	DOMString authId;

public:
	/**
	 * Creates an <code>EppResponseDataCreateXriAuthority</code> object
	 */
	EppResponseDataCreateXriAuthority()
	{
		this->authId = null;
		this->crDate = time(0);
	};

	/**
	 * Creates an <code>EppResponseDataCreateXriAuthority</code> object,
	 * given the XRI authority identifier, with the current date as the creation date
	 */
	EppResponseDataCreateXriAuthority( DOMString authId )
	{
		this->authId = authId;
		this->crDate = time(0);
	};

	/**
	 * Creates an <code>EppResponseDataCreateXriAuthority</code> object,
	 * given the XRI authority identifier and the creation date
	 */
	EppResponseDataCreateXriAuthority( DOMString authId, time_t crDate )
	{
		this->authId = authId;
		this->crDate = crDate;
	};

	/**
	 * Sets the XRI authority identifier
	 */
	void setAuthorityId( DOMString authId )
	{
		this->authId = authId;
	};

	/**
	 * Gets the XRI authority identifier
	 */
	DOMString getAuthorityId()
	{
		return this->authId;
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCreateXriAuthority;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCreateXriAuthority</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XriAuthority object.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCreateXriAuthority</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCreateXriAuthority</code> object, or null
	 *         if the node is invalid
	 */
	static EppResponseDataCreateXriAuthority * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataCreateXriAuthority</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCreateXriAuthority</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATACREATEXRIAUTHORITY_HPP */  /* } */
