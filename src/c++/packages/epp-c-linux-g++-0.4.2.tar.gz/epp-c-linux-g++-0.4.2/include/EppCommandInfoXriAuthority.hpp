#if ! defined(EPPCOMMANDINFOXRIAUTHORITY_HPP)    /* { */
#define       EPPCOMMANDINFOXRIAUTHORITY_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandInfoXriAuthority.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppCommandInfo.hpp"

/**
 * This <code>EppCommandInfoXriAuthority</code> class implements EPP Command Info
 * entity for EPP XRI Authority objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppCommandInfoXriAuthority : public EppCommandInfo
{
private:
	DOMString         authId;
	EppAuthInfo	* authInfo;
	DOMString	  control;

public:
	/**
	 * I-Name/I-Number/I-Service Control - all
	 *
	 * <P>A value of "all" returns information of associated
	 * subordinate i-names, i-numbers and i-services
	 */
	static const char * CONTROL_ALL;
	/**
	 * I-Name/I-Number/I-Service Control - iname
	 *
	 * <P>A value of "iname" returns information of associated subordinate i-names only
	 */
	static const char * CONTROL_INAME;
	/**
	 * I-Name/I-Number/I-Service Control - inumber
	 *
	 * <P>A value of "inumber" returns information of associated subordinate i-numbers only
	 */
	static const char * CONTROL_INUMBER;
	/**
	 * I-Name/I-Number/I-Service Control - iservice
	 *
	 * <P>A value of "inumber" returns information of associated subordinate i-services only
	 */
	static const char * CONTROL_ISERVICE;
	/**
	 * I-Name/I-Number/I-Service Control - none
	 *
	 * <P>A value of "none" (the default, which MAY be absent) returns no information
	 * of associated subordinate i-names, i-numbers and i-services
	 */
	static const char * CONTROL_NONE;

	/**
	 * Creates an <code>EppCommandInfoXriAuthority</code> object
	 */
	EppCommandInfoXriAuthority()
	{
		this->authId   = null;
		this->clTRID   = null;
		this->authInfo = null;
		this->control  = CONTROL_NONE;
	};

	/**
	 * Creates an <code>EppCommandInfoXriAuthority</code> object for
	 * querying an XRI authority object based on its identifier
	 */
	EppCommandInfoXriAuthority( DOMString authId )
	{
		this->authId   = authId;
		this->clTRID   = null;
		this->authInfo = null;
		this->control  = CONTROL_NONE;
	};

	/**
	 * Creates an <code>EppCommandInfoXriAuthority</code> object for
	 * querying an XRI authority object based on its identifier, given a client
	 * transaction id associated with the operation
	 */
	EppCommandInfoXriAuthority( DOMString authId, DOMString xid )
	{
		this->authId   = authId;
		this->clTRID   = xid;
		this->authInfo = null;
		this->control  = CONTROL_NONE;
	};

	/**
	 * Destructor
	 */
	~EppCommandInfoXriAuthority()
	{
		if( this->authInfo != null )
		{
			delete this->authInfo;
			this->authInfo = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandInfoXriAuthority;
	};

	/**
	 * Gets the identifier of the XRI authority object to be queried
	 */
	DOMString getAuthorityId()
	{
		return this->authId;
	};

	/**
	 * Sets the identifier of the XRI authority object to be queried
	 */
	void setAuthorityId( DOMString authId )
	{
		this->authId = authId;
	};

	/**
	 * Gets the optional authorization info for querying the XRI authority object
	 */
	EppAuthInfo * getAuthInfo()
	{
		return this->authInfo;
	};

	/**
	 * Sets the optional authorization info for querying the XRI authority object
	 */
	void setAuthInfo( EppAuthInfo authInfo )
	{
		if( this->authInfo == null )
		{
			this->authInfo = new EppAuthInfo();
		}
		*(this->authInfo) = authInfo;
	};

	/**
	 * Gets the control attribute for querying the XRI authority object
	 */
	DOMString getControl()
	{
		return this->control;
	};

	/**
	 * Sets the control attribute for querying the XRI authority object,
	 * with one of the following values:
	 *
	 * <UL>
	 * <LI>CONTROL_ALL</LI>
	 * <LI>CONTROL_INAME</LI>
	 * <LI>CONTROL_INUMBER</LI>
	 * <LI>CONTROL_NONE</LI>
	 * </UL>
	 */
	void setControl( DOMString control )
	{
		this->control = control;
	};

	/**
	 * Converts the <code>EppCommandInfoXriAuthority</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandInfoXriAuthority</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandInfoXriAuthority</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Info entity for EPP XRI authority object.
	 *
	 * @param root root node for an <code>EppCommandInfoXriAuthority</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandInfoXriAuthority</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandInfoXriAuthority * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDINFOXRIAUTHORITY_HPP */  /* } */
