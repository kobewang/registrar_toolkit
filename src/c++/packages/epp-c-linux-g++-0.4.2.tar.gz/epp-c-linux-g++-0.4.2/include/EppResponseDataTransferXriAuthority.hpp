#if ! defined(EPPRESPONSEDATATRANSFERXRIAUTHORITY_HPP)    /* { */
#define       EPPRESPONSEDATATRANSFERXRIAUTHORITY_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataTransferXriAuthority.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppResponseDataTransfer.hpp"

/**
 * This <code>EppResponseDataTransferXriAuthority</code> class implements EPP
 * Response Data entity for EPP Command Transfer of EPP XRI Authority objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataTransferXriAuthority : public EppResponseDataTransfer
{
private:
	DOMString authId;
	DOMString sourceAuthId;
	DOMString targetAuthId;
	DOMString trToken;

public:
	/**
	 * Creates an <code>EppResponseDataTransferXriAuthority</code> object
	 */
	EppResponseDataTransferXriAuthority()
	{
		this->authId = null;
		this->sourceAuthId = null;
		this->targetAuthId = null;
		this->trToken = null;
	};

	/**
	 * Creates an <code>EppResponseDataTransferXriAuthority</code> object
	 * given the identifier of an XRI authority object to be transferred
	 */
	EppResponseDataTransferXriAuthority( DOMString authId )
	{
		this->authId = authId;
		this->sourceAuthId = null;
		this->targetAuthId = null;
		this->trToken = null;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataTransferXriAuthority() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataTransferXriAuthority;
	};

	/**
	 * Gets the identifier of the XRI Authority object
	 */
	DOMString getAuthorityId()
	{
		return this->authId;
	};

	/**
	 * Sets the identifier of the XRI Authority Object
	 */
	void setAuthorityId( DOMString authId )
	{
		this->authId = authId;
	};

	/**
	 * Gets the identifier of the XRI Authority object involved
	 * in the transfer that acts as the source, if any
	 */
	DOMString getSourceAuthorityId()
	{
		return this->sourceAuthId;
	};

	/**
	 * Sets the identifier of the XRI Authority object involved
	 * in the transfer that acts as the source, if any
	 */
	void setSourceAuthorityId( DOMString sourceAuthId )
	{
		this->sourceAuthId = sourceAuthId;
	};

	/**
	 * Gets the identifier of the XRI Authority object involved
	 * in the transfer that acts as the target, if any
	 */
	DOMString getTargetAuthorityId()
	{
		return this->targetAuthId;
	};

	/**
	 * Sets the identifier of the XRI Authority object involved
	 * in the transfer that acts as the target, if any
	 */
	void setTargetAuthorityId( DOMString targetAuthId )
	{
		this->targetAuthId = targetAuthId;
	};

	/**
	 * Gets the transfer token for the transfer operation
	 */
	DOMString getTransferToken()
	{
		return this->trToken;
	};

	/**
	 * Sets the transfer token for the transfer operation
	 */
	void setTransferToken( DOMString trToken )
	{
		this->trToken = trToken;
	};

	/**
	 * Converts the <code>EppResponseDataTransferXriAuthority</code> object into
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataTransferXriAuthority</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataTransferXriAuthority</code> object. The caller
	 * of this method must make sure that the root node is of an EPP
	 * Response Transfer entity for EPP XRI Authority object.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataTransferXriAuthority</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataTransferXriAuthority</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataTransferXriAuthority * fromXML( const DOM_Node& root );
};

#endif     /* EPPRESPONSEDATATRANSFERXRIAUTHORITY_HPP */  /* } */
