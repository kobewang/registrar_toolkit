#if ! defined(EPPCOMMANDDELETEXRIISERVICE_HPP)    /* { */
#define       EPPCOMMANDDELETEXRIISERVICE_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandDeleteXriService.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppCommandDelete.hpp"

/**
 * This <code>EppCommandDelete</code> class implements EPP Command Delete
 * entity for EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppCommandDeleteXriService : public EppCommandDelete
{
private:
	DOMString id;

public:
	/**
	 * Creates an <code>EppCommandDeleteXriService</code> object for
	 * deleting an XRI i-service based on its identifier
	 */
	EppCommandDeleteXriService( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Creates an <code>EppCommandDeleteXriService</code> object for
	 * deleting an XRI i-service based on its identifier, given a client
	 * transaction id associated with the operation
	 */
	EppCommandDeleteXriService( DOMString id, DOMString xid )
	{
		this->id = id;
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandDeleteXriService() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandDeleteXriService;
	};

	/**
	 * Gets the identifier of the XRI i-service object to be deleted
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the identifier of the XRI i-service object to be deleted
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Converts the <code>EppCommandDeleteXriService</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandDeleteXriService</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandDeleteXriService</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Delete entity for EPP XriService object.
	 *
	 * @param root root node for an <code>EppCommandDeleteXriService</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandDeleteXriService</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandDeleteXriService * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDDELETEXRIISERVICE_HPP */  /* } */
