#if ! defined(EPPRESPONSEDATARENEW_HPP)    /* { */
#define       EPPRESPONSEDATARENEW_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataRenew.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppResponseData.hpp"

/**
 * This <code>EppResponseDataRenew</code> class implements EPP Response
 * Data entity for EPP Command Renew.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataRenew : public EppResponseData
{
protected:
	/**
	 * The ROID associated with the response data after creating
	 * an object successfully
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	DOMString roid;

public:
	/**
	 * Renews <code>EppResponseDataRenew</code> object
	 */
	EppResponseDataRenew()
	{
		this->roid = null;
	};

	/**
	 * Destructor
	 */
	virtual ~EppResponseDataRenew() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataRenew;
	};

	/**
	 * Gets ROID associated with the creation of an <code>EppObject</code>
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	DOMString getRoid()
	{
		return this->roid;
	};

	/**
	 * Sets ROID associated with the creation of an <code>EppObject</code>
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	void setRoid( DOMString roid )
	{
		this->roid = roid;
	};
};

#endif     /* EPPRESPONSEDATARENEW_HPP */  /* } */
