#if ! defined(EPPPOLLABLE_HPP)    /* { */
#define       EPPPOLLABLE_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppPollable.hpp,v 1.2 2006/03/01 01:35:37 wtan Exp $
 */
#include <dom/DOM.hpp>

/**
 * The <code>EppPollable</code> interface is designed for pollable
 * <code>EppEntity</code>, such as <code>EppCommandTransfer</code> objects,
 * that can be included as the data element in the response of an EPP Poll
 * command.
 *
 * <P><B>Warning</B>: This interface is no longer used. Just for compatiblity. It may be removed
 * in the future.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:37 $
 */
class EPP_EXPORT EppPollable
{
public:
	/**
	 * Destructor
	 */
	virtual ~EppPollable() {};

	/**
	 * Converts the <code>EppPollable</code> object into an XML element
	 * that can be included as the data element in the response of an
	 * EPP Poll command.
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the <code>EppEntity</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	virtual DOM_Element toXMLPoll( DOM_Document &doc, const DOMString& tag ) = 0;
};

#endif     /* EPPPOLLABLE_HPP */  /* } */
