#if ! defined(EPPSTATUS_HPP)    /* { */
#define       EPPSTATUS_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppStatus.hpp,v 1.2 2006/03/01 01:35:37 wtan Exp $
 */
#include "EppEntity.hpp"

/**
 * This <code>EppStatus</code> class implements EPP Status entity. Different EPP
 * objects have different status values:
 *
 * <UL>
 * <LI><B>EPP Contact Object</B><UL>
 *     <LI>clientDeleteProhibited</LI>
 *     <LI>clientTransferProhibited</LI>
 *     <LI>clientUpdateProhibited</LI>
 *     <LI>linked</LI>
 *     <LI>ok</LI>
 *     <LI>pendingCreate &dagger;</LI>
 *     <LI>pendingDelete</LI>
 *     <LI>pendingTransfer</LI>
 *     <LI>pendingUpdate &dagger;</LI>
 *     <LI>serverDeleteProhibited</LI>
 *     <LI>serverTransferProhibited</LI>
 *     <LI>serverUpdateProhibited</LI>
 *     </UL></LI>
 * <LI><B>EPP Domain Object</B><UL>
 *     <LI>clientDeleteProhibited</LI>
 *     <LI>clientHold</LI>
 *     <LI>clientRenewProhibited</LI>
 *     <LI>clientTransferProhibited</LI>
 *     <LI>clientUpdateProhibited</LI>
 *     <LI>inactive</LI>
 *     <LI>ok</LI>
 *     <LI>pendingCreate &dagger;</LI>
 *     <LI>pendingDelete</LI>
 *     <LI>pendingRenew &dagger;</LI>
 *     <LI>pendingTransfer</LI>
 *     <LI>pendingUpdate &dagger;</LI>
 *     <LI>pendingVerification &Dagger;</LI>
 *     <LI>serverDeleteProhibited</LI>
 *     <LI>serverHold</LI>
 *     <LI>serverRenewProhibited</LI>
 *     <LI>serverTransferProhibited</LI>
 *     <LI>serverUpdateProhibited</LI>
 *     </UL></LI>
 * <LI><B>EPP Host Object</B><UL>
 *     <LI>clientDeleteProhibited</LI>
 *     <LI>clientUpdateProhibited</LI>
 *     <LI>linked</LI>
 *     <LI>ok</LI>
 *     <LI>pendingCreate &dagger;</LI>
 *     <LI>pendingDelete</LI>
 *     <LI>pendingTransfer</LI>
 *     <LI>pendingUpdate &dagger;</LI>
 *     <LI>serverDeleteProhibited</LI>
 *     <LI>serverUpdateProhibited</LI>
 *     </UL></LI>
 * </UL>
 *
 * <P><B>Note &dagger;:<B> EPP-1.0 (EPP-09) only.
 * <P><B>Note &Dagger;:<B> EPP-04 only.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:37 $
 */
class EPP_EXPORT EppStatus : public EppEntity
{
private:
	DOMString message;
	DOMString s;
	DOMString lang;

public:
	/**
	 * Creates an <code>EppStatus</code> object, with default status
	 * as "ok" and language as "en"
	 */
	EppStatus()
	{
		this->s = DOMString("ok");
		this->lang = null;
		this->message = null;
	};

	/**
	 * Creates an <code>EppStatus</code> object with a status code
	 */
	EppStatus( DOMString status )
	{
		this->s = status;
		this->lang = null;
		this->message = null;
	};

	/**
	 * Creates an <code>EppStatus</code> object with a status code,
	 * and a descriptive message
	 */
	EppStatus( DOMString status, DOMString lang, DOMString message )
	{
		this->s = status;
		this->lang = lang;
		this->message = message;
	};

	/**
	 * Destructor
	 */
	~EppStatus() {};

	/**
	 * Gets the description message associated with the
	 * <code>EppStatus</code> object
	 */
	DOMString getMessage()
	{
		return this->message;
	};

	/**
	 * Sets the description message associated with the
	 * <code>EppStatus</code> object
	 */
	void setMessage( DOMString message )
	{
		this->message = message;
	};

	/**
	 * Gets the status code string
	 */
	DOMString getStatus()
	{
		return this->s;
	};

	/**
	 * Sets the status code string
	 */
	void setStatus( DOMString status )
	{
		this->s = status;
	};

	/**
	 * Gets the language for encoding the description message
	 */
	DOMString getLanguage()
	{
		return this->lang;
	};

	/**
	 * Sets the language for encoding the description message
	 */
	void setLanguage( DOMString language )
	{
		this->lang = language;
	};

	/**
	 * Converts the <code>EppStatus</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the <code>EppStatus</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppStatus</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP Status type.
	 *
	 * @param root root node for an <code>EppStatus</code> object
	 *             in XML format
	 *
	 * @return an <code>EppStatus</code> object, or null if the node
	 *         is invalid
	 */
	static EppStatus * fromXML( const DOM_Node& root );

	DOMString toString()
	{
	   return EppEntity::toString(DOMString("status"));
	};
};

#endif     /* EPPSTATUS_HPP */  /* } */
