#if ! defined(EPPXRISERVICEENDPOINTRULE_HPP)    /* { */
#define       EPPXRISERVICEENDPOINTRULE_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppXriServiceEndpointRule.hpp,v 1.2 2006/03/13 04:13:25 wtan Exp $
 */
#include "EppEntity.hpp"


/**
 * This <code>EppXriServiceEndpointRule</code> abstract class
 * encapsulates the common EPP XRI Authority ServiceEndpoint rules
 * (Type, MediaType and Path).
 *
 * @author William Tan william.tan@neustar.biz
 * @version $Revision: 1.2 $ $Date: 2006/03/13 04:13:25 $
 */
class EPP_EXPORT EppXriServiceEndpointRule : public EppEntity
{
protected:
	DOMString match;
	bool      select;
	DOMString value;


public:
	static const char * MATCH_ATTR_DEFAULT;
	static const char * MATCH_ATTR_CONTENT;
	static const char * MATCH_ATTR_ANY;
	static const char * MATCH_ATTR_NON_NULL;
	static const char * MATCH_ATTR_NULL;
	static const char * MATCH_ATTR_NONE;

	static const char * DEFAULT_MATCH_ATTR;

	static const bool DEFAULT_SELECT_ATTR;

protected:
	/**
	 * Creates an <code>EppXriServiceEndpoint</code> object
	 */
	EppXriServiceEndpointRule()
	{
		this->value  = null;
		this->match  = null;
		this->select = DEFAULT_SELECT_ATTR;
	}

	/**
	 * Creates an <code>EppXriServiceEndpoint</code> object
	 */
	EppXriServiceEndpointRule( DOMString value, DOMString match, bool select )
	{
		this->value  = value;
		this->match  = match;
		this->select = select;
	};


public:
	/**
	 * Destructor
	 */
	virtual ~EppXriServiceEndpointRule()
	{
	};

	/**
	 * Gets the "match" attribute value of this rule object
	 */
	DOMString getMatch()
	{
		// return the default value if it's null
		if (this->match == null)
			return DEFAULT_MATCH_ATTR;
		return this->match;
	};

	/**
	 * Sets the "match" attribute value of this rule object
	 */
	void setMatch( DOMString match )
	{
		this->match = match;
	};

	/**
	 * Gets the select attribute value for this rule object
	 */
	bool getSelect()
	{
		return this->select;
	};

	/**
	 * Sets the select attribute value for this rule object
	 */
	void setSelect( bool select )
	{
		this->select = select;
	};

	/**
	 * Gets the text value of this rule object
	 */
	DOMString getValue()
	{
		return this->value;
	};

	/**
	 * Sets the text value of this rule object
	 */
	void setValue( DOMString value )
	{
		this->value = value;
	};

	/**
         * Converts the <code>EppXriServiceEndpoint</code> object into an XML element
         *
         * @param doc the XML <code>DOM_Document</code> object
         * @param tag the tag/element name for the <code>EppXriServiceEndpoint</code> object
         *
         * @return an <code>DOM_Element</code> object
         */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppXriServiceEndpoint</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP XRI sepAddType or sepInfType.
	 *
	 * @param root root node for an <code>EppXriServiceEndpoint</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriServiceEndpoint</code> object, or null if the node is
	 *         invalid
	 */
	void setFromXML( const DOM_Node& root );

};

#endif     /* EPPXRISERVICEENDPOINTRULE_HPP */  /* } */
