#if ! defined(EPPCOMMANDUPDATEXRIAUTHORITY_HPP)    /* { */
#define       EPPCOMMANDUPDATEXRIAUTHORITY_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandUpdateXriAuthority.hpp,v 1.6 2006/03/23 10:37:28 wtan Exp $
 */
#include "EppCommandUpdate.hpp"
#include "EppXriAuthority.hpp"

/**
 * This <code>EppCommandUpdateXriAuthority</code> class implements EPP Command Update
 * entity for EPP XRI Authority objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.6 $ $Date: 2006/03/23 10:37:28 $
 */
class EPP_EXPORT EppCommandUpdateXriAuthority : public EppCommandUpdate
{
private:
	static const bool TRUEV;
	static const bool FALSEV;

	DOMString           authId;

        ValueVectorOf<EppXriTrustee>             * trusteeAdded;
        ValueVectorOf<EppXriTrustee>             * trusteeRemoved;

        ValueVectorOf<EppXriRef>                 * refAdded;
        ValueVectorOf<DOMString>                 * refRemoved;

        ValueVectorOf<EppXriServiceEndpoint *>   * sepAdded;
        ValueVectorOf<DOMString>                 * sepRemoved;

	DOMString		  newAuthId;
	EppXriSocialData	* newSocialData;
	EppAuthInfo		* newAuthInfo;
	EppAuthInfo		* authInfo;
	const bool              * newIsEscrow;
	const bool              * newIsContact;
	EppXriTrustee           * newEscrowAgent;
	EppXriTrustee           * newContactAgent;

	bool                      socialDataNullified;
	EppXriSocialData        * addSocialData;

	void initStuff( DOMString authId, DOMString xid )
	{
		this->authId = authId;
		this->clTRID = xid;

		this->trusteeAdded   = new ValueVectorOf<EppXriTrustee>(8);
		this->trusteeRemoved = new ValueVectorOf<EppXriTrustee>(8);

		this->refAdded       = new ValueVectorOf<EppXriRef>(8);
		this->refRemoved     = new ValueVectorOf<DOMString>(8);

		this->sepAdded       = new ValueVectorOf<EppXriServiceEndpoint *>(8);
		this->sepRemoved     = new ValueVectorOf<DOMString>(8);

		this->newAuthId      = null;
		this->newAuthInfo    = null;
		this->newSocialData  = null;
		this->newIsEscrow     = null;
		this->newIsContact    = null;
		this->newEscrowAgent  = null;
		this->newContactAgent = null;

		this->authInfo       = null;

		this->addSocialData  = null;
		this->socialDataNullified = false;
	};

	/**
	 * Frees the Service Endpoint list
	 */
	void freeServiceEndpointAdded()
	{
		if( this->sepAdded == null )
		{
			return;
		}
		for( unsigned int i = 0; i < this->sepAdded->size(); i++ )
		{
			EppXriServiceEndpoint * s = this->sepAdded->elementAt(i);
			if( s != null )
			{
				delete s;
			}
		}
		delete this->sepAdded;
		this->sepAdded = null;
	};

	/**
	 * Adds elements included in the &lt;chg&gt tag of the update command
	 * for an XRI authority object
	 *
	 * @param root the root <code>DOM_Node</code> of the &lt;chg&gt; tag
	 */
	void addNewStuff( const DOM_Node& root );

	/**
	 * Converts a list of EPP XRI trustee objects into XML
	 *
	 * @param doc  the XML <code>DOM_Document</code> object
	 * @param body the XML <code>DOM_Element</code> object to which the list
	 *             of EPP XRI trustee objects is appended
	 * @param list the list of EPP XRI trustee objects to be converted
	 */
	void trusteeToXML( DOM_Document doc, DOM_Element body, ValueVectorOf<EppXriTrustee> * list );

	/**
	 * Converts a list of EPP XRI Trustee objects from XML
	 *
	 * @param root the XML <code>DOM_Node</code> object containing the list
	 *             of EPP XRI Trustee objects
	 * @param trusteeList the list of EPP XRI Trustee objects to be stored
	 */
	void trusteeFromXML( DOM_Node root, ValueVectorOf<EppXriTrustee> * trusteeList );

	/**
	 * Converts a list of EPP XRI reference objects into XML
	 *
	 * @param doc  the XML <code>DOM_Document</code> object
	 * @param body the XML <code>DOM_Element</code> object to which the list
	 *             of EPP XRI reference objects is appended
	 * @param list the list of EPP XRI reference objects to be converted
	 */
	void refToXML( DOM_Document doc, DOM_Element body, ValueVectorOf<EppXriRef> * list );

	/**
	 * Converts a list of EPP XRI reference objects from XML
	 *
	 * @param root the XML <code>DOM_Node</code> object containing the list
	 *             of EPP XRI reference objects
	 * @param refList the list of EPP XRI reference objects to be stored
	 */
	void refFromXML( DOM_Node root, ValueVectorOf<EppXriRef> * refList );

	/**
	 * Converts a list of EPP XRI service endpoint objects into XML
	 *
	 * @param doc  the XML <code>DOM_Document</code> object
	 * @param body the XML <code>DOM_Element</code> object to which the list
	 *             of EPP XRI service endpoint objects is appended
	 * @param list the list of EPP XRI service endpoint objects to be converted
	 */
	void sepToXML( DOM_Document doc, DOM_Element body, ValueVectorOf<EppXriServiceEndpoint *> * list );

	/**
	 * Converts a list of EPP XRI service endpoint objects from XML
	 *
	 * @param root the XML <code>DOM_Node</code> object containing the list
	 *             of EPP XRI service endpoint objects
	 * @param sepList the list of EPP XRI service endpoint objects to be stored
	 */
	void sepFromXML( DOM_Node root, ValueVectorOf<EppXriServiceEndpoint *> * sepList );

	/**
	 * Converts a list of string objects into XML
	 *
	 * @param doc  the XML <code>DOM_Document</code> object
	 * @param body the XML <code>DOM_Element</code> object to which the list
	 *             of string objects is appended
	 * @param tag  the XML tag name for each string object
	 * @param child  the XML tag name for each string object, if it is a child element; or null
	 * @param list the list of string objects to be converted
	 */
	void stringToXML( DOM_Document doc, DOM_Element body, ValueVectorOf<DOMString> * list, DOMString tag, DOMString child );

	/**
	 * Converts a list of string objects from XML
	 *
	 * @param root the XML <code>DOM_Node</code> object containing the list
	 *             of string objects
	 * @param stringList the list of string objects to be stored
	 * @param tag  the XML tag name for each string object
	 * @param child  the XML tag name for each string object, if it is a child element; or null
	 */
	void stringFromXML( DOM_Node root, ValueVectorOf<DOMString> * stringList, DOMString tag, DOMString child );

	/**
	 * Converts a EppXriSocialData object from XML for add/remove operations
	 */
	void socialDataFromXML( DOM_Node root, bool addOrRemove );

public:
	/**
	 * Creates an <code>EppCommandUpdateXriAuthority</code> 
	 */
	EppCommandUpdateXriAuthority()
	{
		this->initStuff(null, null);
	};

	/**
	 * Creates an <code>EppCommandUpdateXriAuthority</code> given the
	 * identifier of the XRI authority object
	 */
	EppCommandUpdateXriAuthority( DOMString authId )
	{
		this->initStuff(authId, null);
	};

	/**
	 * Creates an <code>EppCommandUpdateXriAuthority</code> given the
	 * identifier of the XRI authority object and a client transaction id
	 */
	EppCommandUpdateXriAuthority( DOMString authId, DOMString xid )
	{
		this->initStuff(authId, xid);
	};

	/**
	 * Destricutor
	 */
	~EppCommandUpdateXriAuthority()
	{
		if( this->trusteeAdded != null )
		{
			delete this->trusteeAdded;
			this->trusteeAdded = null;
		}
		if( this->trusteeRemoved != null )
		{
			delete this->trusteeRemoved;
			this->trusteeRemoved = null;
		}
		if( this->refAdded != null )
		{
			delete this->refAdded;
			this->refAdded = null;
		}
		if( this->refRemoved != null )
		{
			delete this->refRemoved;
			this->refRemoved = null;
		}
		freeServiceEndpointAdded();
		if( this->sepRemoved != null )
		{
			delete this->sepRemoved;
			this->sepRemoved = null;
		}
		if( this->newAuthInfo != null )
		{
			delete this->newAuthInfo;
			this->newAuthInfo = null;
		}
		if( this->newSocialData != null )
		{
			delete this->newSocialData;
			this->newSocialData = null;
		}
		if( this->authInfo != null )
		{
			delete this->authInfo;
			this->authInfo = null;
		}
		if( this->addSocialData != null )
		{
			delete this->addSocialData;
			this->addSocialData = null;
		}
		if( this->newEscrowAgent != null )
		{
			delete this->newEscrowAgent;
			this->newEscrowAgent = null;
		}
		if( this->newContactAgent != null )
		{
			delete this->newContactAgent;
			this->newContactAgent = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandUpdateXriAuthority;
	};

	/**
	 * Gets the identifier of the XRI authority object to be updated
	 */
	DOMString getAuthorityId()
	{
		return this->authId;
	};

	/**
	 * Sets the identifier of the XRI authority object to be updated
	 */
	void setAuthorityId( DOMString authId )
	{
		this->authId = authId;
	};

	/**
	 * Gets the list of trustees to be associated with the XRI
	 * authority object
	 */
	ValueVectorOf<EppXriTrustee> * getTrusteeAdded()
	{
		return this->trusteeAdded;
	};

	/**
	 * Adds a trustee to the list of trustees to be associated with
	 * the XRI authority object
	 */
	void addTrustee( EppXriTrustee trustee )
	{
		this->trusteeAdded->addElement(trustee);
	};

	/**
	 * Gets the list of trustees to be removed from the XRI
	 * authority object
	 */
	ValueVectorOf<EppXriTrustee> * getTrusteeRemoved()
	{
		return this->trusteeRemoved;
	};

	/**
	 * Adds a trustee to the list of trustees to be removed from
	 * the XRI authority object
	 */
	void removeTrustee( EppXriTrustee trustee )
	{
		this->trusteeRemoved->addElement(trustee);
	};

	/**
	 * Gets the list of references to be associated with
	 * the XRI authority object
	 */
	ValueVectorOf<EppXriRef> * getRefAdded()
	{
		return this->refAdded;
	};

	/**
	 * Adds a reference to the list of references to
	 * be associated with the XRI authority object
	 */
	void addRef( DOMString ref )
	{
		EppXriRef aref(ref);
		this->refAdded->addElement(aref);
	};

	/**
	 * Adds a reference to the list of references to
	 * be associated with the XRI authority object
	 */
	void addRef( EppXriRef ref )
	{
		this->refAdded->addElement(ref);
	};

	/**
	 * Gets the list of references to be removed from the XRI
	 * authority object
	 */
	ValueVectorOf<DOMString> * getRefRemoved()
	{
		return this->refRemoved;
	};

	/**
	 * Adds a reference to the list of references to
	 * be removed from the XRI authority object
	 */
	void removeRef( DOMString ref )
	{
		this->refRemoved->addElement(ref);
	};

	/**
	 * Gets the list of service endpoints to be associated with the XRI authority
	 * object
	 */
	ValueVectorOf<EppXriServiceEndpoint *> * getServiceEndpointAdded()
	{
		return this->sepAdded;
	};

	/**
	 * Adds an service endpoint to the list of service endpoints to be associated with the XRI
	 * authority object
	 */
	void addServiceEndpoint( EppXriServiceEndpoint * sep )
	{
		this->sepAdded->addElement(sep);
	};

	/**
	 * Gets the list of identifiers of service endpoints to be removed from the
	 * XRI authority object
	 */
	ValueVectorOf<DOMString> * getServiceEndpointRemoved()
	{
		return this->sepRemoved;
	};

	/**
	 * Adds the identifier of an service endpoint to the list of identifiers of
	 * service endpoints to be removed from the XRI authority object
	 */
	void removeServiceEndpoint( DOMString id )
	{
		this->sepRemoved->addElement(id);
	};

	/*
	 * Gets the new identifier for the XRI authority object, or null if
	 * the identifier of the XRI authority object is not to be changed
	 */
	DOMString getNewAuthorityId()
	{
		return this->newAuthId;
	};

	/**
	 * Sets the new identifier for the XRI authority object if it needs
	 * to be changed
	 */
	void setNewAuthorityId( DOMString newAuthId )
	{
		this->newAuthId = newAuthId;
	};

	/*
	 * Gets the new isEscrow flag for the XRI authority object, or null if
	 * the identifier of the XRI authority object is not to be changed
	 */
	const bool * getNewIsEscrow()
	{
		return this->newIsEscrow;
	};

	/**
	 * Sets the new isEscrow flag for the XRI authority object if it needs
	 * to be changed
	 */
	void setNewIsEscrow( bool newIsEscrow )
	{
		if (newIsEscrow)
			this->newIsEscrow = &TRUEV;
		else
			this->newIsEscrow = &FALSEV;
	};

	/*
	 * Gets the new isContact flag for the XRI authority object, or null if
	 * the identifier of the XRI authority object is not to be changed
	 */
	const bool * getNewIsContact()
	{
		return this->newIsContact;
	};

	/**
	 * Sets the new isContact flag for the XRI authority object if it needs
	 * to be changed
	 */
	void setNewIsContact( bool newIsContact )
	{
		if (newIsContact)
			this->newIsContact = &TRUEV;
		else
			this->newIsContact = &FALSEV;
	};

	/*
	 * Gets the new escrow agent for the XRI authority object, or null if
	 * the identifier of the XRI authority object is not to be changed
	 */
	EppXriTrustee * getNewEscrowAgent()
	{
		return this->newEscrowAgent;
	};

	/**
	 * Sets the new escrow agent for the XRI authority object if it needs
	 * to be changed
	 */
	void setNewEscrowAgent( EppXriTrustee * newEscrowAgent )
	{
		if (this->newEscrowAgent)
			delete this->newEscrowAgent;
		if (newEscrowAgent == null) {
			this->newEscrowAgent = null;
			return;
		}
		else {
			this->newEscrowAgent = new EppXriTrustee();
			if (this->newEscrowAgent)
				*(this->newEscrowAgent) = *newEscrowAgent;
		}
	};

	/*
	 * Gets the new contact agent for the XRI authority object, or null if
	 * the identifier of the XRI authority object is not to be changed
	 */
	EppXriTrustee * getNewContactAgent()
	{
		return this->newContactAgent;
	};

	/**
	 * Sets the new contact agent for the XRI authority object if it needs
	 * to be changed
	 */
	void setNewContactAgent( EppXriTrustee * newContactAgent )
	{
		if (this->newContactAgent)
			delete this->newContactAgent;
		if (newContactAgent == null) {
			this->newContactAgent = null;
		}
		else {
			this->newContactAgent = new EppXriTrustee();
			if (this->newEscrowAgent)
				*(this->newContactAgent) = *newContactAgent;
		}
	};

	/**
	 * Gets the new/updated social data associated with the XRI authority object
	 */
	EppXriSocialData * getNewSocialData()
	{
		return this->newSocialData;
	};

	/**
	 * Sets the new/updated social data associated with the XRI authority object
	 */
	void setNewSocialData( EppXriSocialData * newSocialData )
	{
		if( this->newSocialData != null )
		{
			delete this->newSocialData;
		}
		if( this->addSocialData != null )
		{
			delete this->addSocialData;
		}
		this->addSocialData = null;
		this->newSocialData = newSocialData;
		this->socialDataNullified = false;
	};

	/**
	 * Gets the social data to be associated with the XRI authority object
	 */
	EppXriSocialData * getSocialData()
	{
		return this->addSocialData;
	};

	/**
	 * Sets the social data to be associated with the XRI authority object
	 */
	void setSocialData( EppXriSocialData * addSocialData )
	{
		if( this->newSocialData != null )
		{
			delete this->newSocialData;
		}
		if( this->addSocialData != null )
		{
			delete this->addSocialData;
		}
		this->newSocialData = null;
		this->addSocialData = addSocialData;
		this->socialDataNullified = false;
	};

	/**
	 * Gets the flag for nullifying existing social data associated
	 * with the XRI authority object
	 */
	bool isSocialDataNullified()
	{
		return this->socialDataNullified;
	};

	/**
	 * Sets the flag for nullifying existing social data associated
	 * with the XRI authority object
	 */
	void nullifySocialData()
	{
		if( this->newSocialData != null )
		{
			delete this->newSocialData;
		}
		if( this->addSocialData != null )
		{
			delete this->addSocialData;
		}
		this->newSocialData = null;
		this->addSocialData = null;
		this->socialDataNullified = true;
	};

	/*
	 * Gets the new authorization information for the XRI authority object, or null if
	 * the authorization information of the XRI authority object is not to be changed
	 */
	EppAuthInfo * getNewAuthInfo()
	{
		return this->newAuthInfo;
	};

	/**
	 * Sets the new authorization information for the XRI authority object if it needs
	 * to be changed
	 */
	void setNewAuthInfo( EppAuthInfo authInfo )
	{
		if( this->newAuthInfo == null )
		{
			this->newAuthInfo = new EppAuthInfo();
		}
		*(this->newAuthInfo) = authInfo;
	};

	/**
	 * Gets the authorization info for the update operation
	 */
	EppAuthInfo * getAuthInfo()
	{
		return this->authInfo;
	};

	/**
	 * Sets the authorization info for the update operation
	 */
	void setAuthInfo( EppAuthInfo authInfo )
	{
		if( this->authInfo == null )
		{
			this->authInfo = new EppAuthInfo();
		}
		*(this->authInfo) = authInfo;
	};

	/**
	 * Converts the <code>EppCommandUpdateXriAuthority</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the 
	 *            <code>EppCommandUpdateXriAuthority</code> object
	 *
	 * @return an <code>DOM_Element</code> object 
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandUpdateXriAuthority</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Update entity for an EPP XRI Authority object.
	 *
	 * @param root root node for an <code>EppCommandUpdateXriAuthority</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandUpdateXriAuthority</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandUpdateXriAuthority * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDUPDATEXRIAUTHORITY_HPP */  /* } */
