#if ! defined(EPPXRIAUTHORITY_HPP)    /* { */
#define       EPPXRIAUTHORITY_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppXriAuthority.hpp,v 1.11 2006/03/18 12:27:24 wtan Exp $
 */
#include "EppEntity.hpp"
#include "EppObject.hpp"
#include "EppXriTrustee.hpp"
#include "EppXriSocialData.hpp"
#include "EppXriRef.hpp"
#include "EppXriServiceEndpoint.hpp"
#include "EppXriNumberAttribute.hpp"

/**
 * This <code>EppXriAuthority</code> class implements EPP XRI Authority objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.11 $ $Date: 2006/03/18 12:27:24 $
 */
class EPP_EXPORT EppXriAuthority : public EppObject
{
private:
	static const bool trueValue;
	static const bool falseValue;

	DOMString                                  authId;
	const bool                               * isEscrow;
	const bool                               * isContact;
	EppXriTrustee                            * escrowAgent;
	EppXriTrustee                            * contactAgent;
	EppXriSocialData                         * socialData;
	ValueVectorOf<EppXriTrustee>             * trustee;
	ValueVectorOf<EppXriRef>                 * ref;
	ValueVectorOf<EppXriServiceEndpoint *>   * sep;
	ValueVectorOf<DOMString>                 * iname;
	ValueVectorOf<EppXriNumberAttribute>     * inumber;
	ValueVectorOf<DOMString>                 * iservice;

	/**
	 * Frees the Service Endpoint list
	 */
	void freeServiceEndpoint()
	{
		if( this->sep == null )
		{
			return;
		}
		for( unsigned int i = 0; i < this->sep->size(); i++ )
		{
			EppXriServiceEndpoint * s = this->sep->elementAt(i);
			if( s != null )
			{
				delete s;
			}
		}
		delete this->sep;
		this->sep = null;
	};

public:
	/**
	 * Authority status - clientAssociateProhibited
	 */
	static const char * STATUS_CLIENT_ASSOCIATE_PROHIBITED;
	/**
	 * Authority status - clientDeleteProhibited
	 */
	static const char * STATUS_CLIENT_DELETE_PROHIBITED;
	/**
	 * Authority status - clientHold
	 */
	static const char * STATUS_CLIENT_HOLD;
	/**
	 * Authority status - clientTransferProhibited
	 */
	static const char * STATUS_CLIENT_TRANSFER_PROHIBITED;
	/**
	 * Authority status - clientUpdateProhibited
	 */
	static const char * STATUS_CLIENT_UPDATE_PROHIBITED;
	/**
	 * Authority status - linked
	 */
	static const char * STATUS_LINKED;
	/**
	 * Authority status - ok
	 */
	static const char * STATUS_OK;
	/**
	 * Authority status - pendingCreate
	 */
	static const char * STATUS_PENDING_CREATE;
	/**
	 * Authority status - pendingDelete
	 */
	static const char * STATUS_PENDING_DELETE;
	/**
	 * Authority status - pendingINameTransfer
	 */
	static const char * STATUS_PENDING_INAME_TRANSFER;
	/**
	 * Authority status - pendingTransfer
	 */
	static const char * STATUS_PENDING_TRANSFER;
	/**
	 * Authority status - pendingUpdate
	 */
	static const char * STATUS_PENDING_UPDATE;
	/**
	 * Authority status - serverAssociateProhibited
	 */
	static const char * STATUS_SERVER_ASSOCIATE_PROHIBITED;
	/**
	 * Authority status - serverDeleteProhibited
	 */
	static const char * STATUS_SERVER_DELETE_PROHIBITED;
	/**
	 * Authority status - serverHold
	 */
	static const char * STATUS_SERVER_HOLD;
	/**
	 * Authority status - serverTransferProhibited
	 */
	static const char * STATUS_SERVER_TRANSFER_PROHIBITED;
	/**
	 * Authority status - serverUpdateProhibited
	 */
	static const char * STATUS_SERVER_UPDATE_PROHIBITED;

	/**
	 * Creates an <code>EppXriAuthority</code> object
	 */
	EppXriAuthority()
	{
		this->authId       = null;
		this->isEscrow     = null;
		this->isContact    = null;
		this->escrowAgent  = null;
		this->contactAgent = null;
		this->socialData   = null;
		this->trustee      = new ValueVectorOf<EppXriTrustee>            (3);
		this->ref          = new ValueVectorOf<EppXriRef>    (3);
		this->sep          = new ValueVectorOf<EppXriServiceEndpoint *>  (3);
		this->iname        = new ValueVectorOf<DOMString>                (3);
		this->inumber      = new ValueVectorOf<EppXriNumberAttribute>   (3);
		this->iservice     = new ValueVectorOf<DOMString>                (3);
	}

	/**
	 * Creates an <code>EppXriAuthority</code> object with an XRI authority identifier
	 */
	EppXriAuthority( DOMString authId )
	{
		this->authId       = authId;
		this->isEscrow     = null;
		this->isContact    = null;
		this->escrowAgent  = null;
		this->contactAgent = null;
		this->socialData   = null;
		this->trustee      = new ValueVectorOf<EppXriTrustee>            (3);
		this->ref          = new ValueVectorOf<EppXriRef>    (3);
		this->sep          = new ValueVectorOf<EppXriServiceEndpoint *>  (3);
		this->iname        = new ValueVectorOf<DOMString>                (3);
		this->inumber      = new ValueVectorOf<EppXriNumberAttribute>   (3);
		this->iservice     = new ValueVectorOf<DOMString>                (3);
	}

	/**
	 * Destructor
	 */
	~EppXriAuthority()
	{
		EppObject::freeCommon();
		if( this->socialData != null )
		{
			delete this->socialData;
			this->socialData = null;
		}
		if( this->trustee != null )
		{
			delete this->trustee;
			this->trustee = null;
		}
		if( this->ref != null )
		{
			delete this->ref;
			this->ref = null;
		}
		if( this->sep != null )
		{
			freeServiceEndpoint();
		}
		if( this->iname != null )
		{
			delete this->iname;
			this->iname = null;
		}
		if( this->inumber != null )
		{
			delete this->inumber;
			this->inumber = null;
		}
		if( this->iservice != null )
		{
			delete this->iservice;
			this->iservice = null;
		}
		if( this->escrowAgent != null )
		{
			delete this->escrowAgent;
			this->escrowAgent = null;
		}
		if( this->contactAgent != null )
		{
			delete this->contactAgent;
			this->contactAgent = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
        virtual int getEntityType()
	{
		return EppEntity::TYPE_EppXriAuthority;
	};

	/**
	 * Gets the XRI authority identifier
	 */
	DOMString getAuthorityId()
	{
		return this->authId;
	};

	/**
	 * Sets the XRI authority identifier
	 */
	void setAuthorityId( DOMString authId )
	{
		this->authId = authId;
	};

	/**
	 * Gets the XRI authority isEscrow flag. If the flag was never set, this method would
	 * return a null pointer.
	 */
	const bool *getIsEscrow()
	{
		return this->isEscrow;
	};

	/**
	 * Sets the XRI authority isEscrow flag
	 */
	void setIsEscrow( bool isEscrow )
	{
		if (isEscrow)
			this->isEscrow = &trueValue;
		else
			this->isEscrow = &falseValue;
	};

	/**
	 * Gets the XRI authority isContact flag. If the flag was never set, this method would
	 * return a null pointer.
	 */
	const bool *getIsContact()
	{
		return this->isContact;
	};

	/**
	 * Sets the XRI authority isContact flag
	 */
	void setIsContact( bool isContact )
	{
		if (isContact)
			this->isContact = &trueValue;
		else
			this->isContact = &falseValue;
	};

	/**
	 * Gets the XRI authority escrowAgent (do not free the memory returned)
	 */
	EppXriTrustee * getEscrowAgent()
	{
		return this->escrowAgent;
	};

	/**
	 * Sets the XRI authority escrowAgent
	 */
	void setEscrowAgent( EppXriTrustee escrowAgent )
	{
		if (this->escrowAgent)
			delete this->escrowAgent;
		this->escrowAgent = new EppXriTrustee(escrowAgent);
	};

	/**
	 * Gets the XRI authority contactAgent (do not free the memory returned)
	 */
	EppXriTrustee * getContactAgent()
	{
		return this->contactAgent;
	};

	/**
	 * Sets the XRI authority contactAgent
	 */
	void setContactAgent( EppXriTrustee contactAgent )
	{
		if (this->contactAgent)
			delete this->contactAgent;
		this->contactAgent = new EppXriTrustee(contactAgent);
	};

	/**
	 * Gets the social data associated with the XRI authority object
	 */
	EppXriSocialData * getSocialData()
	{
		return this->socialData;
	}

	/**
	 * Gets the social data associated with the XRI authority object
	 */
	void setSocialData( EppXriSocialData * socialData )
	{
		if( this->socialData != null )
		{
			delete this->socialData;
		}
		this->socialData = socialData;
	};

	/**
	 * Gets a list of trustees associated with the XRI authority object
	 */
	ValueVectorOf<EppXriTrustee> * getTrustee()
	{
		return this->trustee;
	};

	/**
	 * Adds a trustee associated with the XRI authority object
	 *
	 * <P><B>Note:</B> This method should be only called by the EPP server, and
	 *       an EPP client should not perform this operation.
	 */
	void addTrustee( EppXriTrustee trustee )
	{
		this->trustee->addElement(trustee);
	};

	/**
	 * Gets a list of references associated with the XRI authority object
	 */
	ValueVectorOf<EppXriRef> * getRef()
	{
		return this->ref;
	};

	/**
	 * Adds a reference associated with the XRI authority object
	 *
	 * <P><B>Note:</B> This method should be only called by the EPP server, and
	 *       an EPP client should not perform this operation.
	 */
	void addRef( EppXriRef ref )
	{
		this->ref->addElement(ref);
	};

	/**
	 * Gets a list of XRI service endpoint (SEP) associated with the XRI authority object
	 */
	ValueVectorOf<EppXriServiceEndpoint *> * getServiceEndpoint()
	{
		return this->sep;
	};

	/**
	 * Adds a XRI service service endpoint (SEP) associated with the XRI authority object
	 *
	 * <P><B>Note:</B> This method should be only called by the EPP server, and
	 *       an EPP client should not perform this operation.
	 */
	void addServiceEndpoint( EppXriServiceEndpoint * sep )
	{
		if( sep != null )
		{
			this->sep->addElement(sep);
		}
	};

	/**
	 * Gets a list of i-names associated with the XRI authority object
	 *
	 * <P><B>Note:</B> This method should be only called by the EPP server, and
	 *       an EPP client should not perform this operation.
	 */
	ValueVectorOf<DOMString> * getIName()
	{
		return this->iname;
	};

	/**
	 * Adds an i-name associated with the XRI authority object
	 *
	 * <P><B>Note:</B> This method should be only called by the EPP server, and
	 *       an EPP client should not perform this operation.
	 */
	void addIName( DOMString iname )
	{
		this->iname->addElement(iname);
	};

	/**
	 * Gets a list of i-numbers associated with the XRI authority object
	 */
	ValueVectorOf<EppXriNumberAttribute> * getINumber()
	{
		return this->inumber;
	};

	/**
	 * Adds an i-number associated with the XRI authority object
	 *
	 * <P><B>Note:</B> This method should be only called by the EPP server, and
	 *       an EPP client should not perform this operation.
	 */
	void addINumber( DOMString inumber )
	{
		EppXriNumberAttribute xin;
		xin.setINumber(inumber);
		this->inumber->addElement(xin);
	};

	/**
	 * Adds an i-number associated with the XRI authority object
	 *
	 * <P><B>Note:</B> This method should be only called by the EPP server, and
	 *       an EPP client should not perform this operation.
	 */
	void addINumber( DOMString inumber, unsigned short int priority )
	{
		EppXriNumberAttribute xin(inumber, priority);
		xin.setINumber(inumber);
		xin.setPriority(priority);
		this->inumber->addElement(xin);
	};

	/**
	 * Adds an i-number associated with the XRI authority object
	 *
	 * <P><B>Note:</B> This method should be only called by the EPP server, and
	 *       an EPP client should not perform this operation.
	 */
	void addINumber( EppXriNumberAttribute xin )
	{
		this->inumber->addElement(xin);
	};

	/**
	 * Gets a list of identifiers of XRI I-Service objects associated with the XRI authority object
	 */
	ValueVectorOf<DOMString> * getIService()
	{
		return this->iservice;
	};

	/**
	 * Adds the identifier of an XRI I-Service object associated with the XRI authority object
	 *
	 * <P><B>Note:</B> This method should be only called by the EPP server, and
	 *       an EPP client should not perform this operation.
	 */
	void addIService( DOMString iServiceId )
	{
		this->iservice->addElement(iServiceId);
	};

	/**
	 * Converts the <code>EppXriAuthority</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the <code>EppXriAuthority</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppXriAuthority</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP Authority type.
	 *
	 * @param root root node for an <code>EppXriAuthority</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriAuthority</code> object, or null if the node
	 *         is invalid
	 */
	static EppXriAuthority * fromXML( const DOM_Node& root );

#if 0
	/**
	 * Creates an <code>EppCommandDeleteXriAuthority</code> object for
	 * deleting an EPP XRI Authority object from the registry.
	 *
	 * @param authId the identifier of the XRI authority object to be deleted
	 * @param xid    the client transaction id associated with the operation
	 */
	public static EppCommandDeleteXriAuthority delete( String authId, String xid )
	{
		return new EppCommandDeleteXriAuthority(authId, xid);
	}

	/**
	 * Creates an <code>EppCommandInfoXriAuthority</code> object for
	 * querying the details of an EPP XRI Authority object
	 *
	 * @param authId the identifier of the XRI authority object to be queried
	 * @param xid    the client transaction id associated with the operation
	 */
	public static EppCommandInfoXriAuthority info( String authId, String xid )
	{
		return new EppCommandInfoXriAuthority(authId, xid);
	}

	/**
	 * Creates an <code>EppCommandCheckXriAuthority</code> object for
	 * checking the existance of EPP XRI Authority objects in the registry.
	 * Identifiers of EPP XRI Authority objects can be added via the
	 * <code>add</code> or <code>addAuthorityId</code> methods.
	 *
	 * @param xid  the client transaction id associated with the operation
	 */
	public static EppCommandCheckXriAuthority check( String xid )
	{
		return new EppCommandCheckXriAuthority(xid);
	}

	/**
	 * Creates an <code>EppCommandTransferXriAuthority</code> object for
	 * transfering an EPP XRI Authority object in the registry. The operation
	 * type, transfer token, target authority and authorization information associated
	 * with the operation should be specified via <code>setOperation</code>,
	 * <code>setTransferToken</code>, <code>setTarget</code>, and <code>setAuthInfo</code> method.
	 *
	 * @param authId the identifier of the XRI authority object to be transferred
	 * @param xid    the client transaction id associated with the operation
	 */
	public static EppCommandTransferXriAuthority transfer( String authId, String xid )
	{
		return new EppCommandTransferXriAuthority(authId, xid);
	}

	/**
	 * Creates an <code>EppCommandUpdateXriAuthority</code> object for
	 * updating an EPP Authority object in the registry. The actual update
	 * information should be specified via the various methods defined
	 * for the <code>EppCommandUpdateXriAuthority</code> object.
	 *
	 * @param authId the identifier of the XRI authority object to be updated
	 * @param xid    the client transaction id associated with the operation
	 */
	public static EppCommandUpdateXriAuthority update( String authId, String xid )
	{
		return new EppCommandUpdateXriAuthority(authId, xid);
	}
#endif

	DOMString toString()
	{
		return EppEntity::toString(DOMString("xriAU"));
	};
};

#endif     /* EPPXRIAUTHORITY_HPP */  /* } */
