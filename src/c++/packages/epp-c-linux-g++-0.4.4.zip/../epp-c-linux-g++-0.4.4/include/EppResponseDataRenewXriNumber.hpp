#if ! defined(EPPRESPONSEDATARENEWINUMBER_HPP)    /* { */
#define       EPPRESPONSEDATARENEWINUMBER_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataRenewXriNumber.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include <time.h>
#include "EppResponseDataRenew.hpp"

/**
 * This <code>EppResponseDataRenewXriNumber</code> class implements EPP
 * Response Data entity for EPP Command Renew of EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataRenewXriNumber : public EppResponseDataRenew
{
private:
	DOMString inumber;
	time_t    exDate;

public:
	/**
	 * Creates an <code>EppResponseDataRenewXriNumber</code> object
	 *
	 * @param inumber the i-number of the XRI i-number object renewed
	 */
	EppResponseDataRenewXriNumber()
	{
		this->inumber = null;
		this->roid = null;
		this->exDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataRenewXriNumber</code> object
	 *
	 * @param inumber the i-number of the XRI i-number object renewed
	 */
	EppResponseDataRenewXriNumber( DOMString inumber )
	{
		this->inumber = inumber;
		this->roid = null;
		this->exDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataRenewXriNumber</code> object
	 *
	 * @param inumber the i-number of the XRI i-number object renewed
	 * @param exDate the expiration date of the XRI i-number
	 *               object renewed
	 */
	EppResponseDataRenewXriNumber( DOMString inumber, time_t exDate )
	{
		this->inumber = inumber;
		this->roid = null;
		this->exDate = exDate;
	};

	/**
	 * Renews an <code>EppResponseDataRenewXriNumber</code> object
	 *
	 * @param inumber the inumber of the <code>EppXriNumber</code> object renewed
	 * @param roid the ROID of the <code>EppXriNumber</code> object renewed
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	EppResponseDataRenewXriNumber( DOMString inumber, DOMString roid )
	{
		this->inumber = inumber;
		this->roid = roid;
		this->exDate = 0;
	};

	/**
	 * Renews an <code>EppResponseDataRenewXriNumber</code> object
	 *
	 * @param inumber   the inumber of the <code>EppXriNumber</code> object renewed
	 * @param roid   the ROID of the <code>EppXriNumber</code> object renewed
	 * @param exDate the expiration date of the <code>EppXriNumber</code>
	 *               object renewed
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	EppResponseDataRenewXriNumber( DOMString inumber, DOMString roid, time_t exDate )
	{
		this->inumber = inumber;
		this->roid = roid;
		this->exDate = exDate;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataRenewXriNumber() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataRenewXriNumber;
	};

	/**
	 * Gets the inumber of the XRI i-number renewed
	 */
	DOMString getINumber()
	{
		return this->inumber;
	};

	/**
	 * Sets the inumber of the XRI i-number renewed
	 */
	void setINumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Gets expiration date of the XRI i-number renewed
	 */
	time_t getDateExpired()
	{
		return this->exDate;
	};

	/**
	 * Sets expiration date of the XRI i-number renewed
	 */
	void setDateExpired( time_t exDate )
	{
		this->exDate = exDate;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataRenewXriNumber</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XRI I-Number object
	 *
	 * @param root root node for an <code>EppResponseDataRenewXriNumber</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataRenewXriNumber</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataRenewXriNumber * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataRenewXriNumber</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataRenewXriNumber</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATARENEWINUMBER_HPP */  /* } */
