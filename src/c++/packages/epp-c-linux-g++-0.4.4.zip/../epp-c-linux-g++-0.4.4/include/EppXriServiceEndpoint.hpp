#if ! defined(EPPXRISERVICEENDPOINT_HPP)    /* { */
#define       EPPXRISERVICEENDPOINT_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppXriServiceEndpoint.hpp,v 1.5 2006/03/13 04:13:25 wtan Exp $
 */
#include "EppEntity.hpp"
#include "EppXriURI.hpp"
#include "util/ValueVectorOf.hpp"
#include "EppXriServiceEndpointType.hpp"
#include "EppXriServiceEndpointPath.hpp"
#include "EppXriServiceEndpointMediaType.hpp"

#define MAX_NUM_OF_SEP_TYPES       5
#define MAX_NUM_OF_SEP_PATHS       5
#define MAX_NUM_OF_SEP_URIS        5
#define MAX_NUM_OF_SEP_MEDIA_TYPES 5

/**
 * This <code>EppXriServiceEndpoint</code> class defines local access URI
 * information associated with XRI authority objects.  It
 * implements XRI sepAddType and sepInfType defined
 * in the XRI authority schema file.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.5 $ $Date: 2006/03/13 04:13:25 $
 */
class EPP_EXPORT EppXriServiceEndpoint : public EppEntity
{
private:
	DOMString                  id;
	unsigned short int         priority;
	DOMString                  authority;
	ValueVectorOf<EppXriServiceEndpointType> * type;
	ValueVectorOf<EppXriServiceEndpointPath> * path;
	ValueVectorOf<EppXriURI> * uri;
	ValueVectorOf<EppXriServiceEndpointMediaType> * mediaType;

public:
	/**
	 * Default priority value - 10
	 */
	static const unsigned short int DEFAULT_PRIORITY;

	/**
	 * Creates an <code>EppXriServiceEndpoint</code> object
	 */
	EppXriServiceEndpoint()
	{
		this->id        = null;
		this->priority  = DEFAULT_PRIORITY;
		this->authority = null;
		this->type      = new ValueVectorOf<EppXriServiceEndpointType>(MAX_NUM_OF_SEP_TYPES);
		this->path      = new ValueVectorOf<EppXriServiceEndpointPath>(MAX_NUM_OF_SEP_PATHS);
		this->uri       = new ValueVectorOf<EppXriURI>(MAX_NUM_OF_SEP_URIS);
		this->mediaType = new ValueVectorOf<EppXriServiceEndpointMediaType>(MAX_NUM_OF_SEP_MEDIA_TYPES);
	};

	/**
	 * Creates an <code>EppXriServiceEndpoint</code> object with an identifier
	 */
	EppXriServiceEndpoint( DOMString id )
	{
		this->id        = id;
		this->priority  = DEFAULT_PRIORITY;
		this->authority = null;
		this->type      = new ValueVectorOf<EppXriServiceEndpointType>(MAX_NUM_OF_SEP_TYPES);
		this->path      = new ValueVectorOf<EppXriServiceEndpointPath>(MAX_NUM_OF_SEP_PATHS);
		this->uri       = new ValueVectorOf<EppXriURI>(MAX_NUM_OF_SEP_URIS);
		this->mediaType = new ValueVectorOf<EppXriServiceEndpointMediaType>(MAX_NUM_OF_SEP_MEDIA_TYPES);
	};

	/**
	 * Destructor
	 */
	~EppXriServiceEndpoint()
	{
		if( this->type )
		{
			delete this->type;
			this->type = null;
		}
		if( this->path )
		{
			delete this->path;
			this->path = null;
		}
		if( this->uri != null )
		{
			delete this->uri;
			this->uri = null;
		}
		if( this->mediaType )
		{
			delete this->mediaType;
			this->mediaType = null;
		}
	};

	/**
	 * Gets the identifier of this XRI Service Endpoint object
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the identifier of this XRI Service Endpoint object
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Gets the priority value for this XRI Service Endpoint object
	 */
	unsigned short int getPriority()
	{
		return this->priority;
	};

	/**
	 * Sets the priority value for this XRI Service Endpoint object
	 */
	void setPriority( unsigned short int priority )
	{
		this->priority = priority;
	};

	/**
	 * Gets the list of service types of this XRI Service Endpoint object
	 */
	ValueVectorOf<EppXriServiceEndpointType> * getType()
	{
		return this->type;
	};

	/**
	 * Adds a service type to this XRI Service Endpoint object
	 */
	void addType( DOMString type )
	{
		addType(type, null, null);
	};

	/**
	 * Adds a service type to this XRI Service Endpoint object
	 */
	void addType( DOMString type, DOMString match, bool select )
	{
		EppXriServiceEndpointType t(type, match, select);
		addType(t);
	};

	/**
	 * Adds a service type to this XRI Service Endpoint object
	 */
	void addType( EppXriServiceEndpointType type )
	{
		this->type->addElement(type);
	};

	/**
	 * Gets the list of paths of this XRI Service Endpoint object
	 */
	ValueVectorOf<EppXriServiceEndpointPath> * getPath()
	{
		return this->path;
	};

	/**
	 * Adds a path to this XRI Service Endpoint object
	 */
	void addPath( DOMString path )
	{
		addPath(path, null, null);
	};

	/**
	 * Adds a path to this XRI Service Endpoint object
	 */
	void addPath( DOMString path, DOMString match, bool select )
	{
		EppXriServiceEndpointPath p(path, match, select);
		addPath(p);
	};

	/**
	 * Adds a path to this XRI Service Endpoint object
	 */
	void addPath( EppXriServiceEndpointPath path )
	{
		this->path->addElement(path);
	};


	/**
	 * Gets the identifier of the authority that provides the services of this XRI Service Endpoint object
	 */
	DOMString getAuthority()
	{
		return this->authority;
	};

	/**
	 * Sets the identifier of the authority that provides the services of this XRI Service Endpoint object
	 */
	void setAuthority( DOMString authority )
	{
		this->authority = authority;
	};

	/**
	 * Gets the URIs associated with this XRI Service Endpoint object
	 */
	ValueVectorOf<EppXriURI> * getURI()
	{
		return this->uri;
	};

	/**
	 * Adds a URI to be associated with this XRI Service Endpoint object with the default priority value
	 */
	void addURI( DOMString uri )
	{
		EppXriURI t(uri);
		this->uri->addElement(t);
	};

	/**
	 * Adds a URI to be associated with this XRI Service Endpoint object with a priority value
	 */
	void addURI( DOMString uri, unsigned short int priority, DOMString append )
	{
		EppXriURI t(uri, priority, append);
		this->uri->addElement(t);
	};

	/**
	 * Adds a URI to be associated with this XRI Service Endpoint object
	 */
	void addURI( EppXriURI uri )
	{
		this->uri->addElement(uri);
	};

	/**
	 * Gets the media types associated with this XRI Service Endpoint object
	 */
	ValueVectorOf<EppXriServiceEndpointMediaType> * getMediaType()
	{
		return this->mediaType;
	};

	/**
	 * Adds a media type to be associated with this XRI Service Endpoint object
	 */
	void addMediaType( DOMString mediaType )
	{
		addMediaType(mediaType, null, null);
	};

	/**
	 * Adds a media type to be associated with this XRI Service Endpoint object
	 */
	void addMediaType( DOMString mediaType, DOMString match, bool select )
	{
		EppXriServiceEndpointMediaType m(mediaType, match, select);
		addMediaType(m);
	};

	/**
	 * Adds a media type to be associated with this XRI Service Endpoint object
	 */
	void addMediaType( EppXriServiceEndpointMediaType mediaType )
	{
		this->mediaType->addElement(mediaType);
	};

	/**
         * Converts the <code>EppXriServiceEndpoint</code> object into an XML element
         *
         * @param doc the XML <code>DOM_Document</code> object
         * @param tag the tag/element name for the <code>EppXriServiceEndpoint</code> object
         *
         * @return an <code>DOM_Element</code> object
         */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppXriServiceEndpoint</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP XRI sepAddType or sepInfType.
	 *
	 * @param root root node for an <code>EppXriServiceEndpoint</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriServiceEndpoint</code> object, or null if the node is
	 *         invalid
	 */
	static EppXriServiceEndpoint * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("sep"));
	};
};

#endif     /* EPPXRISERVICEENDPOINT_HPP */  /* } */
