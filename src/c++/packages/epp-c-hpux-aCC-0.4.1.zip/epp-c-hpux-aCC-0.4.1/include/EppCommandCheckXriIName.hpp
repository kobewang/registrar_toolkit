#if ! defined(EPPCOMMANDCHECKXRIINAME_HPP)    /* { */
#define       EPPCOMMANDCHECKXRIINAME_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandCheck.hpp"

#define	MAX_NUM_OF_XRIINAMES	16

/**
 * This <code>EppCommandCheckXriIName</code> class implements EPP Command Check
 * entity for EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppCommandCheckXriIName : public EppCommandCheck
{
private:
	ValueVectorOf<DOMString> * inames;

public:
	/**
	 * Creates an <code>EppCommandCheckXriIName</code> object
	 */
	EppCommandCheckXriIName()
	{
		this->inames = new ValueVectorOf<DOMString>(MAX_NUM_OF_XRIINAMES);
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandCheckXriIName</code> object, given a
	 * client transaction id associated with the operation
	 */
	EppCommandCheckXriIName( DOMString xid )
	{
		this->inames = new ValueVectorOf<DOMString>(MAX_NUM_OF_XRIINAMES);
		this->clTRID = xid;
	}

	/**
	 * Destructor
	 */
	~EppCommandCheckXriIName()
	{
		if( this->inames != null )
		{
			delete this->inames;
			this->inames = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandCheckXriIName;
	};

	/**
	 * Gets the list of the i-names of the XRI i-name objects to be checked
	 */
	ValueVectorOf<DOMString> * getIName()
	{
		return this->inames;
	};

	/**
	 * Gets the list of the i-names of the XRI i-name objects to be checked.
	 *
	 * <P><B>Note:</B> This is an alias for <code>getIName</code>
	 */
	ValueVectorOf<DOMString> * get()
	{
		return this->getIName();
	};

	/**
	 * Adds the i-name of an XRI i-name object to the list of i-names of XRI i-name
	 * objects be checked
	 */
	void addIName( DOMString iname )
	{
		this->inames->addElement(iname);
	};

	/**
	 * Adds the i-name of an XRI i-name object to the list of i-names of XRI i-name
	 * objects be checked.
	 *
	 * <P><B>Note:</B> This is an alias for <code>addIName</code>
	 */
	void add( DOMString iname )
	{
		this->addIName(iname);
	};

	/**
	 * Converts the <code>EppCommandCheckXriIName</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandCheckXriIName</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandCheckXriIName</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Check entity for EPP XriIName objects.
	 *
	 * @param root root node for an <code>EppCommandCheckXriIName</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandCheckXriIName</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandCheckXriIName * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDCHECKXRIINAME_HPP */  /* } */
