#if ! defined(EPPRESPONSEDATACHECKXRIINUMBER_HPP)    /* { */
#define       EPPRESPONSEDATACHECKXRIINUMBER_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppResponseDataCheck.hpp"

/**
 * This <code>EppResponseDataCheckXriINumber</code> class implements EPP
 * Response Data entity for EPP Command Check of EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppResponseDataCheckXriINumber : public EppResponseDataCheck
{
public:
	/**
	 * Checks an <code>EppResponseDataCheckXriINumber</code> object
	 */
	EppResponseDataCheckXriINumber() {};

	/**
	 * Destructor
	 */
	~EppResponseDataCheckXriINumber() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCheckXriINumber;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCheckXriINumber</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for checking EPP XRI I-Number objects.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCheckXriINumber</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCheckXriINumber</code> object, or null
	 *         if the node is invalid
	 */
	static EppResponseDataCheckXriINumber * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataCheckXriINumber</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCheckXriINumber</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATACHECKXRIINUMBER_HPP */  /* } */
