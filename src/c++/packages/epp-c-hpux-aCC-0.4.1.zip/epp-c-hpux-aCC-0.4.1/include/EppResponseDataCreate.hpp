#if ! defined(EPPRESPONSEDATACREATE_HPP)    /* { */
#define       EPPRESPONSEDATACREATE_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include <time.h>
#include "EppResponseData.hpp"

/**
 * This <code>EppResponseDataCreate</code> class implements EPP Response
 * Data entity for EPP Command Create.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppResponseDataCreate : public EppResponseData
{
protected:
	/**
	 * The ROID associated with the response data after creating
	 * an object successfully
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	DOMString roid;
        /**
	 * The creation date of the object created.
	 *
	 * <P><B>Note:</B> The default value is the date when the <I>EppResponseDataCreate</I> object is created
	 *
	 * @since EPP-1.0
	 */
	time_t crDate;

public:
	/**
	 * Creates <code>EppResponseDataCreate</code> object
	 */
	EppResponseDataCreate()
	{
		this->roid = null;
		this->crDate = 0;
	};

	/**
	 * Destructor
	 */
	virtual ~EppResponseDataCreate() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCreate;
	};

	/**
	 * Gets ROID associated with the creation of an <code>EppObject</code>
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	DOMString getRoid()
	{
		return this->roid;
	};

	/**
	 * Sets ROID associated with the creation of an <code>EppObject</code>
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	void setRoid( DOMString roid )
	{
		this->roid = roid;
	};

	/**
	 * Gets creation date of the object created
	 *
	 * @since EPP-1.0
	 */
	time_t getDateCreated()
	{
		return this->crDate;
	};

	/**
	 * Sets creation date of the object created
	 */
	void setDateCreated( time_t crDate )
	{
		this->crDate = crDate;
	};
};

#endif     /* EPPRESPONSEDATACREATE_HPP */  /* } */
