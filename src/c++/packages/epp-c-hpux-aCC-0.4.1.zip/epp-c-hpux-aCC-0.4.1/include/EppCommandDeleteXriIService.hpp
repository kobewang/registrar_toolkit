#if ! defined(EPPCOMMANDDELETEXRIISERVICE_HPP)    /* { */
#define       EPPCOMMANDDELETEXRIISERVICE_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandDelete.hpp"

/**
 * This <code>EppCommandDelete</code> class implements EPP Command Delete
 * entity for EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppCommandDeleteXriIService : public EppCommandDelete
{
private:
	DOMString id;

public:
	/**
	 * Creates an <code>EppCommandDeleteXriIService</code> object for
	 * deleting an XRI i-service based on its identifier
	 */
	EppCommandDeleteXriIService( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Creates an <code>EppCommandDeleteXriIService</code> object for
	 * deleting an XRI i-service based on its identifier, given a client
	 * transaction id associated with the operation
	 */
	EppCommandDeleteXriIService( DOMString id, DOMString xid )
	{
		this->id = id;
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandDeleteXriIService() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandDeleteXriIService;
	};

	/**
	 * Gets the identifier of the XRI i-service object to be deleted
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the identifier of the XRI i-service object to be deleted
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Converts the <code>EppCommandDeleteXriIService</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandDeleteXriIService</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandDeleteXriIService</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Delete entity for EPP XriIService object.
	 *
	 * @param root root node for an <code>EppCommandDeleteXriIService</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandDeleteXriIService</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandDeleteXriIService * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDDELETEXRIISERVICE_HPP */  /* } */
