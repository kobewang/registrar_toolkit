#if        ! defined(BIZPROTECT_HPP)    /* { */
#define              BIZPROTECT_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#if ! defined(EPP_EXPORT)    /* { */
#define       EPP_EXPORT
#endif     /* EPP_EXPORT) */ /* } */

/**
 * This <code>BizProtect</code> class defines various services ids
 * in the BIZprotect product suite.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $
 */
class EPP_EXPORT BizProtect
{
public:
	/**
	 * Service ID for BIZ Account
	 */
	static const char * BIZ_ACCOUNT;

	/**
	 * Service ID for BIZ Lock
	 */
	static const char * BIZ_LOCK;
};

#endif  /* ! defined(BIZPROTECT_HPP) */ /* } */
