#if ! defined(EPPRESPONSEDATAPENDINGHOST_HPP)		/* { */
#define	      EPPRESPONSEDATAPENDINGHOST_HPP		   1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppResponseDataPending.hpp"

/**
 * This <code>EppResponseDataPendingHost</code> class implements EPP
 * Response Data entity for EPP Pending Actions of EPP Host objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppResponseDataPendingHost : public EppResponseDataPending
{
private:
	DOMString   name;

public:
	/**
	 * Creates an <code>EppResponseDataPendingHost</code> object
	 *
	 * @param name the name of the <code>EppHost</code> object associated with the pending action
	 */
	EppResponseDataPendingHost( DOMString name )
	{
		this->name = name;
		this->paResult = false;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataPendingHost</code> object
	 *
	 * @param name the name of the <code>EppHost</code> object associated with the pending action
	 * @param result the boolean flag indicating if the pending action is a success or a failure
	 */
	EppResponseDataPendingHost( DOMString name, bool result )
	{
		this->name = name;
		this->paResult = result;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = 0;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataPendingHost() {};

	/**
	 * Gets the name of the host object associated with the pending action
	*/
	DOMString getName()
	{
		return this->name;
	};

	/**
	 * Sets the name of the host object associated with the pending action
	 */
	void setName( DOMString name )
	{
		this->name = name;
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataPendingHost;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataPendingHost</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP Host object
	 *
	 * @param root root node for an <code>EppResponseDataPendingHost</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataPendingHost</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataPendingHost * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataPendingHost</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataPendingHost</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif	/*    EPPRESPONSEDATAPENDINGHOST_HPP */	/* } */
