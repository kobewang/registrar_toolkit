#if ! defined(EPPCOMMANDDELETEXRIAUTHORITY_HPP)    /* { */
#define       EPPCOMMANDDELETEXRIAUTHORITY_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandDelete.hpp"
#include "EppAuthInfo.hpp"

/**
 * This <code>EppCommandDelete</code> class implements EPP Command Delete
 * entity for EPP XRI Authority objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppCommandDeleteXriAuthority : public EppCommandDelete
{
private:
	DOMString	  authId;
	EppAuthInfo	* authInfo;

public:
	/**
	 * Creates an <code>EppCommandDeleteXriAuthority</code> object for
	 * deleting an XRI authority based on its identifier
	 */
	EppCommandDeleteXriAuthority( DOMString authId )
	{
		this->authId = authId;
		this->authInfo = null;
	};

	/**
	 * Creates an <code>EppCommandDeleteXriAuthority</code> object for
	 * deleting an XRI authority based on its identifier, given a client
	 * transaction id associated with the operation
	 */
	EppCommandDeleteXriAuthority( DOMString authId, DOMString xid )
	{
		this->authId = authId;
		this->authInfo = null;
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandDeleteXriAuthority()
	{
		if( this->authInfo != null )
		{
			delete this->authInfo;
			this->authInfo = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandDeleteXriAuthority;
	};

	/**
	 * Gets the identifier of the XRI authority object to be deleted
	 */
	DOMString getAuthorityId()
	{
		return this->authId;
	};

	/**
	 * Sets the identifier of the XRI authority object to be deleted
	 */
	void setAuthorityId( DOMString authId )
	{
		this->authId = authId;
	};

	/**
	 * Gets the authorization info for the delete operation
	 */
	EppAuthInfo * getAuthInfo()
	{
		return this->authInfo;
	};

	/**
	 * Sets the authorization info for the delete operation
	 */
	void setAuthInfo( EppAuthInfo authInfo )
	{
		if( this->authInfo == null )
		{
			this->authInfo = new EppAuthInfo();
		}
		*(this->authInfo) = authInfo;
	};

	/**
	 * Converts the <code>EppCommandDeleteXriAuthority</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandDeleteXriAuthority</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandDeleteXriAuthority</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Delete entity for EPP XriAuthority object.
	 *
	 * @param root root node for an <code>EppCommandDeleteXriAuthority</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandDeleteXriAuthority</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandDeleteXriAuthority * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDDELETEXRIAUTHORITY_HPP */  /* } */
