#if ! defined(EPPCOMMANDTRANSFERXRIAUTHORITY_HPP)    /* { */
#define       EPPCOMMANDTRANSFERXRIAUTHORITY_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandTransfer.hpp"

/**
 * This <code>EppCommandTransferXriAuthority</code> class implements EPP Command
 * Transfer entity for EPP XRI Authority objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppCommandTransferXriAuthority : public EppCommandTransfer
{
private:
	DOMString     authId;
	DOMString     trToken;
	DOMString     targetAuthId;
	EppAuthInfo * targetAuthInfo;

public:
	/**
	 * Creates an <code>EppCommandTransferXriAuthority</code> object
	 */
	EppCommandTransferXriAuthority()
	{
		this->authId = null;
		this->trToken = null;
		this->targetAuthId = null;
		this->targetAuthInfo = null;
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandTransferXriAuthority</code> object for
	 * transfering an XRI authority object based on its identifier
	 */
	EppCommandTransferXriAuthority( DOMString authId )
	{
		this->authId = authId;
		this->trToken = null;
		this->targetAuthId = null;
		this->targetAuthInfo = null;
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandTransferXriAuthority</code> object for
	 * transfering an XRI authority object based on its identifier
	 * given a client transaction id associated with operation
	 */
	EppCommandTransferXriAuthority( DOMString authId, DOMString xid )
	{
		this->authId = authId;
		this->trToken = null;
		this->targetAuthId = null;
		this->targetAuthInfo = null;
		this->clTRID = xid;
	};

	/**
	 * Creates an <code>EppCommandTransferXriAuthority</code> object for
	 * transfering an XRI authority object based on its identifier,
	 * a client transaction id associated with operation
	 * and with a transfer token
	 */
	EppCommandTransferXriAuthority( DOMString authId, DOMString trToken, DOMString xid )
	{
		this->authId = authId;
		this->trToken = trToken;
		this->targetAuthId = null;
		this->targetAuthInfo = null;
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandTransferXriAuthority()
	{
		if( this->targetAuthInfo != null )
		{
			delete this->targetAuthInfo;
			this->targetAuthInfo = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandTransferXriAuthority;
	};

	/**
	 * Gets the identifier of the XRI authority object to be transferred
	 */
	DOMString getAuthorityId()
	{
		return this->authId;
	};

	/**
	 * Sets the identifier of the XRI authority object to be transferred
	 */
	void setAuthorityId( DOMString authId )
	{
		this->authId = authId;
	};

	/**
	 * Gets the transfer token for the transfer operation
	 */
	DOMString getTransferToken()
	{
		return this->trToken;
	};

	/**
	 * Sets the transfer token for the transfer operation
	 */
	void setTransferToken( DOMString trToken )
	{
		this->trToken = trToken;
	};

	/**
	 * Gets the target XRI authority identifier
	 */
	DOMString getTargetAuthorityId()
	{
		return this->targetAuthId;
	};

	/**
	 * Sets the target XRI authority identifier
	 */
	void setTargetAuthorityId( DOMString authId )
	{
		this->targetAuthId = authId;
	};

	/**
	 * Sets the target XRI authority authInfo
	 */
	EppAuthInfo * getTargetAuthInfo()
	{
		return this->targetAuthInfo;
	};

	/**
	 * Sets the target XRI authority authInfo
	 */
	void setTargetAuthInfo( EppAuthInfo authInfo )
	{
		if( this->targetAuthInfo == null )
		{
			this->targetAuthInfo = new EppAuthInfo();
		}
		*(this->targetAuthInfo) = authInfo;
	};

	/**
	 * Sets the identifier and authInfo of the target XRI authority involved in 
	 * XRI authority transfer operation
	 */
	void setTarget( DOMString authId, EppAuthInfo authInfo )
	{
		this->setTargetAuthorityId(authId);
		this->setTargetAuthInfo(authInfo);
	};

	/**
	 * Converts the <code>EppCommandTransferXriAuthority</code> object into
	 * an XML element for an <code>EppPollable</code> object
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandTransferXriAuthority</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXMLPoll( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts the <code>EppCommandTransferXriAuthority</code> object into
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandTransferXriAuthority</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an
	 * <code>EppCommandTransferXriAuthority</code> object. The caller of this
	 * method must make sure that the root node is of an EPP Command
	 * Transfer entity for EPP XriAuthority object.
	 *
	 * @param root root node for an <code>EppCommandTransferXriAuthority</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandTransferXriAuthority</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandTransferXriAuthority * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDTRANSFERXRIAUTHORITY_HPP */  /* } */
