#if ! defined(EPPXRISERVICEENDPOINTMEDIATYPE_HPP)    /* { */
#define       EPPXRISERVICEENDPOINTMEDIATYPE_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppXriServiceEndpointMediaType.hpp,v 1.1 2006/03/12 12:37:03 wtan Exp $
 */
#include "EppXriServiceEndpointRule.hpp"


/**
 * This <code>EppXriServiceEndpointMediaType</code> class encapsulates
 * the EPP XRI Authority ServiceEndpoint MediaType as defined in the
 * XRI Authority XML Schema type <code>sepMediaTypeType</code>.
 *
 * @author William Tan william.tan@neustar.biz
 * @version $Revision: 1.1 $ $Date: 2006/03/12 12:37:03 $
 */
class EPP_EXPORT EppXriServiceEndpointMediaType : public EppXriServiceEndpointRule
{


public:

	/**
	 * Creates an <code>EppXriServiceEndpointMediaType</code> object
	 */
	EppXriServiceEndpointMediaType()
		: EppXriServiceEndpointRule(null, null, DEFAULT_SELECT_ATTR)
	{
	}

	/**
	 * Creates an <code>EppXriServiceEndpointMediaType</code> object
	 */
	EppXriServiceEndpointMediaType( DOMString value, DOMString match, bool select )
		: EppXriServiceEndpointRule(value, match, select)
	{
	}

	/**
	 * Destructor
	 */
	~EppXriServiceEndpointMediaType()
	{
	}

	/**
	 * Gets the media type
	 */
	DOMString getMediaType()
	{
		return getValue();
	}

	/**
	 * Sets the media type
	 */
	void setValue( DOMString mediaType )
	{
		setValue(mediaType);
	};

	/**
	 * Converts an XML element into an <code>EppXriServiceEndpointMediaType</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP XRI sepMediaTypeType
	 *
	 * @param root root node for an <code>EppXriServiceEndpointMediaType</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriServiceEndpointMediaType</code> object, or null if the node is
	 *         invalid
	 */
	static EppXriServiceEndpointMediaType * fromXML( const DOM_Node& root )
	{
		EppXriServiceEndpointMediaType *mtype = new EppXriServiceEndpointMediaType();
		mtype->setFromXML(root);
		return mtype;
	}

	DOMString toString()
	{
		return EppEntity::toString(DOMString("mediaType"));
	};
};

#endif     /* EPPXRISERVICEENDPOINTMEDIATYPE_HPP */  /* } */
