#if ! defined(EPPCOMMANDINFO_HPP)    /* { */
#define       EPPCOMMANDINFO_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandInfo.hpp,v 1.2 2006/03/01 01:35:37 wtan Exp $
 */
#include "EppCommand.hpp"

/**
 * This <code>EppCommandInfo</code> class implements EPP Command Info
 * entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:37 $
 */
class EPP_EXPORT EppCommandInfo : public EppCommand
{
public:
	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandInfo;
	};

	/**
	 * Converts an XML element into an <code>EppCommandInfo</code> object.
	 * The caller of this method must make sure that the root node is of an
	 * EPP Command Info entity.
	 *
	 * @param root root node for an <code>EppCommandInfo</code> object
	 *             in XML format
	 *
	 * @return an <code>EppCommandInfo</code> object, or null if the node
	 *         is invalid
	 */
	static EppCommandInfo * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("info"));
	};
};

#endif     /* EPPCOMMANDINFO_HPP */  /* } */
