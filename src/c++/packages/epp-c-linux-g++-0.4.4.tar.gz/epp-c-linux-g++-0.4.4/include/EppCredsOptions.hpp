#if ! defined(EPPCREDSOPTIONS_HPP)    /* { */
#define       EPPCREDSOPTIONS_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCredsOptions.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppEntity.hpp"

/**
 * This <code>EppCredsOptions</code> class implements EPP credsOptionsType
 * entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppCredsOptions : public EppEntity
{
private:
	DOMString version;
	DOMString lang;

public:
	/**
	 * Creates an <code>EppCredsOptions</code> object
	 */
	EppCredsOptions()
	{
		this->version = null;
		this->lang = null;
	};
 
	/**
	 * Creates an <code>EppCredsOptions</code> object, given the version
	 * string and language id
	 *
	 * @param version verion string
	 * @param language language id
	 */
	EppCredsOptions( DOMString version, DOMString language )
	{
		this->version = version;
		this->lang = language;
	};

	/**
	 * Destructor
	 */
	~EppCredsOptions() {};

	/**
	 * Gets version string
	 */
	DOMString getVersion()
	{
		return this->version;
	};

	/**
	 * Sets version string
	 */
	void setVersion( DOMString version )
	{
		this->version = version;
	};

	/**
	 * Gets language id
	 */
	DOMString getLanguage()
	{
		return this->lang;
	};

	/**
	 * Sets language id
	 */
	void setLanguage( DOMString language )
	{
		this->lang = language;
	};

	/**
	 * Converts the <code>EppCredsOptions</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the <code>EppCredsOptions</code>
	 *            object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCredsOptions</code> object.
	 * The caller of this method must make sure that the root node is of the
	 * EPP credsOptionsType.
	 *
	 * @param root root node for an <code>EppCredsOptions</code> object in
	 *             XML format
	 *
	 * @return an <code>EppCredsOptions</code> object, or null if the node
	 *         is invalid
	 */
	static EppCredsOptions * fromXML( const DOM_Node& root );

	/**
	 * Converts the <code>EppCredsOptions</code> object into plain XML text
	 * string by using the default root tag name
	 *
	 * @return a text string representing the <code>EppCredsOptions</code>
	 *         object in XML format
	 */
	DOMString toString()
	{
		return EppEntity::toString(DOMString("options"));
	};
};

#endif     /* EPPCREDSOPTIONS_HPP */  /* } */
