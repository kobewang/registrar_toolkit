#if ! defined(EPPCOMMANDCHECKXRIINUMBER_HPP)    /* { */
#define       EPPCOMMANDCHECKXRIINUMBER_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandCheckXriNumber.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppCommandCheck.hpp"

#define	MAX_NUM_OF_XRIINUMBERS	16

/**
 * This <code>EppCommandCheckXriNumber</code> class implements EPP Command Check
 * entity for EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppCommandCheckXriNumber : public EppCommandCheck
{
private:
	ValueVectorOf<DOMString> * inumbers;

public:
	/**
	 * Creates an <code>EppCommandCheckXriNumber</code> object
	 */
	EppCommandCheckXriNumber()
	{
		this->inumbers = new ValueVectorOf<DOMString>(MAX_NUM_OF_XRIINUMBERS);
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandCheckXriNumber</code> object, given a
	 * client transaction id associated with the operation
	 */
	EppCommandCheckXriNumber( DOMString xid )
	{
		this->inumbers = new ValueVectorOf<DOMString>(MAX_NUM_OF_XRIINUMBERS);
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandCheckXriNumber()
	{
		if( this->inumbers != null )
		{
			delete this->inumbers;
			this->inumbers = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandCheckXriNumber;
	};

	/**
	 * Gets the list of the i-numbers of the XRI i-number objects to be checked
	 */
	ValueVectorOf<DOMString> * getINumber()
	{
		return this->inumbers;
	};

	/**
	 * Gets the list of the i-numbers of the XRI i-number objects to be checked.
	 *
	 * <P><B>Note:</B> This is an alias for <code>getINumber</code>
	 */
	ValueVectorOf<DOMString> * get()
	{
		return this->getINumber();
	};

	/**
	 * Adds the i-number of an XRI i-number object to the list of i-numbers of XRI i-number
	 * objects be checked
	 */
	void addINumber( DOMString inumber )
	{
		this->inumbers->addElement(inumber);
	};

	/**
	 * Adds the i-number of an XRI i-number object to the list of i-numbers of XRI i-number
	 * objects be checked.
	 *
	 * <P><B>Note:</B> This is an alias for <code>addINumber</code>
	 */
	void add( DOMString inumber )
	{
		this->addINumber(inumber);
	};

	/**
	 * Converts the <code>EppCommandCheckXriNumber</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandCheckXriNumber</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandCheckXriNumber</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Check entity for EPP XriNumber objects.
	 *
	 * @param root root node for an <code>EppCommandCheckXriNumber</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandCheckXriNumber</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandCheckXriNumber * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDCHECKXRIINUMBER_HPP */  /* } */
