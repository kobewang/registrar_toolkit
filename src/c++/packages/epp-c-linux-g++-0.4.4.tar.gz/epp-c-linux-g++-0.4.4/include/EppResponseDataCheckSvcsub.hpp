#if ! defined(EPPRESPONSEDATACHECKSVCSUB_HPP)    /* { */
#define       EPPRESPONSEDATACHECKSVCSUB_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataCheckSvcsub.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppResponseDataCheck.hpp"

/**
 * This <code>EppResponseDataCheckSvcsub</code> class implements EPP
 * Response Data entity for EPP Command Check of EPP Svcsub objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $
 */
class EPP_EXPORT EppResponseDataCheckSvcsub : public EppResponseDataCheck
{
private:
	DOMString service;

public:
	/**
	 * Creates an <code>EppResponseDataCheckSvcsub</code> object
	 */
	EppResponseDataCheckSvcsub()
	{
		this->service = null;
	};

	/**
	 * Gets the service name
	 */
	DOMString getService()
	{
		return this->service;
	};

	/**
	 * Sets the service name
	 */
	void setService( DOMString service )
	{
		this->service = service;
        };

	/**
	 * Destructor
	 */
	~EppResponseDataCheckSvcsub() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCheckSvcsub;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCheckSvcsub</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP Svcsub object.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCheckSvcsub</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCheckSvcsub</code> object, or null
	 *         if the node is invalid
	 */
	static EppResponseDataCheckSvcsub * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataCheckSvcsub</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCheckSvcsub</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATACHECKSVCSUB_HPP */  /* } */
