#if ! defined(EPPCOMMANDUPDATEXRIISERVICE_HPP)    /* { */
#define       EPPCOMMANDUPDATEXRIISERVICE_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandUpdateXriService.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppCommandUpdate.hpp"

/**
 * This <code>EppCommandUpdateXriService</code> class implements EPP Command Update
 * entity for EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppCommandUpdateXriService : public EppCommandUpdate
{
private:
	DOMString id;

public:
	/**
	 * Creates an <code>EppCommandUpdateXriService</code>
	 */
	EppCommandUpdateXriService()
	{
		this->id = null;
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandUpdateXriService</code> given the
	 * identifier of the XRI i-service object
	 */
	EppCommandUpdateXriService( DOMString id )
	{
		this->id = id;
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandUpdateXriService</code> given the
	 * identifier of the XRI i-service object and a client transaction id
	 */
	EppCommandUpdateXriService( DOMString id, DOMString xid )
	{
		this->id = id;
		this->clTRID = xid;
	};

	/**
	 * Destricutor
	 */
	~EppCommandUpdateXriService() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandUpdateXriService;
	};

	/**
	 * Gets the identifier of the XRI i-service object to be updated
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the identifier of the XRI i-service object to be updated
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Converts the <code>EppCommandUpdateXriService</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the 
	 *            <code>EppCommandUpdateXriService</code> object
	 *
	 * @return an <code>DOM_Element</code> object 
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandUpdateXriService</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Update entity for an EPP XRI I-Service object.
	 *
	 * @param root root node for an <code>EppCommandUpdateXriService</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandUpdateXriService</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandUpdateXriService * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDUPDATEXRIISERVICE_HPP */  /* } */
