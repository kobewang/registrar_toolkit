#if ! defined(EPPXRISERVICEENDPOINTTYPE_HPP)    /* { */
#define       EPPXRISERVICEENDPOINTTYPE_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppXriServiceEndpointType.hpp,v 1.1 2006/03/12 12:37:03 wtan Exp $
 */
#include "EppXriServiceEndpointRule.hpp"


/**
 * This <code>EppXriServiceEndpointType</code> class encapsulates
 * the EPP XRI Authority ServiceEndpoint Type as defined in the
 * XRI Authority XML Schema type <code>sepTypeType</code>.
 *
 * @author William Tan william.tan@neustar.biz
 * @version $Revision: 1.1 $ $Date: 2006/03/12 12:37:03 $
 */
class EPP_EXPORT EppXriServiceEndpointType : public EppXriServiceEndpointRule
{


public:

	/**
	 * Creates an <code>EppXriServiceEndpointType</code> object
	 */
	EppXriServiceEndpointType()
		: EppXriServiceEndpointRule(null, null, DEFAULT_SELECT_ATTR)
	{
	}

	/**
	 * Creates an <code>EppXriServiceEndpointType</code> object
	 */
	EppXriServiceEndpointType( DOMString value, DOMString match, bool select )
		: EppXriServiceEndpointRule(value, match, select)
	{
	}

	/**
	 * Destructor
	 */
	~EppXriServiceEndpointType()
	{
	}

	/**
	 * Gets the type
	 */
	DOMString getType()
	{
		return getValue();
	}

	/**
	 * Sets the type
	 */
	void setValue( DOMString type )
	{
		setValue(type);
	};

	/**
	 * Converts an XML element into an <code>EppXriServiceEndpointType</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP XRI sepTypeType
	 *
	 * @param root root node for an <code>EppXriServiceEndpointType</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriServiceEndpointType</code> object, or null if the node is
	 *         invalid
	 */
	static EppXriServiceEndpointType * fromXML( const DOM_Node& root )
	{
		EppXriServiceEndpointType *type = new EppXriServiceEndpointType();
		type->setFromXML(root);
		return type;
	}

	DOMString toString()
	{
		return EppEntity::toString(DOMString("type"));
	};
};

#endif     /* EPPXRISERVICEENDPOINTTYPE_HPP */  /* } */
