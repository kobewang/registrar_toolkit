#if ! defined(EPPXRISERVICEENDPOINTPATH_HPP)    /* { */
#define       EPPXRISERVICEENDPOINTPATH_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppXriServiceEndpointPath.hpp,v 1.1 2006/03/12 12:37:03 wtan Exp $
 */
#include "EppXriServiceEndpointRule.hpp"


/**
 * This <code>EppXriServiceEndpointPath</code> class encapsulates
 * the EPP XRI Authority ServiceEndpoint Path as defined in the
 * XRI Authority XML Schema type <code>sepPathType</code>.
 *
 * @author William Tan william.tan@neustar.biz
 * @version $Revision: 1.1 $ $Date: 2006/03/12 12:37:03 $
 */
class EPP_EXPORT EppXriServiceEndpointPath : public EppXriServiceEndpointRule
{


public:

	/**
	 * Creates an <code>EppXriServiceEndpointPath</code> object
	 */
	EppXriServiceEndpointPath()
		: EppXriServiceEndpointRule(null, null, DEFAULT_SELECT_ATTR)
	{
	}

	/**
	 * Creates an <code>EppXriServiceEndpointPath</code> object
	 */
	EppXriServiceEndpointPath( DOMString value, DOMString match, bool select )
		: EppXriServiceEndpointRule(value, match, select)
	{
	}

	/**
	 * Destructor
	 */
	~EppXriServiceEndpointPath()
	{
	}

	/**
	 * Gets the path
	 */
	DOMString getPath()
	{
		return getValue();
	}

	/**
	 * Sets the path
	 */
	void setValue( DOMString path )
	{
		setValue(path);
	};

	/**
	 * Converts an XML element into an <code>EppXriServiceEndpointPath</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP XRI sepPathType.
	 *
	 * @param root root node for an <code>EppXriServiceEndpointPath</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriServiceEndpointPath</code> object, or null if the node is
	 *         invalid
	 */
	static EppXriServiceEndpointPath * fromXML( const DOM_Node& root )
	{
		EppXriServiceEndpointPath *path = new EppXriServiceEndpointPath();
		path->setFromXML(root);
		return path;
	}

	DOMString toString()
	{
		return EppEntity::toString(DOMString("path"));
	};
};

#endif     /* EPPXRISERVICEENDPOINTPATH_HPP */  /* } */
