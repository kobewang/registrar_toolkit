#if ! defined(EPPRESPONSEDATAPENDINGXRIAUTHORITY_HPP)	/* { */
#define	      EPPRESPONSEDATAPENDINGXRIAUTHORITY_HPP		   1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataPendingXriAuthority.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppResponseDataPending.hpp"

/**
 * This <code>EppResponseDataPendingXriAuthority</code> class implements EPP
 * Response Data entity for EPP Pending Actions of EPP XRI Authority objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataPendingXriAuthority : public EppResponseDataPending
{
private:
	DOMString   authId;

public:
	/**
	 * Creates an <code>EppResponseDataPendingXriAuthority</code> object
	 *
	 * @param authId the identifier of the <code>EppXriAuthority</code> object associated with the pending action
	 */
	EppResponseDataPendingXriAuthority( DOMString authId )
	{
		this->authId = authId;
		this->paResult = false;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataPendingXriAuthority</code> object
	 *
	 * @param authId the identifier of the <code>EppXriAuthority</code> object associated with the pending action
	 * @param result the boolean flag indicating if the pending action is a success or a failure
	 */
	EppResponseDataPendingXriAuthority( DOMString authId, bool result )
	{
		this->authId = authId;
		this->paResult = result;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = null;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataPendingXriAuthority() {};

	/**
	 * Gets the identifier of the XRI authority object associated with the pending action
	*/
	DOMString getAuthorityId()
	{
		return this->authId;
	};

	/**
	 * Sets the identifier of the XRI authority object associated with the pending action
	 */
	void setAuthorityId( DOMString authId )
	{
		this->authId = authId;
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataPendingXriAuthority;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataPendingXriAuthority</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XRI Authority object
	 *
	 * @param root root node for an <code>EppResponseDataPendingXriAuthority</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataPendingXriAuthority</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataPendingXriAuthority * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataPendingXriAuthority</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataPendingXriAuthority</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif	/*    EPPRESPONSEDATAPENDINGXRIAUTHORITY_HPP */	/* } */
