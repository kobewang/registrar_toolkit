#if ! defined(EPPEXTENSION_HPP)    /* { */
#define       EPPEXTENSION_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppExtension.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppEntity.hpp"

/**
 * This <code>EppExtension</code> class implements EPP Extension entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppExtension : public EppEntity
{
public:
	/**
	 * Creates an <code>EppExtension</code> object
	 */
	EppExtension()
	{
	};

	/**
	 * Destructor
	 */
	virtual ~EppExtension();

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppExtension;
	};

	/**
	 * Converts an XML element into an <code>EppExtension</code> object.
	 * The caller of this method must make sure that the root node is a
	 * child node of an EPP extension tag
	 *
	 * @param root root node for an <code>EppExtension</code> object in XML format
	 *
	 * @return an <code>EppExtension</code> object, or null if the node is invalid
	 */
	static EppExtension * fromXML( const DOM_Node &root );
};

#endif     /* EPPEXTENSION_HPP */  /* } */
