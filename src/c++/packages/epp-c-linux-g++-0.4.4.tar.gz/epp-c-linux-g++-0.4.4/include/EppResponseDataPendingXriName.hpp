#if ! defined(EPPRESPONSEDATAPENDINGXRIINAME_HPP)	/* { */
#define	      EPPRESPONSEDATAPENDINGXRIINAME_HPP		   1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataPendingXriName.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppResponseDataPending.hpp"

/**
 * This <code>EppResponseDataPendingXriName</code> class implements EPP
 * Response Data entity for EPP Pending Actions of EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataPendingXriName : public EppResponseDataPending
{
private:
	DOMString   iname;

public:
	/**
	 * Creates an <code>EppResponseDataPendingXriName</code> object
	 *
	 * @param iname the i-name of the <code>EppXriName</code> object associated with the pending action
	 */
	EppResponseDataPendingXriName( DOMString iname )
	{
		this->iname = iname;
		this->paResult = false;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataPendingXriName</code> object
	 *
	 * @param iname the i-name of the <code>EppXriName</code> object associated with the pending action
	 * @param result the boolean flag indicating if the pending action is a success or a failure
	 */
	EppResponseDataPendingXriName( DOMString iname, bool result )
	{
		this->iname = iname;
		this->paResult = result;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = null;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataPendingXriName() {};

	/**
	 * Gets the i-name of the XRI i-name object associated with the pending action
	*/
	DOMString getIName()
	{
		return this->iname;
	};

	/**
	 * Sets the i-name of the XRI i-name object associated with the pending action
	 */
	void setIName( DOMString iname )
	{
		this->iname = iname;
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataPendingXriName;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataPendingXriName</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XRI I-Name object
	 *
	 * @param root root node for an <code>EppResponseDataPendingXriName</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataPendingXriName</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataPendingXriName * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataPendingXriName</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataPendingXriName</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif	/*    EPPRESPONSEDATAPENDINGXRIINAME_HPP */	/* } */
