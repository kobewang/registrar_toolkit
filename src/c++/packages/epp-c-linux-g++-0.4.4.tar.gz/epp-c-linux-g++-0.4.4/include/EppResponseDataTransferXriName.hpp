#if ! defined(EPPRESPONSEDATATRANSFERXRIINAME_HPP)    /* { */
#define       EPPRESPONSEDATATRANSFERXRIINAME_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataTransferXriName.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppResponseDataTransfer.hpp"

/**
 * This <code>EppResponseDataTransferXriName</code> class implements EPP
 * Response Data entity for EPP Command Transfer of EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataTransferXriName : public EppResponseDataTransfer
{
private:
	DOMString iname;
	DOMString sourceAuthId;
	DOMString targetAuthId;
	DOMString trToken;

public:
	/**
	 * Creates an <code>EppResponseDataTransferXriName</code> object
	 */
	EppResponseDataTransferXriName()
	{
		this->iname = null;
		this->sourceAuthId = null;
		this->targetAuthId = null;
		this->trToken = null;
	};

	/**
	 * Creates an <code>EppResponseDataTransferXriName</code> object
	 * given the i-name of an XRI I-Name object to be transferred
	 */
	EppResponseDataTransferXriName( DOMString iname )
	{
		this->iname = iname;
		this->sourceAuthId = null;
		this->targetAuthId = null;
		this->trToken = null;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataTransferXriName() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataTransferXriName;
	};

	/**
	 * Gets the i-name of the XRI I-Name object
	 */
	DOMString getIName()
	{
		return this->iname;
	};

	/**
	 * Sets the i-name of the XRI I-Name Object
	 */
	void setIName( DOMString iname )
	{
		this->iname = iname;
	};

	/**
	 * Gets the identifier of the XRI I-Name object involved
	 * in the transfer that acts as the source, if any
	 */
	DOMString getSourceAuthorityId()
	{
		return this->sourceAuthId;
	};

	/**
	 * Sets the identifier of the XRI I-Name object involved
	 * in the transfer that acts as the source, if any
	 */
	void setSourceAuthorityId( DOMString sourceAuthId )
	{
		this->sourceAuthId = sourceAuthId;
	};

	/**
	 * Gets the identifier of the XRI I-Name object involved
	 * in the transfer that acts as the target, if any
	 */
	DOMString getTargetAuthorityId()
	{
		return this->targetAuthId;
	};

	/**
	 * Sets the identifier of the XRI I-Name object involved
	 * in the transfer that acts as the target, if any
	 */
	void setTargetAuthorityId( DOMString targetAuthId )
	{
		this->targetAuthId = targetAuthId;
	};

	/**
	 * Gets the transfer token for the transfer operation
	 */
	DOMString getTransferToken()
	{
		return this->trToken;
	};

	/**
	 * Sets the transfer token for the transfer operation
	 */
	void setTransferToken( DOMString trToken )
	{
		this->trToken = trToken;
	};

	/**
	 * Gets the new expiration date of the i-name after the transfer, or
	 * null if the transfer request does not change the expiration date
	 * of the i-name.
	 */
	time_t getDateExpired()
	{
		return this->exDate;
	};

	/**
	 * Sets the new expiration date of the i-name after the transfer.
	 * The value of the new expiration date is optional.
	 */
	void setDateExpired( time_t date )
	{
		this->exDate = date;
	};

	/**
	 * Converts the <code>EppResponseDataTransferXriName</code> object into
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataTransferXriName</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataTransferXriName</code> object. The caller
	 * of this method must make sure that the root node is of an EPP
	 * Response Transfer entity for EPP XRI I-Name object.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataTransferXriName</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataTransferXriName</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataTransferXriName * fromXML( const DOM_Node& root );
};

#endif     /* EPPRESPONSEDATATRANSFERXRIINAME_HPP */  /* } */
