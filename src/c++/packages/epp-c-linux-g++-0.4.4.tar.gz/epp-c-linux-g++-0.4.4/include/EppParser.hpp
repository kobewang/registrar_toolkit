#if ! defined(EPPPARSER_HPP)    /* { */
#define       EPPPARSER_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppParser.hpp,v 1.2 2006/03/01 01:35:37 wtan Exp $
 */
#include <dom/DOM.hpp>
#include <sax/ErrorHandler.hpp>
#include <sax/SAXException.hpp>
#include <sax/SAXParseException.hpp>
#include <parsers/DOMParser.hpp>
#include <dom/DOM_DOMException.hpp>
#include "EppResult.hpp"

#define	MAX_NUM_OF_ERRORS	30

/**
 * This <code>EppParser</code> class is designed to parse and validate
 * EPP XML messages against EPP XML Schema. Apache Xerces 1.5.0 for C++
 * is required.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:37 $
 */
class EPP_EXPORT EppParser : public ErrorHandler
{
private:
	int          countWarnings;
	int          countErrors;
	int          countFatals;
	ValueVectorOf<DOMString>* errorMessages;
	DOMParser    parser;
	DOM_Document document;

	void init();
	void addMessage( const DOMString& msg );
	DOMString getLoc( const SAXParseException& e );

public:
	/**
	 * Creates an <code>EppParser</code> object
	 */
	EppParser();

	/**
	 * Creates an <code>EppParser</code> object, given an EPP XML payload
	 * string
	 *
	 * @param string a string in DOMString format
	 */
	EppParser( const DOMString& string );

	/**
	 * Creates an <code>EppParser</code> object, given an EPP XML payload
	 * string
	 *
	 * @param string a null terminated byte stream
	 */
	EppParser( const char * string );

	/**
	 * Creates an <code>EppParser</code> object, given an EPP XML payload
	 * string and its length
	 *
	 * @param string a minated byte stream
	 * @param length the length of the byte stream
	 */
	EppParser( const char * string, int length );
	
	/**
	 * Destructor for an <code>EppParser</code> object
	 */
	~EppParser();

	/**
	 * Gets the DOM Parser used for parsing EPP messages
	 */
	DOMParser& getParser();

	/**
	 * Parses an EPP message string
	 *
	 * @param string a string in DOMString format
	 */
	void parse( const DOMString& string );

	/**
	 * Parses an EPP message string
	 *
	 * @param string a null terminated byte stream
	 */
	void parse( const char * string );

	/**
	 * Parses an EPP message string, given its length
	 *
	 * @param string a minated byte stream
	 * @param length the length of the byte stream
	 */
	void parse( const char * string, int length );

	/**
	 * Parses an EPP message stored in a file
	 *
	 * @param file file name containing an EPP message
	 */
	void parseFile( const char * file );

	/**
	 * Gets <code>DOM_Document</code> object after parsing
	 */
	DOM_Document& getDocument();

	/**
	 * Checks if there is any errors after parsing
	 */
	bool hasError();

	/**
	 * Gets parsing result as an <code>EppResult</code> object
	 */
	EppResult * getResult();

	/**
	 * Gets the root "epp" node of parsing result as an <code>Node</code>
	 * object. If there is any error, a null DOM_Node is returned.
	 */
	DOM_Node getRootNode();

	/**
	 * <code>ErrorHandler</code> method - Warnings
	 */
	void warning( const SAXParseException& e );

	/**
	 * <code>ErrorHandler</code> method - Errors
	 */
	void error( const SAXParseException& e );

	/**
	 * <code>ErrorHandler</code> method - Fatal errors
	 */
	void fatalError( const SAXParseException& e );

	/**
	 * <code>ErrorHandler</code> method - Reset errors
	 */
	void resetErrors( void );

	DOMString toString();
};

#endif     /* EPPPARSER_HPP */  /* } */
