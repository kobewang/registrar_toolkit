#if ! defined(EPPCOMMANDDELETECONTACT_HPP)    /* { */
#define       EPPCOMMANDDELETECONTACT_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandDeleteContact.hpp,v 1.2 2006/03/01 01:35:37 wtan Exp $
 */
#include "EppCommandDelete.hpp"

/**
 * This <code>EppCommandDelete</code> class implements EPP Command Delete
 * entity for EPP Contact objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:37 $
 */
class EPP_EXPORT EppCommandDeleteContact : public EppCommandDelete
{
private:
	DOMString id;

public:
	/**
	 * Creates an <code>EppCommandDeleteContact</code> object for
	 */
	EppCommandDeleteContact()
	{
		this->id = null;
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandDeleteContact</code> object for
	 * deleting a contact object based on its id
	 */
	EppCommandDeleteContact( DOMString id )
	{
		this->id = id;
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandDeleteContact</code> object for
	 * deleting a contact object based on its id, given a client
	 * transaction id associated with the operation
	 */
	EppCommandDeleteContact( DOMString id, DOMString xid )
	{
		this->id = id;
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandDeleteContact() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandDeleteContact;
	};

	/**
	 * Gets the id of the contact object to be deleted
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the id of the contact object to be deleted
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Converts the <code>EppCommandDeleteContact</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandDeleteContact</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandDeleteContact</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Delete entity for EPP contact object.
	 *
	 * @param root root node for an <code>EppCommandDeleteContact</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandDeleteContact</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandDeleteContact * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDDELETECONTACT_HPP */  /* } */
