#if ! defined(EPPCOMMANDRENEWXRIISERVICE_HPP)    /* { */
#define       EPPCOMMANDRENEWXRIISERVICE_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandRenewXriService.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppCommandRenew.hpp"

/**
 * This <code>EppCommandRenewXriService</code> class implements EPP Command Renew
 * entity for EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppCommandRenewXriService : public EppCommandRenew
{
private:
	 DOMString id;

public:
	/**
	 * Creates an <code>EppCommandRenewXriService</code> object
	 */
	EppCommandRenewXriService()
	{
		this->id = null;
	};

	/**
	 * Creates an <code>EppCommandRenewXriService</code> object with a
	 * default expiration period, specified by the registry
	 */
	EppCommandRenewXriService( DOMString id, time_t curExpDate )
	{
		this->id = id;
		this->curExpDate = curExpDate;
	};

	/**
	 * Creates an <code>EppCommandRenewXriService</code> object with a
	 * client transaction id associated with the operation. The current
	 * date of expiration would be the current date.
	 */
	EppCommandRenewXriService( DOMString id, DOMString xid )
	{
		this->id = id;
		this->clTRID = xid;
	};

	/**
	 * Creates an <code>EppCommandRenewXriService</code> object with a
	 * default expiration period, specified by the registry, and a
	 * client transaction id associated with the operation
	 */
	EppCommandRenewXriService( DOMString id, time_t curExpDate, DOMString xid )
	{
		this->id = id;
		this->curExpDate = curExpDate;
		this->clTRID = xid;
	};

	/**
	 * Creates an <code>EppCommandRenewXriService</code> object with a
	 * specified expiration period, and a client transaction id associated
	 * with the operation
	 */
	EppCommandRenewXriService( DOMString id, time_t curExpDate, EppPeriod period, DOMString xid )
	{
		this->id = id;
		this->curExpDate = curExpDate;
		this->clTRID = xid;
		this->setPeriod(period);
	};

	/**
	 * Destructor
	 */
	~EppCommandRenewXriService() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandRenewXriService;
	};

	/**
	 * Gets the identifier of the XRI i-service object to be renewed
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the identifier of the XRI i-service object to be renewed
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Converts the <code>EppCommandRenewXriService</code> object into
	 *		an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *		<code>EppCommandRenewXriService</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandRenewXriService</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Renew entity for EPP XRI I-Service object
	 *
	 * @param root root node for an <code>EppCommandRenewXriService</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandRenewXriService</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandRenewXriService * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDRENEWXRIISERVICE_HPP */  /* } */
