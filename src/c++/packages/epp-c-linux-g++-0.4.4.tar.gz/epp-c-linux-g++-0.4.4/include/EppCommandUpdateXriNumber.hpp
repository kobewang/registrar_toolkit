#if ! defined(EPPCOMMANDUPDATEXRIINUMBER_HPP)    /* { */
#define       EPPCOMMANDUPDATEXRIINUMBER_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandUpdateXriNumber.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppCommandUpdate.hpp"
#include "EppXriNumber.hpp"

/**
 * This <code>EppCommandUpdateXriNumber</code> class implements EPP Command Update
 * entity for EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppCommandUpdateXriNumber : public EppCommandUpdate
{
private:
	DOMString inumber;
	int       newPriority;

	/**
	 * Adds elements included in the &lt;chg&gt tag of the update command
	 * for an XRI i-number object
	 *
	 * @param root the root <code>DOM_Node</code> of the &lt;chg&gt; tag
	 */
	void addNewStuff( DOM_Node root );

public:
	/**
	 * Creates an <code>EppCommandUpdateXriNumber</code>
	 */
	EppCommandUpdateXriNumber()
	{
		this->inumber = null;
		this->clTRID = null;
		this->newPriority = -1;
	};

	/**
	 * Creates an <code>EppCommandUpdateXriNumber</code> given the
	 * i-number of the XRI i-number object
	 */
	EppCommandUpdateXriNumber( DOMString inumber )
	{
		this->inumber = inumber;
		this->clTRID = null;
		this->newPriority = -1;
	};

	/**
	 * Creates an <code>EppCommandUpdateXriNumber</code> given the
	 * i-number of the XRI i-number object and a client transaction id
	 */
	EppCommandUpdateXriNumber( DOMString inumber, DOMString xid )
	{
		this->inumber = inumber;
		this->clTRID = xid;
		this->newPriority = -1;
	};

	/**
	 * Destricutor
	 */
	~EppCommandUpdateXriNumber() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandUpdateXriNumber;
	};

	/**
	 * Gets the i-number of the XRI i-number object to be updated
	 */
	DOMString getINumber()
	{
		return this->inumber;
	};

	/**
	 * Sets the i-number of the XRI i-number object to be updated
	 */
	void setINumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Gets the new priority value for this i-number
	 */
	unsigned short int getNewPriority()
	{
		if( this->newPriority != -1 )
		{
			return (unsigned short int) (this->newPriority & 0xFFFF);
		}
                return EppXriNumber::DEFAULT_PRIORITY;
	};

	/**
	 * Sets the priority value for this i-number
	 */
	void setNewPriority( unsigned short int newPriority )
	{
		this->newPriority = newPriority;
	};

	/**
	 * Checks if the a new priority value is set for this i-number
	 */
	bool isNewPrioritySet()
	{
		if( this->newPriority != -1 )
		{
			return true;
		}
		return false;
	};

	/**
	 * Converts the <code>EppCommandUpdateXriNumber</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the 
	 *            <code>EppCommandUpdateXriNumber</code> object
	 *
	 * @return an <code>DOM_Element</code> object 
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandUpdateXriNumber</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Update entity for an EPP XRI I-Number object.
	 *
	 * @param root root node for an <code>EppCommandUpdateXriNumber</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandUpdateXriNumber</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandUpdateXriNumber * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDUPDATEXRIINUMBER_HPP */  /* } */
