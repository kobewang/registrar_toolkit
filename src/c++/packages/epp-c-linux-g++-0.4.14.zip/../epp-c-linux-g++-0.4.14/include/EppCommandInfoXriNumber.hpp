#if ! defined(EPPCOMMANDINFOXRIINUMBER_HPP)    /* { */
#define       EPPCOMMANDINFOXRIINUMBER_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandInfoXriNumber.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppCommandInfo.hpp"

/**
 * This <code>EppCommandInfo</code> class implements EPP Command Info
 * entity for EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppCommandInfoXriNumber : public EppCommandInfo
{
private:
	DOMString inumber;

public:
	/**
	 * Creates an <code>EppCommandInfoXriNumber</code> object for
	 * querying an XRI i-number based on its i-number
	 */
	EppCommandInfoXriNumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Creates an <code>EppCommandInfoXriNumber</code> object for
	 * querying an XRI i-number based on its i-number, given a client
	 * transaction id associated with the operation
	 */
	EppCommandInfoXriNumber( DOMString inumber, DOMString xid )
	{
		this->inumber = inumber;
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandInfoXriNumber() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandInfoXriNumber;
	};

	/**
	 * Gets the i-number of the XRI i-number object to be queried
	 */
	DOMString getINumber()
	{
		return this->inumber;
	};

	/**
	 * Sets the i-number of the XRI i-number object to be queried
	 */
	void setINumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Converts the <code>EppCommandInfoXriNumber</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandInfoXriNumber</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandInfoXriNumber</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Info entity for EPP XriNumber object.
	 *
	 * @param root root node for an <code>EppCommandInfoXriNumber</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandInfoXriNumber</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandInfoXriNumber * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDINFOXRIINUMBER_HPP */  /* } */
