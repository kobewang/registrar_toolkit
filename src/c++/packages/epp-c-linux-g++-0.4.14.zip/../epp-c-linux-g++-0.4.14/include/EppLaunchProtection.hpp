#if ! defined(EPPLAUNCHPROTECTION_HPP)    /* { */
#define       EPPLAUNCHPROTECTION_HPP 1
#include <time.h>
#include "EppEntity.hpp"

class EPP_EXPORT EppLaunchProtection : public EppEntity {
	public:
		EppLaunchProtection();/*ctor*/ 
		EppLaunchProtection(const EppLaunchProtection&);/*copy ctor*/ 
		virtual ~EppLaunchProtection();/*d'tor*/ 
		EppLaunchProtection& operator=(const EppLaunchProtection&);/*assigment*/ 
		/* getter(s) | setter(s) */ 
		DOMString region(void);
		void region(const DOMString &);
		DOMString countryCode(void);
		void countryCode(const DOMString &);
		DOMString ruling(void);
		void ruling(const DOMString &);
		virtual DOM_Element toXML(DOM_Document &doc, const DOMString &tag);
		static EppLaunchProtection* fromXML( const DOM_Node& root );
		virtual DOMString toString();
	private:
		DOMString _cc;/*country code*/
		DOMString _ruling;/*attribute length 2*/
		DOMString _region;
};

#endif
