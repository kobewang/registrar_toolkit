#if ! defined(EPPXRISYNONYM_HPP)    /* { */
#define       EPPXRISYNONYM_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppXriSynonym.hpp,v 1.1 2008/03/21 00:39:00 wtan Exp $
 */
#include "EppEntity.hpp"

/**
 * This <code>EppXriSynonym</code> class defines a synonym element 
 * with a priority attribute. Elements such as LocalID and EquivID
 * are represented with this class.
 * It implements XRI synonymAddType and synonymInfType defined
 * in the XRI authority schema file.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2008/03/21 00:39:00 $
 */
class EPP_EXPORT EppXriSynonym : public EppEntity
{
private:
	int priority;
	DOMString          xs;

public:

	/**
	 * Creates an <code>EppXriSynonym</code> object
	 */
	EppXriSynonym()
	{
		this->priority = -1;
		this->xs       = null;
	};

	/**
	 * Creates an <code>EppXriSynonym</code> object with an synonym
	 */
	EppXriSynonym( DOMString xs )
	{
		this->priority = -1;
		this->xs       = xs;
	};

	/**
	 * Creates an <code>EppXriSynonym</code> object with a synonym
	 * and a priority value
	 */
	EppXriSynonym( DOMString xs, int priority )
	{
		this->priority = priority;
		this->xs       = xs;
	};

	/**
	 * Destructor
	 */
	~EppXriSynonym() {} ;

	/**
	 * Gets the priority value for this synonym
	 */
	int getPriority()
	{
		return this->priority;
	};

	/**
	 * Sets the priority value for this synonym
	 */
	void setPriority( int priority )
	{
		if (priority < -1)
			priority = -1;
		this->priority = priority;
	};

	/**
	 * Gets the XRI string of the synonym
	 */
	DOMString getSynonym()
	{
		return this->xs;
	}

	/**
	 * Sets the XRI string of the synonym
	 */
	void setSynonym( DOMString xs )
	{
		this->xs = xs;
	};

	/**
         * Converts the <code>EppXriSynonym</code> object into an XML element
         *
         * @param doc the XML <code>DOM_Document</code> object
         * @param tag the tag/element name for the <code>EppXriSynonym</code> object
         *
         * @return an <code>DOM_Element</code> object
         */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppXriSynonym</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP XRI xsAddType or xsInfType.
	 *
	 * @param root root node for an <code>EppXriSynonym</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriSynonym</code> object, or null if the node is
	 *         invalid
	 */
	static EppXriSynonym * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("synonym"));
	};
};

#endif     /* EPPXRISYNONYM_HPP */  /* } */
