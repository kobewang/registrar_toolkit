#if ! defined(EPPXRISERVICEENDPOINTMEDIATYPE_HPP)    /* { */
#define       EPPXRISERVICEENDPOINTMEDIATYPE_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppXriServiceEndpointMediaType.hpp,v 1.3 2006/05/15 08:08:33 wtan Exp $
 */
#include "EppXriServiceEndpointRule.hpp"


/**
 * This <code>EppXriServiceEndpointMediaType</code> class encapsulates
 * the EPP XRI Authority ServiceEndpoint MediaType as defined in the
 * XRI Authority XML Schema type <code>sepMediaTypeType</code>.
 *
 * @author William Tan william.tan@neustar.biz
 * @version $Revision: 1.3 $ $Date: 2006/05/15 08:08:33 $
 */
class EPP_EXPORT EppXriServiceEndpointMediaType : public EppXriServiceEndpointRule
{


public:

	/**
	 * Creates an <code>EppXriServiceEndpointMediaType</code> object
	 */
	EppXriServiceEndpointMediaType()
		: EppXriServiceEndpointRule()
	{
	}

	/**
	 * Creates an <code>EppXriServiceEndpointMediaType</code> object
	 */
	EppXriServiceEndpointMediaType( DOMString value, DOMString match, bool select )
		: EppXriServiceEndpointRule(value, match, select)
	{
	}

	/**
	 * Destructor
	 */
	~EppXriServiceEndpointMediaType()
	{
	}

	/**
	 * Gets the media type
	 */
	DOMString getMediaType()
	{
		return getValue();
	}

	/**
	 * Sets the media type
	 */
	void setMediaType( DOMString mediaType )
	{
		setValue(mediaType);
	};

	/**
	 * Converts an XML element into an <code>EppXriServiceEndpointMediaType</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP XRI sepMediaTypeType
	 *
	 * @param root root node for an <code>EppXriServiceEndpointMediaType</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriServiceEndpointMediaType</code> object, or null if the node is
	 *         invalid
	 */
	static EppXriServiceEndpointMediaType * fromXML( const DOM_Node& root )
	{
		EppXriServiceEndpointMediaType *mtype = new EppXriServiceEndpointMediaType();
		mtype->setFromXML(root);
		return mtype;
	}

	DOMString toString()
	{
		return EppEntity::toString(DOMString("mediaType"));
	};
};

#endif     /* EPPXRISERVICEENDPOINTMEDIATYPE_HPP */  /* } */
