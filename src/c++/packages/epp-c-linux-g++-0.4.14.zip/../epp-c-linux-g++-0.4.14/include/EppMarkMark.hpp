#if ! defined(EPPEPPMARKMARK_HPP)    /* { */
#define       EPPEPPMARKMARK_HPP 1
#include <time.h>
#include "EppEntity.hpp"
#include "EppMarkData.hpp"
#include <util/ValueVectorOf.hpp>

class EPP_EXPORT EppMarkMark:public EppEntity {
	public:
		EppMarkMark();
		EppMarkMark(const EppMarkMark&);
		virtual ~EppMarkMark();
		void cleanup();
		EppMarkMark& operator=(const EppMarkMark&);
		virtual DOMString toString();
		void addMark(EppMarkData*);
		ValueVectorOf<EppMarkData*> getMark(void);
		virtual DOM_Element toXML(DOM_Document &doc, const DOMString &tag);
		static EppMarkMark* fromXML( const DOM_Node& root );
	private:
		ValueVectorOf<EppMarkData*> _marks;
};

#endif
