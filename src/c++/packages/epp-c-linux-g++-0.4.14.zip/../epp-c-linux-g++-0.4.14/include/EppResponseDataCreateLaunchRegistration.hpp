#if ! defined(EPPRESPONSEDATACREATELAUNCHREGISTRATION_HPP)    /* { */
#define       EPPRESPONSEDATACREATELAUNCHREGISTRATION_HPP 1
#include "EppExtension.hpp"
#include "EppLaunchPhase.hpp"

class EPP_EXPORT EppResponseDataCreateLaunchRegistration : public EppExtension {
	public:
		EppResponseDataCreateLaunchRegistration();
		EppResponseDataCreateLaunchRegistration(const EppResponseDataCreateLaunchRegistration&);
		EppResponseDataCreateLaunchRegistration& operator=(const EppResponseDataCreateLaunchRegistration&);
		virtual ~EppResponseDataCreateLaunchRegistration();
		void phase(const EppLaunchPhase&);
		EppLaunchPhase phase();
		void applicationID(const DOMString&);
		DOMString applicationID();
		static EppResponseDataCreateLaunchRegistration* fromXML( const DOM_Node& root );
		virtual DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
		virtual DOMString toString();
		virtual int getEntityType();
	private:
		EppLaunchPhase _phase;
		DOMString _appId;
};

#endif
