#if ! defined(EPPCOMMANDINFOLAUNCHREGISTRATION_HPP)    /* { */
#define       EPPCOMMANDINFOLAUNCHREGISTRATION_HPP 1
#include "EppExtension.hpp"
#include "EppLaunchPhase.hpp"
#include <util/ValueVectorOf.hpp>

class EPP_EXPORT EppCommandInfoLaunchRegistration : public EppExtension {
	public:
		EppCommandInfoLaunchRegistration();
		EppCommandInfoLaunchRegistration(const EppCommandInfoLaunchRegistration&);
		EppCommandInfoLaunchRegistration& operator=(const EppCommandInfoLaunchRegistration&);
		virtual ~EppCommandInfoLaunchRegistration();
                void phase(const EppLaunchPhase &_p);
                EppLaunchPhase phase(void);
		void applicationID(const DOMString &_id);
		DOMString applicationID(void);
		void includeMark(bool _m);
		bool includeMark(void);
		static EppCommandInfoLaunchRegistration* fromXML( const DOM_Node& root );
		DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
		virtual DOMString toString();
		virtual int getEntityType();
	private:
		EppLaunchPhase _phase;
		DOMString _appId;
		bool _includeMark;
};

#endif
