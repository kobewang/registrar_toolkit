#if ! defined(EPPRESPONSEDATACHECK_HPP)    /* { */
#define       EPPRESPONSEDATACHECK_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataCheck.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppResponseData.hpp"
#include <util/ValueVectorOf.hpp>
#include <util/KeyValuePair.hpp>

#define	MAX_NUM_OF_CHECKS	16

/**
 * This <code>EppResponseDataCheck</code> class implements EPP Response
 * Data entity for EPP Command Check.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataCheck : public EppResponseData
{
protected:
	/**
	 * A vector for storing key and value pairs
	 */
	ValueVectorOf<KeyValuePair<DOMString, DOMString> > * hashMap;
	/**
	 * A vector for storing key and reason pairs
	 */
	ValueVectorOf<KeyValuePair<DOMString, DOMString> > * reasonHashMap;

	/**
	 * Converts shared <code>EppResponseDataCheck</code> component into
	 * XML elements
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param body the XML <code>DOM_Element</code> to be attached
	 * @param tag the XML tag for the object identifiers
	 */
	void toXMLCommon( DOM_Document& doc, DOM_Element& body, const DOMString& tag );

	/**
	 * Converts shared <code>EppResponseDataCheck</code> components from
	 * XML format.
	 * 
	 * @param root root node for the list of shared components
	 * @param tag the XML tag for the object identifiers
	 * @param ns the XML namespace for the object identifiers
	 */
	void fromXMLCommon( const DOM_Node& root, const DOMString& tag, const DOMString& ns );

public:
	/**
	 * Status for checking the existance of an object in the registry
	 */
	static const char * UNKNOWN;
	/**
	 * Status for checking the existance of an object in the registry
	 */
	static const char * FOUND;
	/**
	 * Status for checking the existance of an object in the registry
	 */
	static const char * NOT_FOUND;

	/**
	 * Constructor
	 */
	EppResponseDataCheck()
	{
		this->hashMap       = new ValueVectorOf<KeyValuePair<DOMString, DOMString> >(MAX_NUM_OF_CHECKS);
		this->reasonHashMap = new ValueVectorOf<KeyValuePair<DOMString, DOMString> >(MAX_NUM_OF_CHECKS);
	};

	/**
	 * Destructor
	 */
	virtual ~EppResponseDataCheck()
	{
		if( this->hashMap != null )
		{
			delete this->hashMap;
			this->hashMap = null;
		}
		if( this->reasonHashMap != null )
		{
			delete this->reasonHashMap;
			this->reasonHashMap = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCheck;
	};

	/**
	 * Gets the check result list associated with the result data of
	 * the check command - for backward compatibility, alias for getResultHashMap()
	 *
	 * @note this method is different from the Java API in which as
	 *       a hash table is returned instead of a vector.
	 */
	ValueVectorOf<KeyValuePair<DOMString, DOMString> > * getHashMap()
	{
		return this->hashMap;
	};

	/**
	 * Gets the check result list associated with the result data of
	 * the check command
	 *
	 * @note this method is different from the Java API in which as
	 *       a hash table is returned instead of a vector.
	 */
	ValueVectorOf<KeyValuePair<DOMString, DOMString> > * getResultHashMap()
	{
		return this->hashMap;
	};

	/**
	 * Gets the <code>HashMap</code> associated with the reason data of
	 * the check command
	 */
	ValueVectorOf<KeyValuePair<DOMString, DOMString> > *  getReasonHashMap()
	{
		return this->reasonHashMap;
	};

	/**
	 * Adds an entry into the <code>HashMap</code> for indicating if the
	 * object exists in the registry or not - for backward compatibility
	 *
	 * @param id   The Id associated with an EPP object, ROID for a contact
	 *             object, domain name for a domain object, host name for
	 *             a host object
	 * @param flag one of the <code>FOUND</code>, <code>NOT_FOUND</code>,
	 *             <code>UNKNWON</code>, indicating if the object exists in
	 *             the registry or not, or the existance is unknown
	 */
	void add( DOMString id, DOMString flag )
	{
		KeyValuePair<DOMString, DOMString> v(id, flag);
		this->hashMap->addElement(v);
		KeyValuePair<DOMString, DOMString> r(id, null);
		this->reasonHashMap->addElement(r);
	};

	/**
	 * Adds an entry into the <code>HashMap</code> for indicating if the
	 * object can be privisioned in the registry or not
	 *
	 * @param id   The Id associated with an EPP object, ROID for a contact
	 *             object, domain name for a domain object, host name for
	 *             a host object
	 * @param flag a boolean flag that indicates the availability of an
	 *             object, i.e.can it be provisioned or not.
	 */
	void add( DOMString id, bool flag )
	{
		this->add(id, flag, null);
	};

	/**
	 * Adds an entry into the <code>HashMap</code> for indicating if the
	 * object can be privisioned in the registry or not
	 *
	 * @param id   The Id associated with an EPP object, ROID for a contact
	 *             object, domain name for a domain object, host name for
	 *             a host object
	 * @param flag a boolean flag that indicates the availability of an
	 *             object, i.e.can it be provisioned or not.
	 * @param reason a reason text that provides more details of the status
	 */
	void add( DOMString id, bool flag, DOMString reason )
	{
		if( flag == true )
		{
			KeyValuePair<DOMString, DOMString> v(id, NOT_FOUND);
			this->hashMap->addElement(v);
		}
		else
		{
			KeyValuePair<DOMString, DOMString> v(id, FOUND);
			this->hashMap->addElement(v);
		}
		KeyValuePair<DOMString, DOMString> r(id, reason);
		this->reasonHashMap->addElement(r);
	};

	/**
	 * Checks if an object id is in the <code>HashMap</code>
	 *
	 * @return one of the <code>FOUND</code>, <code>NOT_FOUND</code>,
	 *         <code>UNKNWON</code>
	 */
	DOMString check( DOMString id );

	/**
	 * Checks if an object id is available for provisioning
	 */
	bool isAvailable( DOMString id );

	/**
	 * Gets the reason for an object id
	 */
	DOMString getReason( DOMString id );
};

#endif     /* EPPRESPONSEDATACHECK_HPP */  /* } */
