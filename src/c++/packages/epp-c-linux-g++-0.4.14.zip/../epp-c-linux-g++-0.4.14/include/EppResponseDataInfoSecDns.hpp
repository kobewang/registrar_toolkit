#if ! defined(EPPRESPONSEDATASECDNS_HPP)    /* { */
#define       EPPRESPONSEDATASECDNS_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataInfoSecDns.hpp,v 1.4 2012/07/12 16:30:49 nseshadr Exp $
 */
#include "EppExtension.hpp"
#include "EppSecDnsDsData.hpp"
#include <util/ValueVectorOf.hpp>

#define MAX_NUM_OF_DS_DATA	4

/**
 * This <code>EppCommandSecDns</code> class implements EPP SecDNS infData entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.4 $ $Date: 2012/07/12 16:30:49 $
 */
class EPP_EXPORT EppResponseDataInfoSecDns : public EppExtension
{
private:
	bool keyDataPresent;
	int maxSigLife;
	ValueVectorOf<EppSecDnsDsData> *dsDataList;
	ValueVectorOf<EppSecDnsKeyData> *keyDataList;

public:
	/**
	 * Creates an <code>EppCommandSecDns</code> object
	 */
	EppResponseDataInfoSecDns(uint8_t ver=EPPSECDNS_11):keyDataPresent(false)
	{
		maxSigLife = -1;
		this->dsDataList = new ValueVectorOf<EppSecDnsDsData>(MAX_NUM_OF_DS_DATA);
		this->keyDataList = new ValueVectorOf<EppSecDnsKeyData>(MAX_NUM_OF_DS_DATA);
		secDnsVersion = ver;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataInfoSecDns()
	{
		if( this->dsDataList != null )
		{
			delete this->dsDataList;
			this->dsDataList = null;
		}
		if( this->keyDataList != null )
		{
			delete this->keyDataList;
			this->keyDataList = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataInfoSecDns;
	};

	/**
	 * Adds DS Data to the list to be attached to a domain name
	 */
	void add( EppSecDnsDsData& dsData )
	{
		this->dsDataList->addElement(dsData);
	};
	void add( EppSecDnsKeyData& kdData ) {
		keyDataPresent = true;
		this->keyDataList->addElement(kdData);
	}


	/**
	 * Gets the list of DS data to be attached to a domain name
	 */
	ValueVectorOf<EppSecDnsDsData> * getDsData()
	{
        	return this->dsDataList;
	};
	ValueVectorOf<EppSecDnsKeyData> * getKeyData() {
		return this->keyDataList;
	};

	int getMaxSigLife()
	{
		return this->maxSigLife;
	}
	void setMaxSigLife( int life ) 
	{
		this->maxSigLife = life;
	}

	bool isKeyDataPresent() {
		return this->keyDataPresent;
	}


	/**
	 * Converts an XML element into an <code>EppResponseDataInfoSecDns</code> object.
	 * The caller of this method must make sure that the root node is of
	 * EPP SECDNS createType
	 *
	 * @param root root node for an <code>EppResponseDataInfoSecDns</code> object in XML format
	 *
	 * @return an <code>EppResponseDataInfoSecDns</code> object, or null if the node is invalid
	 */
	static EppResponseDataInfoSecDns * fromXML( const DOM_Node& root );

	/**
	 * Converts the <code>EppResponseDataInfoSecDns</code> object into an XML element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the <code>EppResponseDataInfoSecDns</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("infData"));
	};
};

#endif     /* EPPRESPONSEDATASECDNS_HPP */  /* } */
