#if ! defined(EPPEPPMARKADDRESS_HPP)    /* { */
#define       EPPEPPMARKADDRESS_HPP 1
#include <time.h>
#include "EppEntity.hpp"

class EPP_EXPORT EppMarkAddress: public EppEntity {
	public:
		EppMarkAddress();/*ctor*/ 
		EppMarkAddress(const EppMarkAddress&);/*copy ctor*/ 
		virtual ~EppMarkAddress();/*d'tor*/ 
		EppMarkAddress& operator=(const EppMarkAddress&);/*assigment*/ 
		/* getter(s) | setter(s) */ 
		DOMString streetLine1();/*getter street line1*/ 
		void streetLine1(DOMString &line1);/*setter street line1*/ 
		DOMString streetLine2();/*getter street line1*/ 
		void streetLine2(DOMString &line1);/*setter street line1*/ 
		DOMString streetLine3();/*getter street line1*/ 
		void streetLine3(const DOMString &line1);/*setter street line1*/ 
		DOMString city(void);
		void city(const DOMString&);
		DOMString stateProvince(void);
		void stateProvince(const DOMString &);
		DOMString postalCode(void);
		void postalCode(const DOMString &);
		DOMString countryCode(void);
		void countryCode(const DOMString &);
		virtual DOM_Element toXML(DOM_Document &doc, const DOMString &tag);
		static EppMarkAddress* fromXML( const DOM_Node& root );
		virtual DOMString toString();
		virtual int getEntityType();
	private:
		DOMString _street[3]; /*one, two or three ; optional street*/ 
		DOMString _city; 
		DOMString _sp;/* optional state/province*/ 
		DOMString _pc;/*postal code*/ 
		DOMString _cc;/*country code*/
};

#endif
