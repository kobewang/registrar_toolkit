#if ! defined(EPPCOMMANDUPDATELAUNCHREGISTRATION_HPP)    /* { */
#define       EPPCOMMANDUPDATELAUNCHREGISTRATION_HPP 1
#include "EppExtension.hpp"
#include "EppLaunchPhase.hpp"
#include <util/ValueVectorOf.hpp>

class EPP_EXPORT EppCommandUpdateLaunchRegistration : public EppExtension {
	public:
		EppCommandUpdateLaunchRegistration();
		EppCommandUpdateLaunchRegistration(const EppCommandUpdateLaunchRegistration&);
		EppCommandUpdateLaunchRegistration& operator=(const EppCommandUpdateLaunchRegistration&);
		virtual ~EppCommandUpdateLaunchRegistration();
                void phase(const EppLaunchPhase &_p);
                EppLaunchPhase phase(void);
		void applicationID(const DOMString &_id);
		DOMString applicationID(void);
		static EppCommandUpdateLaunchRegistration* fromXML( const DOM_Node& root );
		DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
		virtual DOMString toString();
		virtual int getEntityType();
	private:
		EppLaunchPhase _phase;
		DOMString _appId;
};

#endif
