#if ! defined(EPPCOMMANDCHECKLAUNCHREGISTRATION_HPP)    /* { */
#define       EPPCOMMANDCHECKLAUNCHREGISTRATION_HPP 1
#include "EppExtension.hpp"
#include "EppLaunchPhase.hpp"
#include <util/ValueVectorOf.hpp>

class EPP_EXPORT EppCommandCheckLaunchRegistration : public EppExtension {
	public:
		EppCommandCheckLaunchRegistration();
		EppCommandCheckLaunchRegistration(const EppCommandCheckLaunchRegistration&);
		EppCommandCheckLaunchRegistration& operator=(const EppCommandCheckLaunchRegistration&);
		void phase(const EppLaunchPhase &_p);
		EppLaunchPhase phase(void);
		void type(const DOMString &);
		DOMString type(void);
		static EppCommandCheckLaunchRegistration* fromXML( const DOM_Node& root );
		DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
		virtual DOMString toString();
		virtual int getEntityType();
		virtual ~EppCommandCheckLaunchRegistration();
	private:
		EppLaunchPhase _phase;
		DOMString _type;
};

#endif
