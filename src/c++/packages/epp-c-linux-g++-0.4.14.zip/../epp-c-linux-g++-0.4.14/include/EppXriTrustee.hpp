#if ! defined(EPPXRITRUSTEE_HPP)    /* { */
#define       EPPXRITRUSTEE_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppXriTrustee.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppEntity.hpp"

/**
 * This <code>EppXriTrustee</code> class defines trustee
 * information associated with XRI authority objects.  It
 * implements XRI trusteeType and trusteeInfType defined
 * in the XRI authority schema file.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppXriTrustee : public EppEntity
{
private:
	DOMString  authId;
	DOMString  inumber;
	bool       external;

public:
	/**
	 * Creates an <code>EppXriTrustee</code> object
	 */
	EppXriTrustee()
	{
		this->authId   = null;
		this->inumber  = null;
		this->external = false;
	};

	/**
	 * Destructor
	 */
	~EppXriTrustee() {} ;

	/**
	 * Returns true if this trustee is an external one
	 */
	bool isExternal()
	{
		return this->external;
	};

	/**
	 * Sets the boolean flag for indicating if this trustee is an external one or not
	 */
	void setExternal( bool flag )
	{
		this->external = flag;
	};

	/**
	 * Gets the identifier of the XRI authority as a trustee
	 *
	 * @return a string representing the XRI authority identifier,
	 * or null if the trustee is not an XRI authority object.
	 */
	DOMString getAuthorityId()
	{
		return this->authId;
	};

	/**
	 * Gets the i-number of the XRI i-number as a trustee
	 *
	 * @return a string representing the XRI i-number,
	 * or null if the trustee is not an XRI i-number object.
	 */
	DOMString getINumber()
	{
		return this->inumber;
	};

	/**
	 * Sets the identifier of an XRI authority as an internal trutee
	 *
	 * @param authId identifier of the XRI authority object
	 */
	void setAuthorityId( DOMString authId )
	{
		this->setAuthorityId(authId, false);
	};

	/**
	 * Sets the identifier of an XRI authority as a trustee, either external or internal
	 *
	 * @param authId identifier of the XRI authority object
	 * @param external flag indicating if the trustee is external or internal
	 */
	void setAuthorityId( DOMString authId, bool external )
	{
		this->authId   = authId;
		this->inumber  = null;
		this->external = external;
	};

	/**
	 * Sets the i-number of an XRI i-number as an internal trutee
	 *
	 * @param inumber i-number of the XRI i-number object
	 */
	void setINumber( DOMString inumber )
	{
		this->setINumber(inumber, false);
	};

	/**
	 * Sets the i-number of an XRI i-number as a trustee, either external or internal
	 *
	 * @param inumber i-number of the XRI i-number object
	 * @param external flag indicating if the trustee is external or internal
	 */
	void setINumber( DOMString inumber, bool external )
	{
		this->authId   = null;
		this->inumber  = inumber;
		this->external = external;
	};

	/**
         * Converts the <code>EppXriTrustee</code> object into an XML element
         *
         * @param doc the XML <code>DOM_Document</code> object
         * @param tag the tag/element name for the <code>EppXriTrustee</code> object
         *
         * @return an <code>DOM_Element</code> object
         */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppXriTrustee</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP XRI uriAddType or uriInfType.
	 *
	 * @param root root node for an <code>EppXriTrustee</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriTrustee</code> object, or null if the node is
	 *         invalid
	 */
	static EppXriTrustee * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("trustee"));
	};
};

#endif     /* EPPXRITRUSTEE_HPP */  /* } */
