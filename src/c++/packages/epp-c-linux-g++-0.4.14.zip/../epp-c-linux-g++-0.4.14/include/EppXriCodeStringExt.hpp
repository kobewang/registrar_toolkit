#ifndef EPPXRICODESTRINGEXT_HPP
#define EPPXRICODESTRINGEXT_HPP
#include "EppEntity.hpp"
#include "EppObject.hpp"

struct vas_t {
	DOMString name;
	DOMString value;
};

class EPP_EXPORT EppXriCodeStringExt: public EppEntity {
	public:
		EppXriCodeStringExt() { vas = new ValueVectorOf<vas_t>(3) ;}
		EppXriCodeStringExt(DOMString _name,DOMString _value) {
			vas = new ValueVectorOf<vas_t>(3);
			this->addVas(_name,_value);
		}
		void addVas(DOMString _name,DOMString _value) {
			vas_t v;
			v.name = _name;
			v.value = _value;
			vas->addElement(v);
		}
		ValueVectorOf<vas_t> & getVas() { return *(this->vas); }
		DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
		static EppXriCodeStringExt* fromXML( const DOM_Node& root );
		DOMString toString() {
			return  EppEntity::toString(DOMString("ext"));
		}
	private:
		ValueVectorOf<vas_t> * vas;
};
#endif
