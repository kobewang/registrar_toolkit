#if ! defined(EPPCOMMANDCHECKXRIAUTHORITY_HPP)    /* { */
#define       EPPCOMMANDCHECKXRIAUTHORITY_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandCheckXriAuthority.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppCommandCheck.hpp"

#define	MAX_NUM_OF_XRIAUTHORITY_IDS	16

/**
 * This <code>EppCommandCheckXriAuthority</code> class implements EPP Command Check
 * entity for EPP XRI Authority objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppCommandCheckXriAuthority : public EppCommandCheck
{
private:
	ValueVectorOf<DOMString> * authIds;

public:
	/**
	 * Creates an <code>EppCommandCheckXriAuthority</code> object
	 */
	EppCommandCheckXriAuthority()
	{
		this->authIds = new ValueVectorOf<DOMString>(MAX_NUM_OF_XRIAUTHORITY_IDS);
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandCheckXriAuthority</code> object, given a
	 * client transaction id associated with the operation
	 */
	EppCommandCheckXriAuthority( DOMString xid )
	{
		this->authIds = new ValueVectorOf<DOMString>(MAX_NUM_OF_XRIAUTHORITY_IDS);
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandCheckXriAuthority()
	{
		if( this->authIds != null )
		{
			delete this->authIds;
			this->authIds = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandCheckXriAuthority;
	};

	/**
	 * Gets the list of the identifiers of the XRI authority objects to be checked
	 */
	ValueVectorOf<DOMString> * getAuthorityId()
	{
		return this->authIds;
	};

	/**
	 * Gets the list of the identifiers of the XRI authority objects to be checked.
	 *
	 * <P><B>Note:</B> This is an alias for <code>getAuthorityId</code>
	 */
	ValueVectorOf<DOMString> * get()
	{
		return this->getAuthorityId();
	};

	/**
	 * Adds the identifier of an XRI authority object to the list of identifiers of XRI authority
	 * objects be checked
	 */
	void addAuthorityId( DOMString authId )
	{
		this->authIds->addElement(authId);
	};

	/**
	 * Adds the identifier of an XRI authority object to the list of identifiers of XRI authority
	 * objects be checked.
	 *
	 * <P><B>Note:</B> This is an alias for <code>addAuthorityId</code>
	 */
	void add( DOMString authId )
	{
		this->addAuthorityId(authId);
	};

	/**
	 * Converts the <code>EppCommandCheckXriAuthority</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandCheckXriAuthority</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandCheckXriAuthority</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Check entity for EPP XriAuthority objects.
	 *
	 * @param root root node for an <code>EppCommandCheckXriAuthority</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandCheckXriAuthority</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandCheckXriAuthority * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDCHECKXRIAUTHORITY_HPP */  /* } */
