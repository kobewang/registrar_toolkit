#if ! defined(EPPCOMMANDUPDATEXRICODESTRING_HPP)    /* { */
#define       EPPCOMMANDUPDATEXRICODESTRING_HPP 1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandUpdateXriCodeString.hpp,v 1.7 2010/01/07 01:19:55 nseshadr Exp $
 */
#include "EppCommandUpdate.hpp"
#include "EppXriCodeString.hpp"
#include "EppXriCodeStringExt.hpp"
#include "EppStatus.hpp"
#include "EppUtil.hpp"

class EPP_EXPORT EppCommandUpdateXriCodeString : public EppCommandUpdate {
public:
	EppCommandUpdateXriCodeString():codeString(""),
                                changedResStartDate(0),
                                changedResEndDate(0),
                                changedTotalRUnits(0),
                                changedTotalMUnits(0),totalRUnitsBase(0),totalMUnitsBase(0),actionResStartDate(""), actionResEndDate(""),
																actionTotalRUnits(""),actionTotalMUnits("") , CSExt(null), rmCSExt(null) {
		this->addedStatus = new ValueVectorOf<EppStatus>(3);
		this->removedStatus = new ValueVectorOf<EppStatus>(3);
		this->addedRecPat = new ValueVectorOf<EppXriResolutionPattern>(3);
		this->removedRecPat = new ValueVectorOf<EppXriResolutionPattern>(3);
	};
	EppCommandUpdateXriCodeString( DOMString csId):codeString(csId),
																changedResStartDate(0),
																changedResEndDate(0),
																changedTotalRUnits(0),
																changedTotalMUnits(0),totalRUnitsBase(0),totalMUnitsBase(0),actionResStartDate(""), actionResEndDate(""),
                                actionTotalRUnits(""),actionTotalMUnits("") , CSExt(null), rmCSExt(null) {
		this->addedStatus = new ValueVectorOf<EppStatus>(3);
		this->removedStatus = new ValueVectorOf<EppStatus>(3);
		this->addedRecPat = new ValueVectorOf<EppXriResolutionPattern>(3);
		this->removedRecPat = new ValueVectorOf<EppXriResolutionPattern>(3);
	};
	EppCommandUpdateXriCodeString( DOMString csId, DOMString xid ):codeString(csId),
                                changedResStartDate(0),
                                changedResEndDate(0),
                                changedTotalRUnits(0),
                                changedTotalMUnits(0),totalRUnitsBase(0),totalMUnitsBase(0),actionResStartDate(""), actionResEndDate(""),
                                actionTotalRUnits(""),actionTotalMUnits("") , CSExt(null), rmCSExt(null) {
		this->addedStatus = new ValueVectorOf<EppStatus>(3);
		this->removedStatus = new ValueVectorOf<EppStatus>(3);
		this->addedRecPat = new ValueVectorOf<EppXriResolutionPattern>(3);
		this->removedRecPat = new ValueVectorOf<EppXriResolutionPattern>(3);
		clTRID = xid;
	};
	~EppCommandUpdateXriCodeString() {
		if( addedStatus ) {
			delete addedStatus;
			addedStatus = null;
		}
		if( removedStatus ) {
			delete removedStatus;
			removedStatus = null;
		}
		if(addedRecPat) {
			delete addedRecPat;
			addedRecPat = null;
		}
		if(removedRecPat) {
			delete removedRecPat;
			removedRecPat = null;
		}
	};
	virtual int getEntityType() {
		return EppEntity::TYPE_EppCommandUpdateXriCodeString;
	};

	void setCodeString(DOMString new_cs ) {
		this->codeString = new_cs;
	}
	DOMString getCodeString() {
		return this->codeString;
	}


	void addNewStatus(EppStatus nstatus ) {
		if( !this->addedStatus ) {
			return;
		}
		this->addedStatus->addElement(nstatus);
	}
	ValueVectorOf<EppStatus>* getNewStatus() {
		return this->addedStatus;
	}
	void addRemStatus(EppStatus ostatus) {
		if( !this->removedStatus )
			return;
		this->removedStatus->addElement(ostatus);
	}
	ValueVectorOf<EppStatus>* getRemovedStatus() {
		return this->removedStatus;
	}
	void addNewRecPattterns(EppXriResolutionPattern np) {
		if( !this->addedRecPat )
			return;
		this->addedRecPat->addElement(np);
	}
	ValueVectorOf<EppXriResolutionPattern>* getNewRecPatterns() {
		return this->addedRecPat;
	}
	void addRemRecPattern(EppXriResolutionPattern op) {
		if( !this->removedRecPat )
			return;
		this->removedRecPat->addElement(op);
	}
	ValueVectorOf<EppXriResolutionPattern>* getRemovedRecPattern() {
		return this->removedRecPat;
	}
	void setResolutionStartDate(time_t sdate, int action) {
		this->changedResStartDate = sdate;
    if( action == DELETE_ACTION)
    {
      this->actionResStartDate = "del";
    }
    else if (action == UPDATE_ACTION)
    {
      this->actionResStartDate = "";
    }
	}
	time_t getResolutionStartDate() {
		return this->changedResStartDate;
	}
	void setResolutionEndDate(time_t edate, int action) {
		this->changedResEndDate = edate;
    if( action == DELETE_ACTION)
    {
      this->actionResEndDate = "del";
    }
    else if (action == UPDATE_ACTION)
    {
      this->actionResEndDate = "";
    }
	}
	time_t getResolutionEndDate() {
		return this->changedResEndDate;
	}
	void updateTotalRUnits(unsigned long chg,int action, unsigned long base) {
		this->changedTotalRUnits = chg;
		this->totalRUnitsBase = base;
    if( action == DELETE_ACTION)
    {
      this->actionTotalRUnits = "del";
    }
    else if (action == INCREMENT_ACTION)
    {
      this->actionTotalRUnits = "inc";
    }
    else if (action == DECREMENT_ACTION)
    {
      this->actionTotalRUnits = "dec";
    }

	}
	unsigned long getBaseRUnits() {
		return this->totalRUnitsBase;
	}
	unsigned long getTotalRUnits(void) {
		return this->changedTotalRUnits;
	}
	void updateTotalMUnits(unsigned long chg,int action, unsigned long base) {
		this->changedTotalMUnits = chg;
		this->totalMUnitsBase = base;
		if( action == DELETE_ACTION)
		{
			this->actionTotalMUnits = "del";
		}
		else if (action == INCREMENT_ACTION)
		{
			this->actionTotalMUnits = "inc";
		}
		else if (action == DECREMENT_ACTION)
		{
			this->actionTotalMUnits = "dec";
		}
	}
	unsigned long getTotalMCaps(void) {
		return this->changedTotalMUnits;
	}
	unsigned long getBaseMCaps(void) {
		return this->totalMUnitsBase;
	}
	DOMString getResolutionStartDateAction() {
		return this->actionResStartDate;
	}
	DOMString getResolutionEndDateAction() {
		return this->actionResEndDate;
	}
	DOMString getTotalRUnitsAction() {
		return this->actionTotalRUnits;
	}
	DOMString getTotalMCapsAction() {
		return this->actionTotalMUnits;
	}

	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
	static EppCommandUpdateXriCodeString * fromXML( const DOM_Node& root );
  void addValueAddedService(EppXriCodeStringExt & ext) {
		if( this->CSExt != null ) {
			delete this->CSExt;
			this->CSExt = null;
		}
		this->CSExt = new EppXriCodeStringExt(ext);
	}

	EppXriCodeStringExt* getValueAddedService(){
		return this->CSExt;
	}
	void removeValueAddedService(EppXriCodeStringExt & ext) {
		if( this->rmCSExt != null ) {
			delete this->rmCSExt;
			this->rmCSExt = null;
		}
		this->rmCSExt = new EppXriCodeStringExt(ext);
	}
	EppXriCodeStringExt* getRemovedValueAddedService(){
		return this->rmCSExt;
	}
	static const int DELETE_ACTION , INCREMENT_ACTION , DECREMENT_ACTION , UPDATE_ACTION;

protected:
	void objFromXml(DOM_Node & root, bool isadd );


private:
	DOMString																codeString;
	ValueVectorOf<EppStatus>								*addedStatus;
	ValueVectorOf<EppStatus>								*removedStatus;
	ValueVectorOf<EppXriResolutionPattern>	*addedRecPat;
	ValueVectorOf<EppXriResolutionPattern>	*removedRecPat;
	time_t																changedResStartDate;
	time_t																changedResEndDate;
	unsigned long														changedTotalRUnits;
	unsigned long														changedTotalMUnits;
	unsigned long														totalRUnitsBase;
	unsigned long														totalMUnitsBase;
	DOMString																actionResStartDate;
	DOMString																actionResEndDate;
	DOMString																actionTotalRUnits;
	DOMString																actionTotalMUnits;
	EppXriCodeStringExt                     *CSExt;
	EppXriCodeStringExt                     *rmCSExt;
};

#endif     /* EPPCOMMANDUPDATEXRICODESTRING_HPP */  /* } */
