#if ! defined(EPPRESPONSEDATACHECKCLAIMS_HPP)    /* { */
#define       EPPRESPONSEDATACHECKCLAIMS_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataCheckClaims.hpp,v 1.2 2013/07/09 18:26:37 achowdhu Exp $
 */
#include "EppResponseData.hpp"
#include "EppExtension.hpp"
#include <util/ValueVectorOf.hpp>
#include <util/KeyValuePair.hpp>
#include "EppLaunchPhase.hpp"

#define	MAX_NUM_OF_CLAIM_CHECKS	16

/**
 * This <code>EppResponseDataCheckClaims</code> class implements EPP Response
 * Data entity for EPP Command Check Claims.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2013/07/09 18:26:37 $
 */
class EPP_EXPORT EppResponseDataCheckClaims : public EppExtension
{
protected:
	/**
	 * A vector for storing key and value pairs
	 */
	ValueVectorOf<KeyValuePair<DOMString, DOMString> > * hashMap;
	/**
	 * A vector for storing key and claimKey pairs
	 */
	ValueVectorOf<KeyValuePair<DOMString, DOMString> > * claimKeyHashMap;

	/**
	* Value for launch:phase
	*/
	EppLaunchPhase _phase;

public:
	/**
	 * Converts <code>EppResponseDataCheckClaims</code> components into
	 * XML elements
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the XML tag for the object identifiers
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
	/**
	 * Converts shared <code>EppResponseDataCheck</code> components from
	 * XML format.
	 * 
	 * @param root root node for the list of shared components
	 */
	static EppResponseDataCheckClaims * fromXML( const DOM_Node& root );
	/**
	 * Status for checking the existance of an object in the registry
	 */
	static const char * UNKNOWN;
	/**
	 * Status for checking the existance of an object in the registry
	 */
	static const char * FOUND;
	/**
	 * Status for checking the existance of an object in the registry
	 */
	static const char * NOT_FOUND;

	/**
	 * Constructor
	 * Note: Instantiating the object on the stack will not work properly. Partivularly, the object destruction will fail in a fiery crash. This is due to some yet unknown behavior of the ValueVector object. So, always instantiate the object on the heap and everything will be fine.
	 */
	EppResponseDataCheckClaims();

	EppResponseDataCheckClaims(const EppResponseDataCheckClaims&);
	EppResponseDataCheckClaims& operator=(const EppResponseDataCheckClaims&);

	/**
	 * Destructor
	 */
	virtual ~EppResponseDataCheckClaims();

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCheckClaims;
	};

	/**
	 * Gets the check result list associated with the result data of
	 * the check command - for backward compatibility, alias for getResultHashMap()
	 *
	 * @note this method is different from the Java API in which as
	 *       a hash table is returned instead of a vector.
	 */
	ValueVectorOf<KeyValuePair<DOMString, DOMString> > * getHashMap()
	{
		return this->hashMap;
	};

	/**
	 * Gets the check result list associated with the result data of
	 * the check command
	 *
	 * @note this method is different from the Java API in which as
	 *       a hash table is returned instead of a vector.
	 */
	ValueVectorOf<KeyValuePair<DOMString, DOMString> > * getResultHashMap()
	{
		return this->hashMap;
	};

	/**
	 * Gets the <code>HashMap</code> associated with the claimKey data of
	 * the check command
	 */
	ValueVectorOf<KeyValuePair<DOMString, DOMString> > *  getClaimKeyHashMap()
	{
		return this->claimKeyHashMap;
	};

	/**
	 * Adds an entry into the <code>HashMap</code> for indicating if the
	 * object exists in the registry or not - for backward compatibility
	 *
	 * @param id   The Id associated with an EPP object, ROID for a contact
	 *             object, domain name for a domain object, host name for
	 *             a host object
	 * @param flag one of the <code>FOUND</code>, <code>NOT_FOUND</code>,
	 *             <code>UNKNWON</code>, indicating if the object exists in
	 *             the registry or not, or the existence is unknown
	 */
	void add( DOMString id, DOMString flag )
	{
		KeyValuePair<DOMString, DOMString> v(id, flag);
		this->hashMap->addElement(v);
		KeyValuePair<DOMString, DOMString> r(id, null);
		this->claimKeyHashMap->addElement(r);
	};

	/**
	 * Adds an entry into the <code>HashMap</code> for indicating if the
	 * object can be privisioned in the registry or not
	 *
	 * @param id   The Id associated with an EPP object, ROID for a contact
	 *             object, domain name for a domain object, host name for
	 *             a host object
	 * @param flag a boolean flag that indicates the availability of an
	 *             object, i.e.can it be provisioned or not.
	 */
	void add( DOMString id, bool flag )
	{
		this->add(id, flag, null);
	};

	/**
	 * Adds an entry into the <code>HashMap</code> for indicating if the
	 * object can be privisioned in the registry or not
	 *
	 * @param id   The Id associated with an EPP object, ROID for a contact
	 *             object, domain name for a domain object, host name for
	 *             a host object
	 * @param flag a boolean flag that indicates the availability of an
	 *             object, i.e.can it be provisioned or not.
	 * @param claimKey a claimKey text that provides more details of the status
	 */
	void add( DOMString id, bool flag, DOMString claimKey )
	{
		if( flag == true )
		{
			KeyValuePair<DOMString, DOMString> v(id, NOT_FOUND);
			this->hashMap->addElement(v);
		}
		else
		{
			KeyValuePair<DOMString, DOMString> v(id, FOUND);
			this->hashMap->addElement(v);
		}
		KeyValuePair<DOMString, DOMString> r(id, claimKey);
		this->claimKeyHashMap->addElement(r);
	};

	/**
	 * Checks if an object id is in the <code>HashMap</code>
	 *
	 * @return one of the <code>FOUND</code>, <code>NOT_FOUND</code>,
	 *         <code>UNKNWON</code>
	 */
	DOMString check( DOMString id );

	/**
	 * Checks if an object id is available for provisioning
	 */
	bool isAvailable( DOMString id );

	/**
	 * Gets the claimKey for an object id
	 */
	DOMString getClaimKey( DOMString id );

	/**
	* Gets the phase value
	*/
	EppLaunchPhase phase();

	/**
	* Sets the phase value
	*/
	void phase(const EppLaunchPhase & s);

	/**
	*
	*/
	DOMString toString();
};

#endif     /* EPPRESPONSEDATACHECKCLAIMS_HPP */  /* } */
