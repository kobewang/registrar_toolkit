#if ! defined(EPPXRIINUMBER_HPP)    /* { */
#define       EPPXRIINUMBER_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppXriNumber.hpp,v 1.4 2008/04/24 21:31:59 wtan Exp $
 */
#include "EppEntity.hpp"
#include "EppObject.hpp"
#include "EppPeriod.hpp"

/**
 * This <code>EppXriNumber</code> class implements EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.4 $ $Date: 2008/04/24 21:31:59 $
 */
class EPP_EXPORT EppXriNumber : public EppObject
{
private:
	DOMString   inumber;
	DOMString   refId;
	DOMString   authId;
	EppPeriod * period; 

public:
	/**
	 * I-Number status - clientDeleteProhibited
	 */
	static const char * STATUS_CLIENT_DELETE_PROHIBITED;
	/**
	 * I-Number status - clientHold
	 */
	static const char * STATUS_CLIENT_HOLD;
	/**
	 * I-Number status - clientRenewProhibited
	 */
	static const char * STATUS_CLIENT_RENEW_PROHIBITED;
	/**
	 * I-Number status - clientUpdateProhibited
	 */
	static const char * STATUS_CLIENT_UPDATE_PROHIBITED;
	/**
	 * I-Number status - ok
	 */
	static const char * STATUS_OK;
	/**
	 * I-Number status - pendingCreate
	 */
	static const char * STATUS_PENDING_CREATE;
	/**
	 * I-Number status - pendingDelete
	 */
	static const char * STATUS_PENDING_DELETE;
	/**
	 * I-Number status - pendingTransfer
	 */
	static const char * STATUS_PENDING_TRANSFER;
	/**
	 * I-Number status - pendingUpdate
	 */
	static const char * STATUS_PENDING_UPDATE;
	/**
	 * I-Number status - serverDeleteProhibited
	 */
	static const char * STATUS_SERVER_DELETE_PROHIBITED;
	/**
	 * I-Number status - serverHold
	 */
	static const char * STATUS_SERVER_HOLD;
	/**
	 * I-Number status - serverRenewProhibited
	 */
	static const char * STATUS_SERVER_RENEW_PROHIBITED;
	/**
	 * I-Number status - serverUpdateProhibited
	 */
	static const char * STATUS_SERVER_UPDATE_PROHIBITED;
	/**
	 * I-Number status - terminated
	 */
	static const char * STATUS_TERMINATED;

	/**
	 * Creates an <code>EppXriNumber</code> object
	 */
	EppXriNumber()
	{
		this->inumber    = null;
		this->refId      = null;
		this->authId     = null;
		this->period     = null;
	};

	/**
	 * Creates an <code>EppXriNumber</code> object with an XRI i-number
	 */
	EppXriNumber( DOMString inumber )
	{
		this->inumber    = inumber;
		this->refId      = null;
		this->authId     = null;
		this->period     = null;
	};

	/**
	 * Destructor
	 */
	~EppXriNumber()
	{
		EppObject::freeCommon();
		if( this->period != null )
		{
			delete this->period;
			this->period = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
        virtual int getEntityType()
	{
		return EppEntity::TYPE_EppXriNumber;
	};

	/**
	 * Gets the i-number
	 */
	DOMString getINumber()
	{
		return this->inumber;
	};

	/**
	 * Sets the i-number
	 */
	void setINumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Sets the identifier of the superorindate XRI authority object,
	 * and authInfo associated with the authority, if any
	 */
	void setAuthority( DOMString authId, EppAuthInfo authInfo )
	{
		this->authId   = authId;
		this->setAuthInfo(authInfo);
	};

	/**
	 * Gets the identifier of the superordinate XRI authority object
	 */
	DOMString getAuthorityId()
	{
		return this->authId;
	};

	/**
	 * Sets the identifier of the superordinate XRI authority object
	 */
	void setAuthorityId( DOMString authId )
	{
		this->authId = authId;
	};

	/**
	 * Gets the reference identifier used in generating the i-number, if any
	 */
	DOMString getReferenceId()
	{
		return this->refId;
	};

	/**
	 * Gets the reference identifier used in generating the i-number, if any
	 */
	void setReferenceId( DOMString refId )
	{
		this->refId = refId;
	};

	/**
	 * Gets registration period for the i-number
	 */
	EppPeriod * getPeriod()
	{
		return this->period;
	};

	/**
	 * Sets registration period for the i-number
	 */
	void setPeriod( EppPeriod period )
	{
		if( this->period == null )
		{
			this->period = new EppPeriod();
		}
		*(this->period) = period;
	};

	/**
	 * Converts the <code>EppXriNumber</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the <code>EppXriNumber</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppXriNumber</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP I-Number type.
	 *
	 * @param root root node for an <code>EppXriNumber</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriNumber</code> object, or null if the node
	 *         is invalid
	 */
	static EppXriNumber * fromXML( const DOM_Node& root );

#if 0
	/**
	 * Creates an <code>EppCommandDeleteXriNumber</code> object for
	 * deleting an EPP XRI I-Number object from the registry.
	 *
	 * @param inumber the i-number of the XRI i-number object to be deleted
	 * @param xid     the client transaction id associated with the operation
	 */
	public static EppCommandDeleteXriNumber delete( String inumber, String xid )
	{
		return new EppCommandDeleteXriNumber(inumber, xid);
	}

	/**
	 * Creates an <code>EppCommandInfoXriNumber</code> object for
	 * querying the details of an EPP XRI I-Number object
	 *
	 * @param inumber the i-number of the XRI i-number object to be queried
	 * @param xid     the client transaction id associated with the operation
	 */
	public static EppCommandInfoXriNumber info( String inumber, String xid )
	{
		return new EppCommandInfoXriNumber(inumber, xid);
	}

	/**
	 * Creates an <code>EppCommandCheckXriNumber</code> object for
	 * checking the existance of EPP XRI I-Number objects in the registry.
	 * Identifiers of EPP XRI I-Number objects can be added via the
	 * <code>add</code> or <code>addINumber</code> methods.
	 *
	 * @param xid  the client transaction id associated with the operation
	 */
	public static EppCommandCheckXriNumber check( String xid )
	{
		return new EppCommandCheckXriNumber(xid);
	}

	/**
	 * Creates an <code>EppCommandRenewXriNumber</code> object for
	 * renewing the registration of an EPP XRI I-Number object in the registry.
	 *
	 * @param inumber    the inumber of the XRI i-number object to be renewed
	 * @param curExpDate the current expiration date of the svcsub object
	 * @param period     the new registration period of the svcsub object,
	 *                   or null if using the value specified by the
	 *                   registry
	 * @param xid        the client transaction id associated with the
	 *                   operation
	 */
	public static EppCommandRenewXriNumber renew( String inumber, Calendar curExpDate, EppPeriod period, String xid )
	{
		return new EppCommandRenewXriNumber(inumber, curExpDate, period, xid);
	}

	/**
	 * Creates an <code>EppCommandUpdateXriNumber</code> object for
	 * updating an EPP I-Number object in the registry. The actual update
	 * information should be specified via the various methods defined
	 * for the <code>EppCommandUpdateXriNumber</code> object.
	 *
	 * @param inumber the i-number of the XRI i-number object to be updated
	 * @param xid    the client transaction id associated with the operation
	 */
	public static EppCommandUpdateXriNumber update( String inumber, String xid )
	{
		return new EppCommandUpdateXriNumber(inumber, xid);
	}
#endif

	DOMString toString()
	{
		return EppEntity::toString(DOMString("xriINU"));
	};
};

#endif     /* EPPXRIINUMBER_HPP */  /* } */
