#if ! defined(EPPCOMMANDRENEWXRIINAME_HPP)    /* { */
#define       EPPCOMMANDRENEWXRIINAME_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandRenewXriName.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppCommandRenew.hpp"

/**
 * This <code>EppCommandRenewXriName</code> class implements EPP Command Renew
 * entity for EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppCommandRenewXriName : public EppCommandRenew
{
private:
	 DOMString iname;

public:
	/**
	 * Creates an <code>EppCommandRenewXriName</code> object
	 */
	EppCommandRenewXriName()
	{
		this->iname = null;
	};

	/**
	 * Creates an <code>EppCommandRenewXriName</code> object with a
	 * default expiration period, specified by the registry
	 */
	EppCommandRenewXriName( DOMString iname, time_t curExpDate )
	{
		this->iname = iname;
		this->curExpDate = curExpDate;
	};

	/**
	 * Creates an <code>EppCommandRenewXriName</code> object with a
	 * client transaction id associated with the operation. The current
	 * date of expiration would be the current date.
	 */
	EppCommandRenewXriName( DOMString iname, DOMString xid )
	{
		this->iname = iname;
		this->clTRID = xid;
	};

	/**
	 * Creates an <code>EppCommandRenewXriName</code> object with a
	 * default expiration period, specified by the registry, and a
	 * client transaction id associated with the operation
	 */
	EppCommandRenewXriName( DOMString iname, time_t curExpDate, DOMString xid )
	{
		this->iname = iname;
		this->curExpDate = curExpDate;
		this->clTRID = xid;
	};

	/**
	 * Creates an <code>EppCommandRenewXriName</code> object with a
	 * specified expiration period, and a client transaction id associated
	 * with the operation
	 */
	EppCommandRenewXriName( DOMString iname, time_t curExpDate, EppPeriod period, DOMString xid )
	{
		this->iname = iname;
		this->curExpDate = curExpDate;
		this->clTRID = xid;
		this->setPeriod(period);
	};

	/**
	 * Destructor
	 */
	~EppCommandRenewXriName() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandRenewXriName;
	};

	/**
	 * Gets the i-name of the XRI i-name object to be renewed
	 */
	DOMString getIName()
	{
		return this->iname;
	};

	/**
	 * Sets the i-name of the XRI i-name object to be renewed
	 */
	void setIName( DOMString iname )
	{
		this->iname = iname;
	};

	/**
	 * Converts the <code>EppCommandRenewXriName</code> object into
	 *		an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *		<code>EppCommandRenewXriName</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandRenewXriName</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Renew entity for EPP XRI I-Name object
	 *
	 * @param root root node for an <code>EppCommandRenewXriName</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandRenewXriName</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandRenewXriName * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDRENEWXRIINAME_HPP */  /* } */
