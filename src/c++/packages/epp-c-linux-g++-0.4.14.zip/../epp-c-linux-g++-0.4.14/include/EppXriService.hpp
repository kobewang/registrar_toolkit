#if ! defined(EPPXRIISERVICE_HPP)    /* { */
#define       EPPXRIISERVICE_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppXriService.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppEntity.hpp"
#include "EppObject.hpp"
#include "EppPeriod.hpp"

/**
 * This <code>EppXriService</code> class implements EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppXriService : public EppObject
{
private:
	DOMString                  id;
	DOMString                  type;
	DOMString                  authId;
	EppPeriod                * period; 
	ValueVectorOf<DOMString> * uri;

public:
	/**
	 * I-Service status - clientDeleteProhibited
	 */
	static const char * STATUS_CLIENT_DELETE_PROHIBITED;
	/**
	 * I-Service status - clientHold
	 */
	static const char * STATUS_CLIENT_HOLD;
	/**
	 * I-Service status - clientRenewProhibited
	 */
	static const char * STATUS_CLIENT_RENEW_PROHIBITED;
	/**
	 * I-Service status - clientUpdateProhibited
	 */
	static const char * STATUS_CLIENT_UPDATE_PROHIBITED;
	/**
	 * I-Service status - ok
	 */
	static const char * STATUS_OK;
	/**
	 * I-Service status - pendingCreate
	 */
	static const char * STATUS_PENDING_CREATE;
	/**
	 * I-Service status - pendingDelete
	 */
	static const char * STATUS_PENDING_DELETE;
	/**
	 * I-Service status - pendingTransfer
	 */
	static const char * STATUS_PENDING_TRANSFER;
	/**
	 * I-Service status - pendingUpdate
	 */
	static const char * STATUS_PENDING_UPDATE;
	/**
	 * I-Service status - serverDeleteProhibited
	 */
	static const char * STATUS_SERVER_DELETE_PROHIBITED;
	/**
	 * I-Service status - serverHold
	 */
	static const char * STATUS_SERVER_HOLD;
	/**
	 * I-Service status - serverRenewProhibited
	 */
	static const char * STATUS_SERVER_RENEW_PROHIBITED;
	/**
	 * I-Service status - serverUpdateProhibited
	 */
	static const char * STATUS_SERVER_UPDATE_PROHIBITED;

	/**
	 * Creates an <code>EppXriService</code> object
	 */
	EppXriService()
	{
		this->id         = null;
		this->type       = null;
		this->authId     = null;
		this->period     = null;
		this->uri        = new ValueVectorOf<DOMString>(3);
	};

	/**
	 * Creates an <code>EppXriService</code> object with an XRI i-service identifier
	 */
	EppXriService( DOMString id )
	{
		this->id         = id;
		this->type       = null;
		this->authId     = null;
		this->period     = null;
		this->uri        = new ValueVectorOf<DOMString>(3);
	};

	/**
	 * Destructor
	 */
	~EppXriService()
	{
		EppObject::freeCommon();
		if( this->period != null )
		{
			delete this->period;
			this->period = null;
		}
		if( this->uri != null )
		{
			delete this->uri;
			this->uri = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
        virtual int getEntityType()
	{
		return EppEntity::TYPE_EppXriService;
	};

	/**
	 * Gets the i-service identifier
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the i-service identifier
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Sets the identifier of the superorindate XRI authority object,
	 * and authInfo associated with the authority, if any
	 */
	void setAuthority( DOMString authId, EppAuthInfo authInfo )
	{
		this->authId   = authId;
		this->setAuthInfo(authInfo);
	};

	/**
	 * Gets the identifier of the superordinate XRI authority object
	 */
	DOMString getAuthorityId()
	{
		return this->authId;
	};

	/**
	 * Sets the identifier of the superordinate XRI authority object
	 */
	void setAuthorityId( DOMString authId )
	{
		this->authId = authId;
	};

	/**
	 * Gets i-service type
	 */
	DOMString getType()
	{
		return this->type;
	};

	/**
	 * Sets i-service type
	 */
	void setType( DOMString type )
	{
		this->type = type;
	};

	/**
	 * Gets the list of URIs associated with the XRI i-service object
	 */
	ValueVectorOf<DOMString> * getURI()
	{
		return this->uri;
	};

	/**
	 * Adds a URL to the list of URIs associated with the XRI i-service object
	 */
	void addURI( DOMString uri )
	{
		this->uri->addElement(uri);
	};

	/**
	 * Gets registration period for the i-service
	 */
	EppPeriod * getPeriod()
	{
		return this->period;
	};

	/**
	 * Sets registration period for the i-service
	 */
	void setPeriod( EppPeriod period )
	{
		if( this->period == null )
		{
			this->period = new EppPeriod();
		}
		*(this->period) = period;
	};

	/**
	 * Converts the <code>EppXriService</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the <code>EppXriService</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppXriService</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP I-Service type.
	 *
	 * @param root root node for an <code>EppXriService</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriService</code> object, or null if the node
	 *         is invalid
	 */
	static EppXriService * fromXML( const DOM_Node& root );

#if 0
	/**
	 * Creates an <code>EppCommandDeleteXriService</code> object for
	 * deleting an EPP XRI I-Service object from the registry.
	 *
	 * @param id  the identifier of the XRI i-service object to be deleted
	 * @param xid the client transaction id associated with the operation
	 */
	public static EppCommandDeleteXriService delete( String id, String xid )
	{
		return new EppCommandDeleteXriService(id, xid);
	}

	/**
	 * Creates an <code>EppCommandInfoXriService</code> object for
	 * querying the details of an EPP XRI I-Service object
	 *
	 * @param id  the identifier of the XRI i-service object to be queried
	 * @param xid the client transaction id associated with the operation
	 */
	public static EppCommandInfoXriService info( String id, String xid )
	{
		return new EppCommandInfoXriService(id, xid);
	}

	/**
	 * Creates an <code>EppCommandCheckXriService</code> object for
	 * checking the existance of EPP XRI I-Service objects in the registry.
	 * Identifiers of EPP XRI I-Service objects can be added via the
	 * <code>add</code> or <code>addIService</code> methods.
	 *
	 * @param xid  the client transaction id associated with the operation
	 */
	public static EppCommandCheckXriService check( String xid )
	{
		return new EppCommandCheckXriService(xid);
	}

	/**
	 * Creates an <code>EppCommandRenewXriService</code> object for
	 * renewing the registration of an EPP XRI I-Service object in the registry.
	 *
	 * @param id         the identifier of the XRI i-service object to be renewed
	 * @param curExpDate the current expiration date of the svcsub object
	 * @param period     the new registration period of the svcsub object,
	 *                   or null if using the value specified by the
	 *                   registry
	 * @param xid        the client transaction id associated with the
	 *                   operation
	 */
	public static EppCommandRenewXriService renew( String id, Calendar curExpDate, EppPeriod period, String xid )
	{
		return new EppCommandRenewXriService(id, curExpDate, period, xid);
	}

	/**
	 * Creates an <code>EppCommandUpdateXriService</code> object for
	 * updating an EPP I-Service object in the registry. The actual update
	 * information should be specified via the various methods defined
	 * for the <code>EppCommandUpdateXriService</code> object.
	 *
	 * @param id  the identifier of the XRI i-service object to be updated
	 * @param xid the client transaction id associated with the operation
	 */
	public static EppCommandUpdateXriService update( String id, String xid )
	{
		return new EppCommandUpdateXriService(id, xid);
	}
#endif

	DOMString toString()
	{
		return EppEntity::toString(DOMString("xriISV"));
	};
};

#endif     /* EPPXRIISERVICE_HPP */  /* } */
