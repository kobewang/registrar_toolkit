#if ! defined(EPPENCODEDSIGNEDMARKDATA_HPP)    /* { */
#define       EPPENCODEDSIGNEDMARKDATA_HPP 1
#include "EppEntity.hpp"

class EPP_EXPORT EppEncodedSignedMarkData: public EppEntity {
	public:
		EppEncodedSignedMarkData();
		EppEncodedSignedMarkData(const EppEncodedSignedMarkData&);
		EppEncodedSignedMarkData& operator=(const EppEncodedSignedMarkData&);
		virtual ~EppEncodedSignedMarkData();
		void rawXml(const DOMString&);
		DOMString rawXml(void);
		bool hasSMD();
		void hasSMD(bool);
		virtual DOM_Element toXML(DOM_Document &doc, const DOMString &tag);
		virtual DOMString toString();
		static EppEncodedSignedMarkData* fromXML( const DOM_Node& root );
		virtual int getEntityType();
	private:
		DOMString _rawXml; /*shall only be used in C++ RTK*/
		bool _hasElement;
};
#endif
