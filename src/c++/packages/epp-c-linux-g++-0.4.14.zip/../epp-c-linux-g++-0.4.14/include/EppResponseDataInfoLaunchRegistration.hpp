#if ! defined(EppResponseDataInfoLaunchRegistration_HPP)    /* { */
#define       EppResponseDataInfoLaunchRegistration_HPP 1
#include "EppExtension.hpp"
#include "EppMarkMark.hpp"
#include "EppStatus.hpp"
#include "EppLaunchPhase.hpp"

class EPP_EXPORT EppResponseDataInfoLaunchRegistration : public EppExtension {
	public:
		EppResponseDataInfoLaunchRegistration();
		EppResponseDataInfoLaunchRegistration(const EppResponseDataInfoLaunchRegistration&);
		EppResponseDataInfoLaunchRegistration& operator=(const EppResponseDataInfoLaunchRegistration&);
		virtual ~EppResponseDataInfoLaunchRegistration();
		void phase(const EppLaunchPhase&);
		EppLaunchPhase phase();
		void applicationId(const DOMString &);
		DOMString applicationId(void);
		void status(const DOMString& _s);
		DOMString status(void);
		void mark(EppMarkMark* _mark);
		EppMarkMark* mark(void);
		static EppResponseDataInfoLaunchRegistration* fromXML( const DOM_Node& root );
		virtual DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
		virtual DOMString toString();
		virtual int getEntityType();
	private:
		EppLaunchPhase  _phase;
		DOMString _appId;
		EppStatus _status;
		EppMarkMark *_mark;
		bool isStatusSet;
};

#endif
