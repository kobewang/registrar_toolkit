#if ! defined(EPPXRIRESOLUTIONPATTERN_HPP)    /* { */
#define       EPPXRIRESOLUTIONPATTERN_HPP				1
#include "EppEntity.hpp"
class EPP_EXPORT EppXriResolutionPattern : public EppEntity {
	public:
		EppXriResolutionPattern():patternId(""),min("*"),hrs("*"),dom("*"),mon("*"),dow("*") {
		}
		EppXriResolutionPattern(DOMString pid):patternId(pid),min("*"),hrs("*"),dom("*"),mon("*"),dow("*") {
		}
		
		void setPatternId(DOMString pid) {
			this->patternId = pid;
		}
		void setMin(DOMString _min) {
			this->min = _min;
		}
		void setHours(DOMString _hrs) {
			this->hrs = _hrs;
		}
		void setDayOfMonth(DOMString _dom) {
			this->dom = _dom;
		}
		void setMonth(DOMString _mon) {
			this->mon = _mon;
		}
		void setDayOfWeek(DOMString _dow) {
			this->dow = _dow;
		}

		DOMString getPatternId() {
			return this->patternId;
		}
		DOMString getMin() {
			return this->min;
		}
		DOMString getHours() {
			return this->hrs;
		}
		DOMString getDayOfMonth() {
			return this->dom;
		}
		DOMString getMonth() {
			return this->mon;
		}
		DOMString getDayOfWeek() {
			return this->dow;
		}
	
		DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
		static EppXriResolutionPattern* fromXML( const DOM_Node& root );
		DOMString toString() {
			return  EppEntity::toString(DOMString("resolutionIntervalRecurrencePattern"));
		}
	private:
		DOMString patternId,min,hrs,dom,mon,dow;
};
#endif
