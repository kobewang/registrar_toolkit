#if ! defined(EPPRESULTMESSAGE_HPP)    /* { */
#define       EPPRESULTMESSAGE_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResultMessage.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppEntity.hpp"

/**
 * This <code>EppResultMessage</code> class implements EPP Result Message
 * entity.
 *
 * <P>The <I>id</I> tag has been removed from EPP-1.0. For backward compatibility,
 * the API is unchanged, but the <I>id</I> value would always be null.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResultMessage : public EppEntity
{
private:
	DOMString id;
	DOMString lang;
	DOMString msg;

public:
	/**
	 * Creates an <code>EppResultMessage</code> object
	 */
	EppResultMessage()
	{
		this->id = null;
		this->lang = null;
		this->msg = null;
	};

	/**
	 * Creates an <code>EppResultMessage</code> object
	 *
	 * @param message message to be returned
	 */
	EppResultMessage( DOMString message )
	{
		this->id = null;
		this->lang = DOMString("en-US");
		this->msg = message;
		this->id = null;
	};

	/**
	 * Creates an <code>EppResultMessage</code> object
	 *
	 * @param id message id
	 * @param message message to be returned
	 */
	EppResultMessage( DOMString id, DOMString message )
	{
		this->id = id;
		this->lang = DOMString("en-US");
		this->msg = message;
		this->id = null;
	};

	/**
	 * Creates an <code>EppResultMessage</code> object
	 *
	 * @param id message id
	 * @param language langaue type of the message
	 * @param message message to be returned
	 */
	EppResultMessage( DOMString id, DOMString language, DOMString message )
	{
		this->id = id;
		this->lang = language;
		this->msg = message;
		this->id = null;
	};

	/**
	 * Destructor
	 */
	~EppResultMessage() {};

	/**
	 * Gets message id
	 *
	 * This method is not functional in EPP-1.0, will be removed in the future.
	 *
	 * Please use EppResponse::getMessageId() instead
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets message id
	 *
	 * This method is not functional in EPP-1.0, will be removed in the future.
	 *
	 * Please use EppResponse::setMessageId() instead
	 */
	void setId( DOMString id )
	{
		this->id = id;
		this->id = null;
	};

	/**
	 * Gets message to be returned
	 */
	DOMString getMessage()
	{
		return this->msg;
	};

	/**
	 * Sets message to be returned
	 */
	void setMessage( DOMString message )
	{
		this->msg = message;
	};

	/**
	 * Gets language type of the message
	 */
	DOMString getLanguage()
	{
		return this->lang;
	};

	/**
	 * Sets language type of the message
	 */
	void setLanguage( DOMString language )
	{
		this->lang = language;
	};

	/**
	 * Converts the <code>EppResultMessage</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the <code>EppResultMessage</code>
	 *            object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppResultMessage</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP msgType.
	 *
	 * @param root root node for an <code>EppResultMessage</code> object in
	 *             XML format
	 *
	 * @return an <code>EppResultMessage</code> object, or null if the node
	 *         is invalid
	 */
	static EppResultMessage * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("msg"));
	};
};

#endif     /* EPPRESULTMESSAGE_HPP */  /* } */
