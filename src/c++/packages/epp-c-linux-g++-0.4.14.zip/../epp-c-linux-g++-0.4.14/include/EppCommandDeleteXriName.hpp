#if ! defined(EPPCOMMANDDELETEXRIINAME_HPP)    /* { */
#define       EPPCOMMANDDELETEXRIINAME_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandDeleteXriName.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppCommandDelete.hpp"

/**
 * This <code>EppCommandDelete</code> class implements EPP Command Delete
 * entity for EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppCommandDeleteXriName : public EppCommandDelete
{
private:
	DOMString iname;

public:
	/**
	 * Creates an <code>EppCommandDeleteXriName</code> object for
	 * deleting an XRI i-name based on its i-name
	 */
	EppCommandDeleteXriName( DOMString iname )
	{
		this->iname = iname;
	};

	/**
	 * Creates an <code>EppCommandDeleteXriName</code> object for
	 * deleting an XRI i-name based on its i-name, given a client
	 * transaction id associated with the operation
	 */
	EppCommandDeleteXriName( DOMString iname, DOMString xid )
	{
		this->iname = iname;
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandDeleteXriName() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandDeleteXriName;
	};

	/**
	 * Gets the i-name of the XRI i-name object to be deleted
	 */
	DOMString getIName()
	{
		return this->iname;
	};

	/**
	 * Sets the i-name of the XRI i-name object to be deleted
	 */
	void setIName( DOMString iname )
	{
		this->iname = iname;
	};

	/**
	 * Converts the <code>EppCommandDeleteXriName</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandDeleteXriName</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandDeleteXriName</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Delete entity for EPP XriName object.
	 *
	 * @param root root node for an <code>EppCommandDeleteXriName</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandDeleteXriName</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandDeleteXriName * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDDELETEXRIINAME_HPP */  /* } */
