#ifndef EPPGENERICNVPAIRS_HPP
#define EPPGENERICNVPAIRS_HPP
#include "EppEntity.hpp"
#include "EppObject.hpp"

struct pair_t {
	DOMString name;
	DOMString value;
};

class EPP_EXPORT EppGenericNVPairs {
	public:
		EppGenericNVPairs() { vas = new ValueVectorOf<pair_t>(3) ;}
		EppGenericNVPairs(DOMString _name,DOMString _value) {
			vas = new ValueVectorOf<pair_t>(3);
			this->addGenericNVPair(_name,_value);
		}
		~EppGenericNVPairs() { if (vas != null) { delete vas ; vas = null;} };
		 EppGenericNVPairs( EppGenericNVPairs & pairs) {
			vas = new ValueVectorOf<pair_t>(3);
			ValueVectorOf<pair_t> &  allTuples = pairs.getGenericNVPairs();
			int sizeof_vec = allTuples.size();

        for(int i=0;i<sizeof_vec;i++) {
                pair_t v = allTuples.elementAt(i);
					 addGenericNVPair(v.name,v.value);
        }

		}
		EppGenericNVPairs & operator=(EppGenericNVPairs & rhs)
		{
			if(this != &rhs)
			{
				delete vas;
				vas = new ValueVectorOf<pair_t>(3);
				ValueVectorOf<pair_t> &  allTuples = rhs.getGenericNVPairs();
				int sizeof_vec = allTuples.size();
				for(int i=0;i<sizeof_vec;i++) {
					pair_t v = allTuples.elementAt(i);
					addGenericNVPair(v.name,v.value);
				}
			}
			return *this;
		}
		void addGenericNVPair(DOMString _name,DOMString _value) {
			pair_t v;
			v.name = _name;
			v.value = _value;
			vas->addElement(v);
		}
		ValueVectorOf<pair_t> & getGenericNVPairs() { return *(this->vas); }
		DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
		static EppGenericNVPairs* fromXML( const DOM_Node& root );
		DOMString toString() {
			return  "genericNVPairs";
		}
		int howMany()
		{
			if(vas == null)
			{
				return 0;
			}
			return vas->size();

		}
	private:
		ValueVectorOf<pair_t> * vas;
};
#endif
