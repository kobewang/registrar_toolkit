#if ! defined(EPPCOMMANDCHECKXRICODESTRING_HPP)    /* { */
#define       EPPCOMMANDCHECKXRICODESTRING_HPP 1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 */
#include "EppCommandCheck.hpp"

#define	MAX_NUM_OF_XRICODESTRING_IDS	1

class EPP_EXPORT EppCommandCheckXriCodeString: public EppCommandCheck
{
private:
	ValueVectorOf<DOMString> *codeString;

public:
	/**
	 * Creates an <code>EppCommandCheckXriCodeString</code> object
	 */
	EppCommandCheckXriCodeString()
	{
		this->codeString = new ValueVectorOf<DOMString>(MAX_NUM_OF_XRICODESTRING_IDS);
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandCheckXriCodeString</code> object, given a
	 * client transaction id associated with the operation
	 */
	EppCommandCheckXriCodeString( DOMString xid )
	{
		this->codeString = new ValueVectorOf<DOMString>(MAX_NUM_OF_XRICODESTRING_IDS);
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandCheckXriCodeString()
	{
		if( this->codeString != null )
		{
			delete this->codeString;
			this->codeString = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandCheckXriCodeString;
	};

	/**
	 * Gets the list of the identifiers of the XRI codeString objects to be checked
	 */
	ValueVectorOf<DOMString> * getCodeStringId()
	{
		return this->codeString;
	};

	/**
	 * Gets the list of the identifiers of the XRI codeString objects to be checked.
	 *
	 * <P><B>Note:</B> This is an alias for <code>getCodeStringId</code>
	 */
	ValueVectorOf<DOMString> * get()
	{
		return this->getCodeStringId();
	};

	/**
	 * Adds the identifier of an XRI codeString object to the list of identifiers of XRI codeString
	 * objects be checked
	 */
	void addCodeStringId( DOMString csId )
	{
		this->codeString->addElement(csId);
	};

	/**
	 * Adds the identifier of an XRI codeString object to the list of identifiers of XRI codeString
	 * objects be checked.
	 *
	 * <P><B>Note:</B> This is an alias for <code>addCodeStringId</code>
	 */
	void add( DOMString csId)
	{
		this->addCodeStringId(csId);
	};

	/**
	 * Converts the <code>EppCommandCheckXriCodeString</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandCheckXriCodeString</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandCheckXriCodeString</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Check entity for EPP XriCodeString objects.
	 *
	 * @param root root node for an <code>EppCommandCheckXriCodeString </code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandCheckXriCodeString </code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandCheckXriCodeString * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDCHECKXRICODESTRING_HPP */  /* } */
