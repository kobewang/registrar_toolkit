#if ! defined(EPPEPPMARKDATA_HPP)    /* { */
#define       EPPEPPMARKDATA_HPP 1
#include <time.h>
#include "EppEntity.hpp"
#include "EppMarkHolder.hpp"
#include <util/ValueVectorOf.hpp>

class EPP_EXPORT EppMarkData: public EppEntity {
	public:
		EppMarkData();
		EppMarkData(const EppMarkData&);
		virtual ~EppMarkData();
		EppMarkData& operator=(const EppMarkData&);
		void id(const DOMString &_id);
		DOMString id(void);
		void markName(const DOMString& _name);
		DOMString markName(void);
		void addHolder(const EppMarkHolder&);
		ValueVectorOf<EppMarkHolder> holder(void);
		void addContact(const EppMarkHolder&);
		ValueVectorOf<EppMarkHolder> contact(void);
		void addLabel(const DOMString&);
		ValueVectorOf<DOMString> labels(void);
		void goodsServices(const DOMString&);
		DOMString goodsServices(void);
		virtual DOM_Element toXML(DOM_Document &doc, const DOMString &tag);
		void fromXml( const DOM_Node& root );/*check the name of the function.it's not by accident.*/
		/*virtual DOMString toString(); by design we have commented it out*/
	protected:
		DOMString Id; 
		DOMString _markName; 
		ValueVectorOf<EppMarkHolder> _holder; /* ? */
		ValueVectorOf<EppMarkHolder> _contact; /* * */
		ValueVectorOf<DOMString> _label; /* * */
		DOMString goodsAndServices; 
};
#endif
