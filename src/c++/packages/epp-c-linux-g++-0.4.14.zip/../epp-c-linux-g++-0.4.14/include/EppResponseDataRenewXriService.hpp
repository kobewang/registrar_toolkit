#if ! defined(EPPRESPONSEDATARENEWISERVICE_HPP)    /* { */
#define       EPPRESPONSEDATARENEWISERVICE_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataRenewXriService.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include <time.h>
#include "EppResponseDataRenew.hpp"

/**
 * This <code>EppResponseDataRenewXriService</code> class implements EPP
 * Response Data entity for EPP Command Renew of EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataRenewXriService : public EppResponseDataRenew
{
private:
	DOMString id;
	time_t    exDate;

public:
	/**
	 * Creates an <code>EppResponseDataRenewXriService</code> object
	 *
	 * @param id the identifier of the XRI i-service object renewed
	 */
	EppResponseDataRenewXriService()
	{
		this->id = null;
		this->roid = null;
		this->exDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataRenewXriService</code> object
	 *
	 * @param id the identifier of the XRI i-service object renewed
	 */
	EppResponseDataRenewXriService( DOMString id )
	{
		this->id = id;
		this->roid = null;
		this->exDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataRenewXriService</code> object
	 *
	 * @param id     the identifier of the XRI i-service object renewed
	 * @param exDate the expiration date of the XRI i-service
	 *               object renewed
	 */
	EppResponseDataRenewXriService( DOMString id, time_t exDate )
	{
		this->id = id;
		this->roid = null;
		this->exDate = exDate;
	};

	/**
	 * Renews an <code>EppResponseDataRenewXriService</code> object
	 *
	 * @param id the id of the <code>EppXriService</code> object renewed
	 * @param roid the ROID of the <code>EppXriService</code> object renewed
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	EppResponseDataRenewXriService( DOMString id, DOMString roid )
	{
		this->id = id;
		this->roid = roid;
		this->exDate = 0;
	};

	/**
	 * Renews an <code>EppResponseDataRenewXriService</code> object
	 *
	 * @param id   the id of the <code>EppXriService</code> object renewed
	 * @param roid   the ROID of the <code>EppXriService</code> object renewed
	 * @param exDate the expiration date of the <code>EppXriService</code>
	 *               object renewed
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	EppResponseDataRenewXriService( DOMString id, DOMString roid, time_t exDate )
	{
		this->id = id;
		this->roid = roid;
		this->exDate = exDate;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataRenewXriService() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataRenewXriService;
	};

	/**
	 * Gets the identifier of the XRI i-service object renewed
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the identifier of the XRI i-service object renewed
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Gets expiration date of the XRI i-service object renewed
	 */
	time_t getDateExpired()
	{
		return this->exDate;
	};

	/**
	 * Sets expiration date of the XRI i-service object renewed
	 */
	void setDateExpired( time_t exDate )
	{
		this->exDate = exDate;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataRenewXriService</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XRI I-Service object
	 *
	 * @param root root node for an <code>EppResponseDataRenewXriService</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataRenewXriService</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataRenewXriService * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataRenewXriService</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataRenewXriService</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATARENEWISERVICE_HPP */  /* } */
