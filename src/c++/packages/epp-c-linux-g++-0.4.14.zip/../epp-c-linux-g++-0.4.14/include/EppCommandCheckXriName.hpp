#if ! defined(EPPCOMMANDCHECKXRIINAME_HPP)    /* { */
#define       EPPCOMMANDCHECKXRIINAME_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandCheckXriName.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppCommandCheck.hpp"

#define	MAX_NUM_OF_XRIINAMES	16

/**
 * This <code>EppCommandCheckXriName</code> class implements EPP Command Check
 * entity for EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppCommandCheckXriName : public EppCommandCheck
{
private:
	ValueVectorOf<DOMString> * inames;

public:
	/**
	 * Creates an <code>EppCommandCheckXriName</code> object
	 */
	EppCommandCheckXriName()
	{
		this->inames = new ValueVectorOf<DOMString>(MAX_NUM_OF_XRIINAMES);
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandCheckXriName</code> object, given a
	 * client transaction id associated with the operation
	 */
	EppCommandCheckXriName( DOMString xid )
	{
		this->inames = new ValueVectorOf<DOMString>(MAX_NUM_OF_XRIINAMES);
		this->clTRID = xid;
	}

	/**
	 * Destructor
	 */
	~EppCommandCheckXriName()
	{
		if( this->inames != null )
		{
			delete this->inames;
			this->inames = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandCheckXriName;
	};

	/**
	 * Gets the list of the i-names of the XRI i-name objects to be checked
	 */
	ValueVectorOf<DOMString> * getIName()
	{
		return this->inames;
	};

	/**
	 * Gets the list of the i-names of the XRI i-name objects to be checked.
	 *
	 * <P><B>Note:</B> This is an alias for <code>getIName</code>
	 */
	ValueVectorOf<DOMString> * get()
	{
		return this->getIName();
	};

	/**
	 * Adds the i-name of an XRI i-name object to the list of i-names of XRI i-name
	 * objects be checked
	 */
	void addIName( DOMString iname )
	{
		this->inames->addElement(iname);
	};

	/**
	 * Adds the i-name of an XRI i-name object to the list of i-names of XRI i-name
	 * objects be checked.
	 *
	 * <P><B>Note:</B> This is an alias for <code>addIName</code>
	 */
	void add( DOMString iname )
	{
		this->addIName(iname);
	};

	/**
	 * Converts the <code>EppCommandCheckXriName</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandCheckXriName</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandCheckXriName</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Check entity for EPP XriName objects.
	 *
	 * @param root root node for an <code>EppCommandCheckXriName</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandCheckXriName</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandCheckXriName * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDCHECKXRIINAME_HPP */  /* } */
