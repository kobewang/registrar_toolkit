#if ! defined(EPPRESPONSEDATACHECKXRIINAME_HPP)    /* { */
#define       EPPRESPONSEDATACHECKXRIINAME_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataCheckXriName.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppResponseDataCheck.hpp"

/**
 * This <code>EppResponseDataCheckXriName</code> class implements EPP
 * Response Data entity for EPP Command Check of EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataCheckXriName : public EppResponseDataCheck
{
public:
	/**
	 * Checks an <code>EppResponseDataCheckXriName</code> object
	 */
	EppResponseDataCheckXriName() {};

	/**
	 * Destructor
	 */
	~EppResponseDataCheckXriName() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCheckXriName;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCheckXriName</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for checking EPP XRI I-Name objects.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCheckXriName</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCheckXriName</code> object, or null
	 *         if the node is invalid
	 */
	static EppResponseDataCheckXriName * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataCheckXriName</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCheckXriName</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATACHECKXRIINAME_HPP */  /* } */
