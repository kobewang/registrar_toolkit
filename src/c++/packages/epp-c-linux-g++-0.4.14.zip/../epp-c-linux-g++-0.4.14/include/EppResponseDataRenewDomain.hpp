#if ! defined(EPPRESPONSEDATARENEWDOMAIN_HPP)    /* { */
#define       EPPRESPONSEDATARENEWDOMAIN_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataRenewDomain.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include <time.h>
#include "EppResponseDataRenew.hpp"

/**
 * This <code>EppResponseDataRenewDomain</code> class implements EPP
 * Response Data entity for EPP Command Renew of EPP Domain objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataRenewDomain : public EppResponseDataRenew
{
private:
	DOMString name;
	time_t    exDate;

public:
	/**
	 * Renews an <code>EppResponseDataRenewDomain</code> object
	 */
	EppResponseDataRenewDomain()
	{
		this->name = null;
		this->roid = null;
		this->exDate = 0;
	};

	/**
	 * Renews an <code>EppResponseDataRenewDomain</code> object
	 *
	 * @param name the name of the <code>EppDomain</code> object renewed
	 */
	EppResponseDataRenewDomain( DOMString name )
	{
		this->name = name;
		this->roid = null;
		this->exDate = 0;
	};

	/**
	 * Renews an <code>EppResponseDataRenewDomain</code> object
	 *
	 * @param name   the name of the <code>EppDomain</code> object renewed
	 * @param exDate the expiration date of the <code>EppDomain</code>
	 *               object renewed
	 */
	EppResponseDataRenewDomain( DOMString name, time_t exDate )
	{
		this->name = name;
		this->roid = null;
		this->exDate = exDate;
	};

	/**
	 * Renews an <code>EppResponseDataRenewDomain</code> object
	 *
	 * @param name the name of the <code>EppDomain</code> object renewed
	 * @param roid the ROID of the <code>EppDomain</code> object renewed
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	EppResponseDataRenewDomain( DOMString name, DOMString roid )
	{
		this->name = name;
		this->roid = roid;
		this->exDate = 0;
	};

	/**
	 * Renews an <code>EppResponseDataRenewDomain</code> object
	 *
	 * @param name   the name of the <code>EppDomain</code> object renewed
	 * @param roid   the ROID of the <code>EppDomain</code> object renewed
	 * @param exDate the expiration date of the <code>EppDomain</code>
	 *               object renewed
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	EppResponseDataRenewDomain( DOMString name, DOMString roid, time_t exDate )
	{
		this->name = name;
		this->roid = roid;
		this->exDate = exDate;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataRenewDomain() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataRenewDomain;
	};

	/**
	 * Gets the name of the domain renewed
	 */
	DOMString getName()
	{
		return this->name;
	};

	/**
	 * Sets the name of the domain renewed
	 */
	void setName( DOMString name )
	{
		this->name = name;
	};

	/**
	 * Gets expiration date of the domain renewed
	 */
	time_t getDateExpired()
	{
		return this->exDate;
	};

	/**
	 * Sets expiration date of the domain renewed
	 */
	void setDateExpired( time_t exDate )
	{
		this->exDate = exDate;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataRenewDomain</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP Domain object
	 *
	 * @param root root node for an <code>EppResponseDataRenewDomain</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataRenewDomain</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataRenewDomain * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataRenewDomain</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataRenewDomain</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATARENEWDOMAIN_HPP */  /* } */
