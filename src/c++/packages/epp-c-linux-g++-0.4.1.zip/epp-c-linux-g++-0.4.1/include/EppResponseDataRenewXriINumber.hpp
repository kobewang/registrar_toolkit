#if ! defined(EPPRESPONSEDATARENEWINUMBER_HPP)    /* { */
#define       EPPRESPONSEDATARENEWINUMBER_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include <time.h>
#include "EppResponseDataRenew.hpp"

/**
 * This <code>EppResponseDataRenewXriINumber</code> class implements EPP
 * Response Data entity for EPP Command Renew of EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppResponseDataRenewXriINumber : public EppResponseDataRenew
{
private:
	DOMString inumber;
	time_t    exDate;

public:
	/**
	 * Creates an <code>EppResponseDataRenewXriINumber</code> object
	 *
	 * @param inumber the i-number of the XRI i-number object renewed
	 */
	EppResponseDataRenewXriINumber()
	{
		this->inumber = null;
		this->roid = null;
		this->exDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataRenewXriINumber</code> object
	 *
	 * @param inumber the i-number of the XRI i-number object renewed
	 */
	EppResponseDataRenewXriINumber( DOMString inumber )
	{
		this->inumber = inumber;
		this->roid = null;
		this->exDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataRenewXriINumber</code> object
	 *
	 * @param inumber the i-number of the XRI i-number object renewed
	 * @param exDate the expiration date of the XRI i-number
	 *               object renewed
	 */
	EppResponseDataRenewXriINumber( DOMString inumber, time_t exDate )
	{
		this->inumber = inumber;
		this->roid = null;
		this->exDate = exDate;
	};

	/**
	 * Renews an <code>EppResponseDataRenewXriINumber</code> object
	 *
	 * @param inumber the inumber of the <code>EppXriINumber</code> object renewed
	 * @param roid the ROID of the <code>EppXriINumber</code> object renewed
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	EppResponseDataRenewXriINumber( DOMString inumber, DOMString roid )
	{
		this->inumber = inumber;
		this->roid = roid;
		this->exDate = 0;
	};

	/**
	 * Renews an <code>EppResponseDataRenewXriINumber</code> object
	 *
	 * @param inumber   the inumber of the <code>EppXriINumber</code> object renewed
	 * @param roid   the ROID of the <code>EppXriINumber</code> object renewed
	 * @param exDate the expiration date of the <code>EppXriINumber</code>
	 *               object renewed
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	EppResponseDataRenewXriINumber( DOMString inumber, DOMString roid, time_t exDate )
	{
		this->inumber = inumber;
		this->roid = roid;
		this->exDate = exDate;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataRenewXriINumber() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataRenewXriINumber;
	};

	/**
	 * Gets the inumber of the XRI i-number renewed
	 */
	DOMString getINumber()
	{
		return this->inumber;
	};

	/**
	 * Sets the inumber of the XRI i-number renewed
	 */
	void setINumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Gets expiration date of the XRI i-number renewed
	 */
	time_t getDateExpired()
	{
		return this->exDate;
	};

	/**
	 * Sets expiration date of the XRI i-number renewed
	 */
	void setDateExpired( time_t exDate )
	{
		this->exDate = exDate;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataRenewXriINumber</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XRI I-Number object
	 *
	 * @param root root node for an <code>EppResponseDataRenewXriINumber</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataRenewXriINumber</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataRenewXriINumber * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataRenewXriINumber</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataRenewXriINumber</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATARENEWINUMBER_HPP */  /* } */
