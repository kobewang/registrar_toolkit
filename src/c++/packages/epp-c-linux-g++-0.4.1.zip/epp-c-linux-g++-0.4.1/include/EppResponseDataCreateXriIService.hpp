#if ! defined(EPPRESPONSEDATACREATEXRIISERVICE_HPP)    /* { */
#define       EPPRESPONSEDATACREATEXRIISERVICE_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppResponseDataCreate.hpp"
#include "util/ValueVectorOf.hpp"

/**
 * This <code>EppResponseDataCreateXriIService</code> class implements EPP
 * Response Data entity for EPP Command Create of EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppResponseDataCreateXriIService : public EppResponseDataCreate
{
private:
	DOMString                  id;
	DOMString                  type;
	ValueVectorOf<DOMString> * uri;
	time_t                     exDate;

public:
	/**
	 * Creates an <code>EppResponseDataCreateXriIService</code> object
	 */
	EppResponseDataCreateXriIService()
	{
		this->id     = null;
		this->type   = null;
		this->crDate = time(0);
		this->exDate = time(0);
		this->uri    = new ValueVectorOf<DOMString>(3);
	};

	/**
	 * Creates an <code>EppResponseDataCreateXriIService</code> object,
	 * with the current date as the creation date.
	 *
         * @param id the identifier of the EPP XRI i-service object created
	 */
	EppResponseDataCreateXriIService( DOMString id )
	{
		this->id     = id;
		this->type   = null;
		this->crDate = time(0);
		this->exDate = time(0);
		this->uri    = new ValueVectorOf<DOMString>(3);
	};

	/**
	 * Creates an <code>EppResponseDataCreateXriIService</code> object,
	 * given the identifier of the XRI i-service object, and an expiration date,
	 * with the current date as the creation date
	 *
         * @param id the identifier of the EPP XRI i-service object created
         * @param exDate  the expiration date of the XRI i-service object created
	 */
	EppResponseDataCreateXriIService( DOMString id, time_t exDate )
	{
		this->id     = id;
		this->type   = null;
		this->crDate = time(0);
		this->exDate = exDate;
		this->uri    = new ValueVectorOf<DOMString>(3);
	};

	/**
	 * Creates an <code>EppResponseDataCreateXriIService</code> object,
	 * given the identifier of the XRI i-service object, a reference id,
	 * and an expiration date,
	 * with the current date as the creation date
	 *
         * @param id      the identifier of the EPP XRI i-service object created
         * @param type    the type of the XRI i-service object created
         * @param exDate  the expiration date of the XRI i-service object created
	 */
	EppResponseDataCreateXriIService( DOMString id, DOMString type, time_t exDate )
	{
		this->id     = id;
		this->type   = type;
		this->crDate = time(0);
		this->exDate = exDate;
		this->uri    = new ValueVectorOf<DOMString>(3);
	};

	/**
	 * Creates an <code>EppResponseDataCreateXriIService</code> object,
	 * given the identifier of the XRI i-service object, a reference id,
	 * and an expiration date,
	 * with the current date as the creation date
	 *
         * @param id      the identifier of the EPP XRI i-service object created
         * @param type    the type of the XRI i-service object created
         * @param exDate  the expiration date of the XRI i-service object created
         * @param crDate  the creation date of the XRI i-service object created
	 */
	EppResponseDataCreateXriIService( DOMString id, DOMString type, time_t exDate, time_t crDate )
	{
		this->id     = id;
		this->type   = type;
		this->crDate = crDate;
		this->exDate = exDate;
		this->uri    = new ValueVectorOf<DOMString>(3);
	};

	/**
	 * Sets the identifier of the XRI i-service object
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Gets the identifier of the XRI i-service object
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Gets expiration date of the XRI i-service object created
	 */
	time_t getDateExpired()
	{
		return this->exDate;
	};

	/**
	 * Sets expiration date of the XRI i-service object created
	 */
	void setDateExpired( time_t exDate )
	{
		this->exDate = exDate;
	};

	/**
	 * Gets the type of the XRI i-service object
	 */
	DOMString getType()
	{
		return this->type;
	};

	/**
	 * Sets the type of the XRI i-service object
	 */
	void setType( DOMString type )
	{
		this->type = type;
	};

	/**
	 * Adds a URI to the list of URIs associated with the i-service object
	 */
	void addURI( DOMString uri )
	{
		this->uri->addElement(uri);
	};

	/**
	 * Gets the list of URIs associated with the i-service object
	 */
	ValueVectorOf<DOMString> * getURI()
	{
		return this->uri;
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCreateXriIService;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCreateXriIService</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XriIService object.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCreateXriIService</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCreateXriIService</code> object, or null
	 *         if the node is invalid
	 */
	static EppResponseDataCreateXriIService * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataCreateXriIService</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCreateXriIService</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATACREATEXRIISERVICE_HPP */  /* } */
