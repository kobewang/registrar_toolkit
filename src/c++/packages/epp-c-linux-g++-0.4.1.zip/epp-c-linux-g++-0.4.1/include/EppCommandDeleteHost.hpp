#if ! defined(EPPCOMMANDDELETEHOST_HPP)    /* { */
#define       EPPCOMMANDDELETEHOST_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandDelete.hpp"

/**
 * This <code>EppCommandDeleteHost</code> class implements EPP Command Delete
 * entity for EPP Host objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppCommandDeleteHost : public EppCommandDelete
{
private:
	DOMString name;

public:
	/**
	 * Creates an <code>EppCommandDeleteHost</code> object
	 */
	EppCommandDeleteHost()
	{
		this->name = null;
	};
	
	/**
	 * Creates an <code>EppCommandDeleteHost</code> object for
	 * deleting a host object based on its name
	 */
	EppCommandDeleteHost( DOMString name )
	{
		this->name = name;
	};

	/**
	 * Creates an <code>EppCommandDeleteHost</code> object for
	 * deleting a host object based on its name, given a client
	 * transaction id associated with the operation
	 */
	EppCommandDeleteHost( DOMString name, DOMString xid )
	{
		this->name = name;
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandDeleteHost() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandDeleteHost;
	};

	/**
	 * Gets the name of the host object to be deleted
	 */
	DOMString getName()
	{
		return this->name;
	};

	/**
	 * Sets the name of the host object to be deleted
	 */
	void setName( DOMString name )
	{
		this->name = name;
	};

	/**
	 * Converts the <code>EppCommandDeleteHost</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandDeleteHost</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandDeleteHost</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Delete entity for EPP host object.
	 *
	 * @param root root node for an <code>EppCommandDeleteHost</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandDeleteHost</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandDeleteHost * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDDELETEHOST_HPP */  /* } */
