#if ! defined(EPPRESPONSEDATAPENDINGDOMAIN_HPP)		/* { */
#define	      EPPRESPONSEDATAPENDINGDOMAIN_HPP		   1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppResponseDataPending.hpp"

/**
 * This <code>EppResponseDataPendingDomain</code> class implements EPP
 * Response Data entity for EPP Pending Actions of EPP Domain objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppResponseDataPendingDomain : public EppResponseDataPending
{
private:
	DOMString   name;

public:
	/**
	 * Creates an <code>EppResponseDataPendingDomain</code> object
	 *
	 * @param name the name of the <code>EppDomain</code> object associated with the pending action
	 */
	EppResponseDataPendingDomain( DOMString name )
	{
		this->name = name;
		this->paResult = false;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataPendingDomain</code> object
	 *
	 * @param name the name of the <code>EppDomain</code> object associated with the pending action
	 * @param result the boolean flag indicating if the pending action is a success or a failure
	 */
	EppResponseDataPendingDomain( DOMString name, bool result )
	{
		this->name = name;
		this->paResult = result;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = 0;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataPendingDomain() {};

	/**
	 * Gets the name of the domain object associated with the pending action
	*/
	DOMString getName()
	{
		return this->name;
	};

	/**
	 * Sets the name of the domain object associated with the pending action
	 */
	void setName( DOMString name )
	{
		this->name = name;
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataPendingDomain;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataPendingDomain</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP Domain object
	 *
	 * @param root root node for an <code>EppResponseDataPendingDomain</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataPendingDomain</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataPendingDomain * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataPendingDomain</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataPendingDomain</code> object
	 *
	 * @return an <code>Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif	/*    EPPRESPONSEDATAPENDINGDOMAIN_HPP */	/* } */
