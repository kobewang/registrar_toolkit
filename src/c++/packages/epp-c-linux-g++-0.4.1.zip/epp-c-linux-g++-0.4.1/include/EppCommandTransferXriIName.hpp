#if ! defined(EPPCOMMANDTRANSFERXRIINAME_HPP)    /* { */
#define       EPPCOMMANDTRANSFERXRIINAME_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandTransfer.hpp"
#include "EppPeriod.hpp"

/**
 * This <code>EppCommandTransferXriIName</code> class implements EPP Command
 * Transfer entity for EPP XRI IName objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppCommandTransferXriIName : public EppCommandTransfer
{
private:
	DOMString     iname;
	EppPeriod   * period;
	DOMString     trToken;
	DOMString     targetAuthId;
	EppAuthInfo * targetAuthInfo;

public:
	/**
	 * Creates an <code>EppCommandTransferXriIName</code> object
	 */
	EppCommandTransferXriIName()
	{
		this->iname = null;
		this->period = null;
		this->trToken = null;
		this->targetAuthId = null;
		this->targetAuthInfo = null;
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandTransferXriIName</code> object for
	 * transfering an XRI i-name object based on its i-name
	 */
	EppCommandTransferXriIName( DOMString iname )
	{
		this->iname = iname;
		this->period = null;
		this->trToken = null;
		this->targetAuthId = null;
		this->targetAuthInfo = null;
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandTransferXriIName</code> object for
	 * transfering an XRI i-name object based on its i-name
	 * given a client transaction id associated with operation
	 */
	EppCommandTransferXriIName( DOMString iname, DOMString xid )
	{
		this->iname = iname;
		this->period = null;
		this->trToken = null;
		this->targetAuthId = null;
		this->targetAuthInfo = null;
		this->clTRID = xid;
	};

	/**
	 * Creates an <code>EppCommandTransferXriIName</code> object for
	 * transfering an XRI i-name object based on its i-name,
	 * a client transaction id associated with operation
	 * and with a transfer token
	 */
	EppCommandTransferXriIName( DOMString iname, DOMString trToken, DOMString xid )
	{
		this->iname = iname;
		this->period = null;
		this->trToken = trToken;
		this->targetAuthId = null;
		this->targetAuthInfo = null;
		this->clTRID = xid;
	};

	/**
	 * Creates an <code>EppCommandTransferXriIName</code> object for
	 * transfering an XRI i-name object based on its i-name,
	 * and an extended expiration period
	 */
	EppCommandTransferXriIName( DOMString iname, EppPeriod period )
	{
		this->iname = iname;
		this->period = null;
		this->trToken = null;
		this->targetAuthId = null;
		this->targetAuthInfo = null;
		this->clTRID = null;
		this->setPeriod(period);
	};

	/**
	 * Creates an <code>EppCommandTransferXriIName</code> object for
	 * transfering an XRI i-name object based on its i-name,
	 * an extended expiration period,
	 * and with a transfer token
	 */
	EppCommandTransferXriIName( DOMString iname, EppPeriod period, DOMString trToken )
	{
		this->iname = iname;
		this->period = null;
		this->trToken = trToken;
		this->targetAuthId = null;
		this->targetAuthInfo = null;
		this->clTRID = null;
		this->setPeriod(period);
	};

	/**
	 * Creates an <code>EppCommandTransferXriIName</code> object for
	 * transfering an XRI i-name object based on its i-name,
	 * an extended expiration period,
	 * a client transaction id associated with operation
	 * and with a transfer token
	 */
	EppCommandTransferXriIName( DOMString iname, EppPeriod period, DOMString trToken, DOMString xid )
	{
		this->iname = iname;
		this->period = null;
		this->trToken = trToken;
		this->targetAuthId = null;
		this->targetAuthInfo = null;
		this->clTRID = xid;
		this->setPeriod(period);
	};

	/**
	 * Destructor
	 */
	~EppCommandTransferXriIName()
	{
		if( this->period != null )
		{
			delete this->period;
			this->period = null;
		}
		if( this->targetAuthInfo != null )
		{
			delete this->targetAuthInfo;
			this->targetAuthInfo = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandTransferXriIName;
	};

	/**
	 * Gets the i-name of the XRI i-name object to be transferred
	 */
	DOMString getIName()
	{
		return this->iname;
	};

	/**
	 * Sets the i-name of the XRI i-name object to be transferred
	 */
	void setIName( DOMString iname )
	{
		this->iname = iname;
	};

	/**
	 * Gets the transfer token for the transfer operation
	 */
	DOMString getTransferToken()
	{
		return this->trToken;
	};

	/**
	 * Sets the transfer token for the transfer operation
	 */
	void setTransferToken( DOMString trToken )
	{
		this->trToken = trToken;
	};

	/**
	 * Gets the target XRI authority identifier
	 */
	DOMString getTargetAuthorityId()
	{
		return this->targetAuthId;
	};

	/**
	 * Sets the target XRI authority identifier
	 */
	void setTargetAuthorityId( DOMString authId )
	{
		this->targetAuthId = authId;
	};

	/**
	 * Sets the target XRI authority authInfo
	 */
	EppAuthInfo * getTargetAuthInfo()
	{
		return this->targetAuthInfo;
	};

	/**
	 * Sets the target XRI authority authInfo
	 */
	void setTargetAuthInfo( EppAuthInfo authInfo )
	{
		if( this->targetAuthInfo == null )
		{
			this->targetAuthInfo = new EppAuthInfo();
		}
		*(this->targetAuthInfo) = authInfo;
	};

	/**
	 * Sets the identifier and authInfo of the target XRI authority involved in 
	 * XRI authority transfer operation
	 */
	void setTarget( DOMString authId, EppAuthInfo authInfo )
	{
		this->setTargetAuthorityId(authId);
		this->setTargetAuthInfo(authInfo);
	};

	/**
	 * Gets the extended registration period of the XRI I-Name object to be transferred
	 */
	EppPeriod * getPeriod()
	{
		return this->period;
	};

	/**
	 * Sets the extended registration period of the XRI I-Name object to be transferred
	 */
	void setPeriod( EppPeriod& period )
	{
		if( this->period == null )
		{
			this->period = new EppPeriod();
		}
		*(this->period) = period;
	};

	/**
	 * Converts the <code>EppCommandTransferXriIName</code> object into
	 * an XML element for an <code>EppPollable</code> object
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandTransferXriIName</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXMLPoll( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts the <code>EppCommandTransferXriIName</code> object into
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandTransferXriIName</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an
	 * <code>EppCommandTransferXriIName</code> object. The caller of this
	 * method must make sure that the root node is of an EPP Command
	 * Transfer entity for EPP XriIName object.
	 *
	 * @param root root node for an <code>EppCommandTransferXriIName</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandTransferXriIName</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandTransferXriIName * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDTRANSFERXRIINAME_HPP */  /* } */
