#if ! defined(EPPRESPONSEDATAPENDINGXRIINAME_HPP)	/* { */
#define	      EPPRESPONSEDATAPENDINGXRIINAME_HPP		   1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppResponseDataPending.hpp"

/**
 * This <code>EppResponseDataPendingXriIName</code> class implements EPP
 * Response Data entity for EPP Pending Actions of EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppResponseDataPendingXriIName : public EppResponseDataPending
{
private:
	DOMString   iname;

public:
	/**
	 * Creates an <code>EppResponseDataPendingXriIName</code> object
	 *
	 * @param iname the i-name of the <code>EppXriIName</code> object associated with the pending action
	 */
	EppResponseDataPendingXriIName( DOMString iname )
	{
		this->iname = iname;
		this->paResult = false;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataPendingXriIName</code> object
	 *
	 * @param iname the i-name of the <code>EppXriIName</code> object associated with the pending action
	 * @param result the boolean flag indicating if the pending action is a success or a failure
	 */
	EppResponseDataPendingXriIName( DOMString iname, bool result )
	{
		this->iname = iname;
		this->paResult = result;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = null;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataPendingXriIName() {};

	/**
	 * Gets the i-name of the XRI i-name object associated with the pending action
	*/
	DOMString getIName()
	{
		return this->iname;
	};

	/**
	 * Sets the i-name of the XRI i-name object associated with the pending action
	 */
	void setIName( DOMString iname )
	{
		this->iname = iname;
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataPendingXriIName;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataPendingXriIName</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XRI I-Name object
	 *
	 * @param root root node for an <code>EppResponseDataPendingXriIName</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataPendingXriIName</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataPendingXriIName * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataPendingXriIName</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataPendingXriIName</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif	/*    EPPRESPONSEDATAPENDINGXRIINAME_HPP */	/* } */
