#if ! defined(EPPCOMMANDCHECK_HPP)    /* { */
#define       EPPCOMMANDCHECK_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommand.hpp"
#include <util/ValueVectorOf.hpp>

/**
 * This <code>EppCommandCheck</code> class implements EPP Command Check
 * entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppCommandCheck : public EppCommand
{
public:
	/**
	 * Gets a list of EPP Object ids to be checked
	 */
	virtual ValueVectorOf<DOMString> * get() = 0;

	/**
	 * Adds an object id to the list of ids of objects to be checked
	 */
	virtual void add( DOMString objectId ) = 0;

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandCheck;
	};

	/**
	 * Converts an XML element into an <code>EppCommandCheck</code> object.
	 * The caller of this method must make sure that the root node is of an
	 * EPP Command Check entity.
	 *
	 * @param root root node for an <code>EppCommandCheck</code> object
	 *             in XML format
	 *
	 * @return an <code>EppCommandCheck</code> object, or null if the node
	 *         is invalid
	 */
	static EppCommandCheck * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("check"));
	};
};

#endif     /* EPPCOMMANDCHECK_HPP */  /* } */
