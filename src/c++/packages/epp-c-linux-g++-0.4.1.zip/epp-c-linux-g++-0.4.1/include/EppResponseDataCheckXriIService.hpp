#if ! defined(EPPRESPONSEDATACHECKXRIISERVICE_HPP)    /* { */
#define       EPPRESPONSEDATACHECKXRIISERVICE_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppResponseDataCheck.hpp"

/**
 * This <code>EppResponseDataCheckXriIService</code> class implements EPP
 * Response Data entity for EPP Command Check of EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppResponseDataCheckXriIService : public EppResponseDataCheck
{
public:
	/**
	 * Checks an <code>EppResponseDataCheckXriIService</code> object
	 */
	EppResponseDataCheckXriIService() {};

	/**
	 * Destructor
	 */
	~EppResponseDataCheckXriIService() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCheckXriIService;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCheckXriIService</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for checking EPP XRI I-Service objects.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCheckXriIService</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCheckXriIService</code> object, or null
	 *         if the node is invalid
	 */
	static EppResponseDataCheckXriIService * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataCheckXriIService</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCheckXriIService</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATACHECKXRIISERVICE_HPP */  /* } */
