#if ! defined(EPPOBJECT_HPP)    /* { */
#define       EPPOBJECT_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include <time.h>
#include "EppEntity.hpp"
#include "EppStatus.hpp"
#include "EppAuthInfo.hpp"
#include <util/ValueVectorOf.hpp>

#define	MAX_NUM_OF_STATUS	10

class EppCommandCreate;

/**
 * This <code>EppObject</code> class is the base class for all objects
 * registered in the registry via the EPP Protocol.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2002/05/08 15:35:28 $
 */
class EPP_EXPORT EppObject : public EppEntity
{
protected:
	/**
	 * The ROID of the EPP Object in the registry
	 */
	DOMString                  roid;
	/**
	 * The status list associated with the EPP Object in the registry
	 */
	ValueVectorOf<EppStatus> * status;
	/**
	 * The id of the client that is sponsering the EPP Object
	 */
	DOMString                  clID;
	/**
	 * The id of the client that created the EPP Object initially
	 */
	DOMString                  crID;
	/**
	 * The timestamp when the EPP Object was created initially
	 */
	time_t                     crDate;
	/**
	 * The id of the client that updated the EPP Object most recently
	 */
	DOMString                  upID;        // optional
	/**
	 * The timestamp when the EPP Object was updated most recently
	 */
	time_t                     upDate;      // optional
	/**
	 * The timestamp when the EPP Object is set to be expired
	 *
	 * @note this field only applies to EPP objects with registration period.
	 */
	time_t                     exDate;      // optional, only valid for EppDomain/EppSvcsub
	/**
	 * The timestamp when the EPP Object was transferred most recently
	 *
	 * @note this field does not apply to EPP Host objects
	 */
	time_t                     trDate;      // optional
	/**
	 * The authorization information associated with the EPP object
	 *
	 * @note this field does not apply to EPP Host objects
	 */
	EppAuthInfo              * authInfo;    // not valid for EppHost

	/**
	 * Converts shared <code>EppObject</code> components from XML
	 *
	 * @param node the node for a shared <code>EppObject</code> component
	 * @param name the name of the node for the shared
	 *             <code>EppObject</code> component
	 */
	void fromXMLCommon( const DOM_Node& node, const DOMString name );

	/**
	 * Converts shared <code>EppObject</code> components into XML
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param body the XML <code>DOM_Element</code> to be attached
	 */
	void toXMLCommon( DOM_Document& doc, DOM_Element& body );

	/**
	 * Frees shared <code>EppObject</code> components
	 */
	void freeCommon();

public:
	/**
	 * Type for EPP Contact objcet
	 */
	static const int CONTACT;
	/**
	 * Type for EPP Domain object
	 */
	static const int DOMAIN;
	/**
	 * Type for EPP Host object
	 */
	static const int HOST;
	/**
	 * Type for EPP Svcsub object
	 */
	static const int SVCSUB;
	/**
	 * Type for EPP XRI Authority object
	 */
	static const int XRI_AUTHORITY;
	/**
	 * Type for EPP XRI I-Number object
	 */
	static const int XRI_INUMBER;
	/**
	 * Type for EPP XRI I-Name object
	 */
	static const int XRI_INAME;
	/**
	 * Type for EPP XRI I-Service object
	 */
	static const int XRI_ISERVICE;

	/**
	 * Constructor
	 */
	EppObject();

	/**
	 * Destructor
	 */
	virtual ~EppObject() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppObject;
	};

	/**
	 * Gets ROID of the <code>EppObject</code>
	 */
	DOMString getRoid()
	{
		return this->roid;
	};

	/**
	 * Sets ROID of the <code>EppObject</code>
	 */
	void setRoid( DOMString roid )
	{
		this->roid = roid;
	};

	/**
	 * Gets the id of the registrar client sponsering the
	 * <code>EppObject</code>.
	 */
	DOMString getClientId()
	{
		return this->clID;
	};

	/**
	 * Sets the id of the registrar client sponsering the
	 * <code>EppObject</code>
	 */
	void setClientId( DOMString clientId )
	{
		this->clID = clientId;
	};

	/**
	 * Gets the id of the registrar client creating the
	 * <code>EppObject</code>
	 * initially
	 */
	DOMString getClientIdCreated()
	{
		return this->crID;
	};

	/**
	 * Sets the id of the registrar client creating the
	 * <code>EppObject</code> initially
	 */
	void setClientIdCreated( DOMString clientId )
	{
		this->crID = clientId;
	};

	/**
	 * Gets the date of the <code>EppObject</code> created
	 */
	time_t getDateCreated()
	{
		return this->crDate;
	};

	/**
	 * Sets the date of the <code>EppObject</code> created
	 */
	void setDateCreated( time_t cal )
	{
		this->crDate = cal;
	};

	/**
	 * Gets the id of the registrar client updating the
	 * <code>EppObject</code> most recently
	 */
	DOMString getClientIdUpdated()
	{
		return this->upID;
	};

	/**
	 * Sets the id of the registrar client updating the
	 * <code>EppObject</code> most recently
	 */
	void setClientIdUpdated( DOMString clientId )
	{
		this->upID = clientId;
	};

	/**
	 * Gets the date of the <code>EppObject</code> updated
	 */
	time_t getDateUpdated()
	{
		return this->upDate;
	};

	/**
	 * Sets the date of the <code>EppObject</code> updated
	 */
	void setDateUpdated( time_t cal )
	{
		this->upDate = cal;
	};

	/**
	 * Gets the date of the <code>EppObject</code> expiration date
	 *
	 * @note Currently, only an EPP domain object has an expiration date
	 */
	time_t getDateExpired()
	{
		return this->exDate;
	};

	/**
	 * Sets the expiration date of the <code>EppObject</code>
	 *
	 * @note Currently, only an EPP domain object has an expiration date
	 */
	void setDateExpired( time_t cal )
	{
		this->exDate = cal;
	};

	/**
	 * Gets the date of the <code>EppObject</code> transferred
	 */
	time_t getDateTransferred()
	{
		return this->trDate;
	};

	/**
	 * Sets the date of the <code>EppObject</code> transferred
	 */
	void setDateTransferred( time_t cal )
	{
		this->trDate = cal;
	};

	/**
	 * Gets the authorization info of the <code>EppObject</code>
	 */
	EppAuthInfo * getAuthInfo()
	{
		return this->authInfo;
	};

	/**
	 * Sets the authorization info of the <code>EppObject</code>
	 */
	void setAuthInfo( EppAuthInfo authInfo )
	{
		if( this->authInfo == null )
		{
			this->authInfo = new EppAuthInfo();
		}
		*this->authInfo = authInfo;
	};

	/**
	 * Gets the status of the <code>EppObject</code>
	 */
	ValueVectorOf<EppStatus> * getStatus()
	{
		return this->status;
	};

	/**
	 * Adds a status to the <code>EppObject</code>
	 */
	void addStatus( EppStatus status )
	{
		this->status->addElement(status);
	};

	/**
	 * Converts an XML element into an <code>EppObject</code> object
	 *
	 * @param root root node for an <code>EppObject</code> object
	 * in XML format
	 */
	static EppObject * fromXML( const DOM_Node& root );

	/**
	 * Creates an <code>EppCommandCreate</code> object for creating
	 * an EPP Object in the registry.
	 *
	 * @param object the EPP Object to be created in the registry
	 * @param xid the client transaction id associated with the operation
	 */
	static EppCommandCreate create( EppObject * object, DOMString xid );
};

#endif     /* EPPOBJECT_HPP */  /* } */
