#if ! defined(EPPCOMMANDDELETEXRIINAME_HPP)    /* { */
#define       EPPCOMMANDDELETEXRIINAME_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandDelete.hpp"

/**
 * This <code>EppCommandDelete</code> class implements EPP Command Delete
 * entity for EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppCommandDeleteXriIName : public EppCommandDelete
{
private:
	DOMString iname;

public:
	/**
	 * Creates an <code>EppCommandDeleteXriIName</code> object for
	 * deleting an XRI i-name based on its i-name
	 */
	EppCommandDeleteXriIName( DOMString iname )
	{
		this->iname = iname;
	};

	/**
	 * Creates an <code>EppCommandDeleteXriIName</code> object for
	 * deleting an XRI i-name based on its i-name, given a client
	 * transaction id associated with the operation
	 */
	EppCommandDeleteXriIName( DOMString iname, DOMString xid )
	{
		this->iname = iname;
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandDeleteXriIName() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandDeleteXriIName;
	};

	/**
	 * Gets the i-name of the XRI i-name object to be deleted
	 */
	DOMString getIName()
	{
		return this->iname;
	};

	/**
	 * Sets the i-name of the XRI i-name object to be deleted
	 */
	void setIName( DOMString iname )
	{
		this->iname = iname;
	};

	/**
	 * Converts the <code>EppCommandDeleteXriIName</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandDeleteXriIName</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandDeleteXriIName</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Delete entity for EPP XriIName object.
	 *
	 * @param root root node for an <code>EppCommandDeleteXriIName</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandDeleteXriIName</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandDeleteXriIName * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDDELETEXRIINAME_HPP */  /* } */
