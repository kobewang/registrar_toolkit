#if ! defined(EPPCOMMANDCHECKXRIINUMBER_HPP)    /* { */
#define       EPPCOMMANDCHECKXRIINUMBER_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandCheck.hpp"

#define	MAX_NUM_OF_XRIINUMBERS	16

/**
 * This <code>EppCommandCheckXriINumber</code> class implements EPP Command Check
 * entity for EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppCommandCheckXriINumber : public EppCommandCheck
{
private:
	ValueVectorOf<DOMString> * inumbers;

public:
	/**
	 * Creates an <code>EppCommandCheckXriINumber</code> object
	 */
	EppCommandCheckXriINumber()
	{
		this->inumbers = new ValueVectorOf<DOMString>(MAX_NUM_OF_XRIINUMBERS);
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandCheckXriINumber</code> object, given a
	 * client transaction id associated with the operation
	 */
	EppCommandCheckXriINumber( DOMString xid )
	{
		this->inumbers = new ValueVectorOf<DOMString>(MAX_NUM_OF_XRIINUMBERS);
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandCheckXriINumber()
	{
		if( this->inumbers != null )
		{
			delete this->inumbers;
			this->inumbers = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandCheckXriINumber;
	};

	/**
	 * Gets the list of the i-numbers of the XRI i-number objects to be checked
	 */
	ValueVectorOf<DOMString> * getINumber()
	{
		return this->inumbers;
	};

	/**
	 * Gets the list of the i-numbers of the XRI i-number objects to be checked.
	 *
	 * <P><B>Note:</B> This is an alias for <code>getINumber</code>
	 */
	ValueVectorOf<DOMString> * get()
	{
		return this->getINumber();
	};

	/**
	 * Adds the i-number of an XRI i-number object to the list of i-numbers of XRI i-number
	 * objects be checked
	 */
	void addINumber( DOMString inumber )
	{
		this->inumbers->addElement(inumber);
	};

	/**
	 * Adds the i-number of an XRI i-number object to the list of i-numbers of XRI i-number
	 * objects be checked.
	 *
	 * <P><B>Note:</B> This is an alias for <code>addINumber</code>
	 */
	void add( DOMString inumber )
	{
		this->addINumber(inumber);
	};

	/**
	 * Converts the <code>EppCommandCheckXriINumber</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandCheckXriINumber</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandCheckXriINumber</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Check entity for EPP XriINumber objects.
	 *
	 * @param root root node for an <code>EppCommandCheckXriINumber</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandCheckXriINumber</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandCheckXriINumber * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDCHECKXRIINUMBER_HPP */  /* } */
