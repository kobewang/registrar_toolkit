#if ! defined(EPPXRIURI_HPP)    /* { */
#define       EPPXRIURI_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppEntity.hpp"

/**
 * This <code>EppXriURI</code> class defines URI
 * information associated with XRI authority objects.  It
 * implements XRI uriType defined
 * in the XRI authority schema file.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppXriURI : public EppEntity
{
protected:
	static const unsigned short int DEFAULT_PRIORITY;

private:
        DOMString          uri;
        unsigned short int priority;

public:
	/**
	 * Creates an <code>EppXriURI</code> object
	 */
	EppXriURI()
	{
		this->uri = null;
		this->priority = DEFAULT_PRIORITY;
	};

	/**
	 * Creates an <code>EppXriURI</code> object with a URI
	 */
	EppXriURI( DOMString uri )
	{
		this->uri = uri;
		this->priority = DEFAULT_PRIORITY;
	}

	/**
	 * Creates an <code>EppXriURI</code> object with a URI and a priority value
	 */
	EppXriURI( DOMString uri, unsigned short int priority )
	{
		this->uri = uri;
		this->priority = priority;
	};

	/**
	 * Destructor
	 */
	~EppXriURI() {};

	/**
	 * Gets the URI
	 */
	DOMString getURI()
	{
		return this->uri;
	};

	/**
	 * Sets the URI
	 */
	void setURI( DOMString uri )
	{
		this->uri = uri;
	};

	/**
	 * Gets the priority value for this URI
	 */
	unsigned short int getPriority()
	{
		return this->priority;
	};

	/**
	 * Sets the priority value for this URI
	 */
	void setPriority( unsigned short int priority )
	{
		this->priority = priority;
	};

	/**
         * Converts the <code>EppXriURI</code> object into an XML element
         *
         * @param doc the XML <code>DOM_Document</code> object
         * @param tag the tag/element name for the <code>EppXriURI</code> object
         *
         * @return an <code>DOM_Element</code> object
         */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppXriURI</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP XRI uriAddType or uriInfType.
	 *
	 * @param root root node for an <code>EppXriURI</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriURI</code> object, or null if the node is
	 *         invalid
	 */
	static EppXriURI * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("uri"));
	};
};

#endif     /* EPPXRIURI_HPP */  /* } */
