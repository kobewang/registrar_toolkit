#if ! defined(EPPCOMMANDINFOCONTACT_HPP)    /* { */
#define       EPPCOMMANDINFOCONTACT_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandInfo.hpp"
#include "EppAuthInfo.hpp"

/**
 * This <code>EppCommandInfo</code> class implements EPP Command Info
 * entity for EPP Contact objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppCommandInfoContact : public EppCommandInfo
{
private:
	DOMString id;
	EppAuthInfo * authInfo;

public:
	/**
	 * Creates an <code>EppCommandInfoContact</code> object
	 */
	EppCommandInfoContact()
	{
		this->id = null;
		this->authInfo = null;
	};

	/**
	 * Creates an <code>EppCommandInfoContact</code> object for
	 * querying a contact object based on its id
	 */
	EppCommandInfoContact( DOMString id )
	{
		this->id = id;
		this->authInfo = null;
	};

	/**
	 * Creates an <code>EppCommandInfoContact</code> object for
	 * querying a contact object based on its id, given a client
	 * transaction id assoicated with the operation
	 */
	EppCommandInfoContact( DOMString id, DOMString xid )
	{
		this->id = id;
		this->clTRID = xid;
		this->authInfo = null;
	};

	/**
	 * Destructor
	 */
	~EppCommandInfoContact()
	{
		if( this->authInfo != null )
		{
			delete this->authInfo;
			this->authInfo = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandInfoContact;
	};

	/**
	 * Gets the id of the contact object to be queried
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the id of the contact object to be queried
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Gets the authorization info for querying the contact object
	 */
	EppAuthInfo * getAuthInfo()
	{
		return this->authInfo;
	};

	/**
	 * Sets the authorization info for querying the contact object
	 */
	void setAuthInfo( EppAuthInfo& authInfo )
	{
		if( this->authInfo == null )
		{
			this->authInfo = new EppAuthInfo();
		}
		*(this->authInfo) = authInfo;
	};

	/**
	 * Converts the <code>EppCommandInfoContact</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandInfoContact</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandInfoContact</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Info entity for EPP contact object.
	 *
	 * @param root root node for an <code>EppCommandInfoContact</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandInfoContact</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandInfoContact * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDINFOCONTACT_HPP */  /* } */
