#if ! defined(EPPCOMMANDINFOXRIINAME_HPP)    /* { */
#define       EPPCOMMANDINFOXRIINAME_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandInfo.hpp"

/**
 * This <code>EppCommandInfo</code> class implements EPP Command Info
 * entity for EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppCommandInfoXriIName : public EppCommandInfo
{
private:
	DOMString iname;

public:
	/**
	 * Creates an <code>EppCommandInfoXriIName</code> object for
	 * querying an XRI i-name based on its i-name
	 */
	EppCommandInfoXriIName( DOMString iname )
	{
		this->iname = iname;
	};

	/**
	 * Creates an <code>EppCommandInfoXriIName</code> object for
	 * querying an XRI i-name based on its i-name, given a client
	 * transaction id associated with the operation
	 */
	EppCommandInfoXriIName( DOMString iname, DOMString xid )
	{
		this->iname = iname;
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandInfoXriIName() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandInfoXriIName;
	};

	/**
	 * Gets the i-name of the XRI i-name object to be queried
	 */
	DOMString getIName()
	{
		return this->iname;
	};

	/**
	 * Sets the i-name of the XRI i-name object to be queried
	 */
	void setIName( DOMString iname )
	{
		this->iname = iname;
	};

	/**
	 * Converts the <code>EppCommandInfoXriIName</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandInfoXriIName</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandInfoXriIName</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Info entity for EPP XriIName object.
	 *
	 * @param root root node for an <code>EppCommandInfoXriIName</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandInfoXriIName</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandInfoXriIName * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDINFOXRIINAME_HPP */  /* } */
