#if ! defined(EPPCOMMANDINFOXRIISERVICE_HPP)    /* { */
#define       EPPCOMMANDINFOXRIISERVICE_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandInfo.hpp"

/**
 * This <code>EppCommandInfo</code> class implements EPP Command Info
 * entity for EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppCommandInfoXriIService : public EppCommandInfo
{
private:
	DOMString id;

public:
	/**
	 * Creates an <code>EppCommandInfoXriIService</code> object for
	 * querying an XRI i-service based on its identifier
	 */
	EppCommandInfoXriIService( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Creates an <code>EppCommandInfoXriIService</code> object for
	 * querying an XRI i-service based on its identifier, given a client
	 * transaction id associated with the operation
	 */
	EppCommandInfoXriIService( DOMString id, DOMString xid )
	{
		this->id = id;
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandInfoXriIService() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandInfoXriIService;
	};

	/**
	 * Gets the identifier of the XRI i-service object to be queried
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the identifier of the XRI i-service object to be queried
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Converts the <code>EppCommandInfoXriIService</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandInfoXriIService</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandInfoXriIService</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Info entity for EPP XriIService object.
	 *
	 * @param root root node for an <code>EppCommandInfoXriIService</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandInfoXriIService</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandInfoXriIService * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDINFOXRIISERVICE_HPP */  /* } */
