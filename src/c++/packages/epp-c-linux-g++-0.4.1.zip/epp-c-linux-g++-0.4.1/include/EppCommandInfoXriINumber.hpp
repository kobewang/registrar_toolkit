#if ! defined(EPPCOMMANDINFOXRIINUMBER_HPP)    /* { */
#define       EPPCOMMANDINFOXRIINUMBER_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommandInfo.hpp"

/**
 * This <code>EppCommandInfo</code> class implements EPP Command Info
 * entity for EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppCommandInfoXriINumber : public EppCommandInfo
{
private:
	DOMString inumber;

public:
	/**
	 * Creates an <code>EppCommandInfoXriINumber</code> object for
	 * querying an XRI i-number based on its i-number
	 */
	EppCommandInfoXriINumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Creates an <code>EppCommandInfoXriINumber</code> object for
	 * querying an XRI i-number based on its i-number, given a client
	 * transaction id associated with the operation
	 */
	EppCommandInfoXriINumber( DOMString inumber, DOMString xid )
	{
		this->inumber = inumber;
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandInfoXriINumber() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandInfoXriINumber;
	};

	/**
	 * Gets the i-number of the XRI i-number object to be queried
	 */
	DOMString getINumber()
	{
		return this->inumber;
	};

	/**
	 * Sets the i-number of the XRI i-number object to be queried
	 */
	void setINumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Converts the <code>EppCommandInfoXriINumber</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandInfoXriINumber</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandInfoXriINumber</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Info entity for EPP XriINumber object.
	 *
	 * @param root root node for an <code>EppCommandInfoXriINumber</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandInfoXriINumber</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandInfoXriINumber * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDINFOXRIINUMBER_HPP */  /* } */
