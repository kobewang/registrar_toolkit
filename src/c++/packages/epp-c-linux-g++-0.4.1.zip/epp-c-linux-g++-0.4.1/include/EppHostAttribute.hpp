#if ! defined(EPPHOSTATTRIBUTE_HPP)	/* { */
#define	      EPPHOSTATTRIBUTE_HPP	   1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppEntity.hpp"
#include "EppIpAddress.hpp"
#include "util/ValueVectorOf.hpp"

#define	MAX_NUM_OF_IP_ADDRESSES		13

/**
 * This <code>EppHostAttribute</code> class implements EPP hostAttrType entity
 * that is used by <code>EppDomain</code> objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppHostAttribute : public EppEntity
{
private:
	DOMString		      hostname;
	ValueVectorOf<EppIpAddress> * hostaddr;

public:
	/**
	 * Creates an <code>EppHostAttribute</code> object with a host name
	 */
	EppHostAttribute( DOMString hostname )
	{
		this->hostname = hostname;
		this->hostaddr = null;
	};

	/**
	 * Creates an <code>EppHostAttribute</code> object with a host name
	 * and a list of <code>EppIpAddress</code> objects
	 */
	EppHostAttribute( DOMString hostname, ValueVectorOf<EppIpAddress> * address )
	{
		this->hostname = hostname;
		this->hostaddr = address;
	};

	/**
	 * Destructor
	 */
	~EppHostAttribute()
	{
		if( this->hostaddr != null )
		{
			delete this->hostaddr;
		}
		this->hostaddr = null;
	};

	/**
	 * Gets the host name
	 */
	DOMString getHostName()
	{
		return this->hostname;
	};

	/**
	 * Sets the host name
	 */
	void setHostName( DOMString hostname )
	{
		this->hostname = hostname;
	};

	/**
	 * Gets the list of ip addresses associated with the host name
	 */
	ValueVectorOf<EppIpAddress> * getIpAddress()
	{
		return this->hostaddr;
	}

	/**
	 * Sets the list of ip addresses associated with the host name
	 */
	void setIpAddress( ValueVectorOf<EppIpAddress> * address )
	{
		if( this->hostaddr != null )
		{
			delete this->hostaddr;
		}
		this->hostaddr = address;
	}

	/**
	 * Adds an ip address to the list of ip addresses associated
	 * with the host name
	 */
	void addIpAddress( EppIpAddress address )
	{
		if( this->hostaddr == null )
		{
			this->hostaddr = new ValueVectorOf<EppIpAddress>(MAX_NUM_OF_IP_ADDRESSES);
		}
		this->hostaddr->addElement(address);
	};

	/**
 	 * Converts the <code>EppHostAttribute</code> object into an XML element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the <code>EppHostAttribute</code>
	 *            object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppHostAttribute</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP Contact Type type.
	 *
	 * @param root root node for an <code>EppHostAttribute</code> object
	 *             in XML format
	 *
	 * @return an <code>EppHostAttribute</code> object, or null if the node
	 *         is invalid
	 */
	static EppHostAttribute * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("hostAttr"));
	};
};

#endif	/*    EPPHOSTATTRIBUTE_HPP */	/* } */
