#if ! defined(EPPXRIINAME_HPP)    /* { */
#define       EPPXRIINAME_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppEntity.hpp"
#include "EppObject.hpp"
#include "EppPeriod.hpp"

/**
 * This <code>EppXriIName</code> class implements EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision$ $Date$
 */
class EPP_EXPORT EppXriIName : public EppObject
{
private:
	DOMString   iname;
	DOMString   authId;
	EppPeriod * period; 

public:
	/**
	 * I-Name status - clientDeleteProhibited
	 */
	static const char * STATUS_CLIENT_DELETE_PROHIBITED;
	/**
	 * I-Name status - clientHold
	 */
	static const char * STATUS_CLIENT_HOLD;
	/**
	 * I-Name status - clientRenewProhibited
	 */
	static const char * STATUS_CLIENT_RENEW_PROHIBITED;
	/**
	 * I-Name status - clientTransferProhibited
	 */
	static const char * STATUS_CLIENT_TRANSFER_PROHIBITED;
	/**
	 * I-Name status - clientUpdateProhibited
	 */
	static const char * STATUS_CLIENT_UPDATE_PROHIBITED;
	/**
	 * I-Name status - ok
	 */
	static const char * STATUS_OK;
	/**
	 * I-Name status - pendingCreate
	 */
	static const char * STATUS_PENDING_CREATE;
	/**
	 * I-Name status - pendingDelete
	 */
	static const char * STATUS_PENDING_DELETE;
	/**
	 * I-Name status - pendingTransfer
	 */
	static const char * STATUS_PENDING_TRANSFER;
	/**
	 * I-Name status - pendingUpdate
	 */
	static const char * STATUS_PENDING_UPDATE;
	/**
	 * I-Name status - serverDeleteProhibited
	 */
	static const char * STATUS_SERVER_DELETE_PROHIBITED;
	/**
	 * I-Name status - serverHold
	 */
	static const char * STATUS_SERVER_HOLD;
	/**
	 * I-Name status - serverRenewProhibited
	 */
	static const char * STATUS_SERVER_RENEW_PROHIBITED;
	/**
	 * I-Name status - serverTransferProhibited
	 */
	static const char * STATUS_SERVER_TRANSFER_PROHIBITED;
	/**
	 * I-Name status - serverUpdateProhibited
	 */
	static const char * STATUS_SERVER_UPDATE_PROHIBITED;

	/**
	 * Creates an <code>EppXriIName</code> object
	 */
	EppXriIName()
	{
		this->iname      = null;
		this->authId     = null;
		this->period     = null;
	};

	/**
	 * Creates an <code>EppXriIName</code> object with an XRI i-name
	 */
	EppXriIName( DOMString iname )
	{
		this->iname      = iname;
		this->authId     = null;
		this->period     = null;
	};

	/**
	 * Destructor
	 */
	~EppXriIName()
	{
		EppObject::freeCommon();
		if( this->period != null )
		{
			delete this->period;
			this->period = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
        virtual int getEntityType()
	{
		return EppEntity::TYPE_EppXriIName;
	};

	/**
	 * Gets the i-name
	 */
	DOMString getIName()
	{
		return this->iname;
	};

	/**
	 * Sets the i-name
	 */
	void setIName( DOMString iname )
	{
		this->iname = iname;
	};

	/**
	 * Sets the identifier of the superorindate XRI authority object,
	 * and authInfo associated with the authority, if any
	 */
	void setAuthority( DOMString authId, EppAuthInfo authInfo )
	{
		this->authId   = authId;
		this->setAuthInfo(authInfo);
	};

	/**
	 * Gets the identifier of the superordinate XRI authority object
	 */
	DOMString getAuthorityId()
	{
		return this->authId;
	};

	/**
	 * Sets the identifier of the superordinate XRI authority object
	 */
	void setAuthorityId( DOMString authId )
	{
		this->authId = authId;
	};

	/**
	 * Gets registration period for the i-name
	 */
	EppPeriod * getPeriod()
	{
		return this->period;
	};

	/**
	 * Sets registration period for the i-name
	 */
	void setPeriod( EppPeriod period )
	{
		if( this->period == null )
		{
			this->period = new EppPeriod();
		}
		*(this->period) = period;
	};

	/**
	 * Converts the <code>EppXriIName</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the <code>EppXriIName</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppXriIName</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP I-Name type.
	 *
	 * @param root root node for an <code>EppXriIName</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriIName</code> object, or null if the node
	 *         is invalid
	 */
	static EppXriIName * fromXML( const DOM_Node& root );

#if 0
	/**
	 * Creates an <code>EppCommandDeleteXriIName</code> object for
	 * deleting an EPP XRI I-Name object from the registry.
	 *
	 * @param iname the i-name of the XRI i-name object to be deleted
	 * @param xid     the client transaction id associated with the operation
	 */
	public static EppCommandDeleteXriIName delete( String iname, String xid )
	{
		return new EppCommandDeleteXriIName(iname, xid);
	}

	/**
	 * Creates an <code>EppCommandInfoXriIName</code> object for
	 * querying the details of an EPP XRI I-Name object
	 *
	 * @param iname the i-name of the XRI i-name object to be queried
	 * @param xid     the client transaction id associated with the operation
	 */
	public static EppCommandInfoXriIName info( String iname, String xid )
	{
		return new EppCommandInfoXriIName(iname, xid);
	}

	/**
	 * Creates an <code>EppCommandCheckXriIName</code> object for
	 * checking the existance of EPP XRI I-Name objects in the registry.
	 * Identifiers of EPP XRI I-Name objects can be added via the
	 * <code>add</code> or <code>addIName</code> methods.
	 *
	 * @param xid  the client transaction id associated with the operation
	 */
	public static EppCommandCheckXriIName check( String xid )
	{
		return new EppCommandCheckXriIName(xid);
	}

	/**
	 * Creates an <code>EppCommandRenewXriIName</code> object for
	 * renewing the registration of an EPP XRI I-Name object in the registry.
	 *
	 * @param iname    the iname of the XRI i-name object to be renewed
	 * @param curExpDate the current expiration date of the svcsub object
	 * @param period     the new registration period of the svcsub object,
	 *                   or null if using the value specified by the
	 *                   registry
	 * @param xid        the client transaction id associated with the
	 *                   operation
	 */
	public static EppCommandRenewXriIName renew( String iname, Calendar curExpDate, EppPeriod period, String xid )
	{
		return new EppCommandRenewXriIName(iname, curExpDate, period, xid);
	}

	/**
	 * Creates an <code>EppCommandTransferXriIName</code> object for
	 * transfering an EPP XRI I-Name object in the registry. The operation
	 * type, transfer token, target authority and authorization information associated
	 * with the operation should be specified via <code>setOperation</code>,
	 * <code>setTransferToken</code>, <code>setTarget</code>, and <code>setAuthInfo</code> method.
	 *
	 * @param iname the identifier of the XRI authority object to be transferred
	 * @param xid   the client transaction id associated with the operation
	 */
	public static EppCommandTransferXriIName transfer( String iname, String xid )
	{
		return new EppCommandTransferXriIName(iname, xid);
	}

	/**
	 * Creates an <code>EppCommandUpdateXriIName</code> object for
	 * updating an EPP I-Name object in the registry. The actual update
	 * information should be specified via the various methods defined
	 * for the <code>EppCommandUpdateXriIName</code> object.
	 *
	 * @param iname the i-name of the XRI i-name object to be updated
	 * @param xid   the client transaction id associated with the operation
	 */
	public static EppCommandUpdateXriIName update( String iname, String xid )
	{
		return new EppCommandUpdateXriIName(iname, xid);
	}
#endif

	DOMString toString()
	{
		return EppEntity::toString(DOMString("xriINA"));
	};
};

#endif     /* EPPXRIINAME_HPP */  /* } */
