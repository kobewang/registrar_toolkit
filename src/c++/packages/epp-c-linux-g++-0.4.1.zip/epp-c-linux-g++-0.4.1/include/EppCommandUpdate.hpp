#if ! defined(EPPCOMMANDUPDATE_HPP)    /* { */
#define       EPPCOMMANDUPDATE_HPP        1
/*
 * Copyright (c) 2001-2004 NeuLevel, Inc. All Rights Reserved.
 *
 * $Id$
 */
#include "EppCommand.hpp"
#include "EppStatus.hpp"

#define	MAX_NUM_OF_UPDATE_STATUS	10

/**
 * This <code>EppCommandUpdate</code> class implements EPP Command Update
 * entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2001/11/05 20:20:36 $
 */
class EPP_EXPORT EppCommandUpdate : public EppCommand
{
protected:
	ValueVectorOf<EppStatus> * statusAdded;
	ValueVectorOf<EppStatus> * statusRemoved;

	/**
	 * Converts a list of EPP Status objects into XML
	 *
	 * @param doc  the XML <code>DOM_Element</code> object
	 * @param body the XML <code>DOM_Element</code> object to which the list
	 *             of EPP Status objects is appended
	 * @param list the list of EPP Status objects to be converted
	 */
	void statusToXML( DOM_Document& doc, DOM_Element& body, ValueVectorOf<EppStatus> * list );

	/**
	 * Converts a list of EPP Status objects from XML
	 *
	 * @param root the XML <code>Node</code> object containing the list
	 *             of EPP Status objects
	 * @param statusList the list of EPP Status objects to be stored
	 */
	void statusFromXML( const DOM_Node& root, ValueVectorOf<EppStatus> * statusList );

public:
	/**
	 * Creates an <code>EppCommandUpdate</code> object
	 */
	EppCommandUpdate()
	{
		this->statusAdded   = new ValueVectorOf<EppStatus>(MAX_NUM_OF_UPDATE_STATUS);
		this->statusRemoved = new ValueVectorOf<EppStatus>(MAX_NUM_OF_UPDATE_STATUS);
	};

	/**
	 * Destructor
	 */
	virtual ~EppCommandUpdate()
	{
		if( this->statusAdded != null )
		{
			delete this->statusAdded;
			this->statusAdded = null;
		}
		if( this->statusRemoved != null )
		{
			delete this->statusRemoved;
			this->statusRemoved = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandUpdate;
	};

	/**
	 * Gets the list of new status to be added for the EPP object
	 */
	ValueVectorOf<EppStatus> * getAddedStatus()
	{
		return this->statusAdded;
	};

	/*
	 * Adds a new status for the EPP object
	 */
	void addStatus( DOMString status )
	{
		EppStatus s(status);
		this->addStatus(s);
	};

	/*
	 * Adds a new status for the EPP object
	 */
	void addStatus( EppStatus& status )
	{
		this->statusAdded->addElement(status);
	};

	/**
	 * Gets the list of old status to be removed for the EPP object
	 */
	ValueVectorOf<EppStatus> * getRemovedStatus()
	{
		return this->statusRemoved;
	};

	/*
	 * Removes an old status for the EPP object
	 */
	void removeStatus( DOMString status )
	{
		EppStatus s(status);
		this->removeStatus(s);
	};

	/*
	 * Removes an old status for the EPP object
	 */
	void removeStatus( EppStatus& status )
	{
		this->statusRemoved->addElement(status);
	};

	/**
	 * Converts an XML element into an <code>EppCommandUpdate</code>
	 * object. The caller of this method must make sure that the root
	 * node is of an EPP Command Update entity.
	 *
	 * @param root root node for an <code>EppCommandUpdate</code> object
	 *             in XML format
	 *
	 * @return an <code>EppCommandUpdate</code> object, or null if the
	 *         node is invalid
	 */
	static EppCommandUpdate * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("update"));
	};
};

#endif     /* EPPCOMMANDUPDATE_HPP */  /* } */
