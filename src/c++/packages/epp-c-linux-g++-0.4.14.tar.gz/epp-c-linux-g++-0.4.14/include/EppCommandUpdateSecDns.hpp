#if ! defined(EPPCOMMANDUPDATESECDNS_HPP)    /* { */
#define       EPPCOMMANDUPDATESECDNS_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandUpdateSecDns.hpp,v 1.7 2013/03/06 20:45:08 nseshadr Exp $
 */
#include "EppExtension.hpp"
#include "EppSecDnsKeyData.hpp"
#include "EppSecDnsDsData.hpp"
#include <util/ValueVectorOf.hpp>

#define MAX_NUM_OF_DS_DATA	4

/**
 * This <code>EppCommandSecDns</code> class implements EPP CommandSecDns entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.7 $ $Date: 2013/03/06 20:45:08 $
 */
class EPP_EXPORT EppCommandUpdateSecDns : public EppExtension
{
private:
	ValueVectorOf<EppSecDnsDsData> * addDsDataList;
	ValueVectorOf<EppSecDnsDsData> * chgDsDataList;
	ValueVectorOf<EppSecDnsDsData> * remKeyTagList;
	ValueVectorOf<EppSecDnsKeyData> * addKeyDataList;
	ValueVectorOf<EppSecDnsKeyData> * remKeyDataList;

	bool				 urgent;
	int maxSigLife;
	bool removeAllDS;
	bool keyDataPresent;

	static const int		 OP_ADD;
	static const int		 OP_CHG;
	static const int		 OP_REM;

	/**
	 * Converts an XML element into an <code>EppSecDnsDsData</code> object list,
	 * or <code>key tag</code> list, The caller of this method must make sure that
	 * the root node contains a list of EPP SECDNS dsDataType objects
	 *
	 * @param root root node for a <code>add</code>, <code>chg</code> or <code>rem</code> tag
	 *        op flag indicating one of the operations: OP_ADD, OP_CHG, OP_REM.
	 *
	 * @return none
	 */
	void fromXML( const DOM_Node& root, const int op );

       /**
         * Converts a list of object into an XML format
         *
         * @param doc the XML <code>Document</code> object
         * @param root the element for attaching the child element, such as, "add", "chg", or "rem"
         * @param tag the tag/element name for the object, "add", "chg", or "rem"
         * @param dsDataList the list of <code>EppSecDnsDsData</code> objects
         * @param keyTagList the list of <code>Kay Tag</code> integers
         *
         * @return true if a child element is added
         */
	bool toXML( DOM_Document& doc, DOM_Element& root, const DOMString& tag, ValueVectorOf<EppSecDnsDsData> * dsDataList, ValueVectorOf<int> * keyTagList );

public:
	/**
	 * Creates an <code>EppCommandSecDns</code> object
	 */
	EppCommandUpdateSecDns():addDsDataList(null),chgDsDataList(null),remKeyTagList(null),
					addKeyDataList(null),remKeyDataList(null),urgent(false), maxSigLife(-1),
					removeAllDS(false), keyDataPresent(false)
	{
		this->addDsDataList = new ValueVectorOf<EppSecDnsDsData>(MAX_NUM_OF_DS_DATA);
#if defined(EPPDNSSEC_COMPT)
		this->chgDsDataList = new ValueVectorOf<EppSecDnsDsData>(MAX_NUM_OF_DS_DATA);
#endif
		this->remKeyTagList = new ValueVectorOf<EppSecDnsDsData>(MAX_NUM_OF_DS_DATA);
		this->addKeyDataList = new ValueVectorOf<EppSecDnsKeyData>(MAX_NUM_OF_DS_DATA);
		this->remKeyDataList = new ValueVectorOf<EppSecDnsKeyData>(MAX_NUM_OF_DS_DATA);

		this->urgent        = false;
		this->maxSigLife		= -1;
		this->removeAllDS		= false;
		this->keyDataPresent	= false;
	};

	/**
	 * Destructor
	 */
	~EppCommandUpdateSecDns()
	{
		if( this->addDsDataList != null )
		{
			delete this->addDsDataList;
			this->addDsDataList = null;
		}
#if defined(EPPDNSSEC_COMPT)
		if( this->chgDsDataList != null )
		{
			delete this->chgDsDataList;
			this->chgDsDataList = null;
		}
#endif
		if( this->remKeyTagList != null )
		{
			delete this->remKeyTagList;
			this->remKeyTagList = null;
		}

		if( this->addKeyDataList != null )
		{
			delete this->addKeyDataList;
			this->addKeyDataList = null;
		}

		if( this->remKeyDataList != null )
		{
			delete this->remKeyDataList;
			this->remKeyDataList = null;
		}

	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandUpdateSecDns;
	};

	/**
	 * Gets the urgent update boolean flag
	 */
	bool getUrgentFlag()
	{
		return this->urgent;
	};

	/**
	 * Sets the urgent update boolean flag
	 */
	void setUrgentFlag( bool urgent )
	{
		this->urgent = urgent;
	};

	bool isRemovelAllDS() {
		return this->removeAllDS;
	}

	void isRemoveAllDS( bool flag ) {
		this->removeAllDS = flag;
	}

	int getMaxSigLife() {
		return this->maxSigLife;
	}

	void setMaxSigLife( int secs ) {
		this->maxSigLife = secs;
	}
	bool isKeyDataPresent() {
		return this->keyDataPresent;
	}

	/**
	 * Adds DS Data to the list to be attached to a domain name
	 */
	void add( EppSecDnsDsData& dsData )
	{
                this->addDsDataList->addElement(dsData);
	};

	void add( EppSecDnsKeyData& keyData )
	{
                this->addKeyDataList->addElement(keyData);
	}
	/**
	 * Gets the list of DS data to be attached to a domain name
	 */
	ValueVectorOf<EppSecDnsDsData> * getDsDataAdded()
	{
        	return this->addDsDataList;
	};

	ValueVectorOf<EppSecDnsKeyData> * getKeyDataAdded()
	{
        	return this->addKeyDataList;
	};
#if defined(EPPDNSSEC_COMPT)
	/**
	 * Changes DS Data to the list to be attached to a domain name
	 */
	void change( EppSecDnsDsData& dsData )
	{
                this->chgDsDataList->addElement(dsData);

	};

	/**
	 * Gets the list of DS data to be changed to a domain name
	 */
	ValueVectorOf<EppSecDnsDsData> * getDsDataChanged()
	{
        	return this->chgDsDataList;
	};
#endif

	void remove( EppSecDnsDsData& dsData )
	{
		this->remKeyTagList->addElement(dsData);
	};
	void remove( EppSecDnsKeyData& keyData )
	{
		this->remKeyDataList->addElement(keyData);
	}
	/**
	 * Gets the list of key tags of DS data to be detached from a domain name
	 */
	ValueVectorOf<EppSecDnsDsData>* getKeyTagRemoved()
	{
		return this->remKeyTagList;
	};
	ValueVectorOf<EppSecDnsKeyData>* getKeyDataRemoved()
	{
		return this->remKeyDataList;
	}


	/**
	 * Converts an XML element into an <code>EppCommandUpdateSecDns</code> object.
	 * The caller of this method must make sure that the root node is of
	 * EPP SECDNS updateType
	 *
	 * @param root root node for an <code>EppCommandUpdateSecDns</code> object in XML format
	 *
	 * @return an <code>EppCommandUpdateSecDns</code> object, or null if the node is invalid
	 */
	static EppCommandUpdateSecDns * fromXML( const DOM_Node& root );

	/**
	 * Converts the <code>EppCommandUpdateSecDns</code> object into an XML element
	 *
	 * @param doc the XML <code>Document</code> object
	 * @param tag the tag/element name for the <code>EppCommandUpdateSecDns</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("update"));
	};
};

#endif     /* EPPCOMMANDUPDATESECDNS_HPP */  /* } */
