#if ! defined(EPPEPPCOURTDATA_HPP)    /* { */
#define       EPPEPPCOURTDATA_HPP 1
#include <time.h>
#include "EppEntity.hpp"
#include "EppMarkData.hpp"

class EPP_EXPORT EppCourtData : public EppMarkData {
	public:
		EppCourtData();
		EppCourtData(const EppCourtData&);
		virtual ~EppCourtData();
		EppCourtData& operator=(const EppCourtData&);

		void refNum(const DOMString&);
		DOMString refNum(void);

		void proDate(const DOMString &);
		time_t proDate(void);

		void countryCode(const DOMString& _cc);
		DOMString countryCode(void);

		void addRegion(const DOMString& _r);
		ValueVectorOf<DOMString> region(void);

		void courtName(const DOMString&);
		DOMString courtName(void);

		virtual DOM_Element toXML(DOM_Document &doc, const DOMString &tag);
		static EppCourtData* fromXML( const DOM_Node& root );
		virtual DOMString toString();

	private:
		DOMString _refNum; /*registration number of TM*/ 
		time_t _proDate; /*optional*/ 
		DOMString _cc;
		ValueVectorOf<DOMString> _region;
		DOMString _courtName;
};
#endif
