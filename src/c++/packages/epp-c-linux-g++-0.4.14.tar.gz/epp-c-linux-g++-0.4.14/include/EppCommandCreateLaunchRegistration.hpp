#if ! defined(EPPCOMMANDCREATELAUNCHREGISTRATION_HPP)    /* { */
#define       EPPCOMMANDCREATELAUNCHREGISTRATION_HPP 1
#include "EppExtension.hpp"
#include "EppSignedMarkData.hpp"
#include "EppLaunchPhase.hpp"
#include <util/ValueVectorOf.hpp>
#include "EppEncodedSignedMarkData.hpp"

class EPP_EXPORT EppCommandCreateLaunchRegistration : public EppExtension {
	public:
		EppCommandCreateLaunchRegistration();
		EppCommandCreateLaunchRegistration(const EppCommandCreateLaunchRegistration&);
		EppCommandCreateLaunchRegistration& operator=(const EppCommandCreateLaunchRegistration&);
		virtual ~EppCommandCreateLaunchRegistration();
		void phase(const EppLaunchPhase &_p);
		EppLaunchPhase phase(void);
		void signedMark(const EppSignedMarkData&);
		EppSignedMarkData signedMark(void);
		void type(const DOMString &);
		DOMString type(void);
		static EppCommandCreateLaunchRegistration* fromXML( const DOM_Node& root );
		DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
		virtual DOMString toString();
		virtual int getEntityType();
		void encodedSignedMark(const EppEncodedSignedMarkData&);
		EppEncodedSignedMarkData encodedSignedMark(void);
		DOMString noticeID();
		void noticeID(const DOMString &);
		DOMString notAfter();
		void notAfter(const DOMString &);
		DOMString acceptedDate();
		void acceptedDate(const DOMString &);
	private:
		EppLaunchPhase _phase;
		DOMString _type;
		EppSignedMarkData _signedMark;
		EppEncodedSignedMarkData _encSignedMark;
		DOMString _noticeID;
		DOMString _notAfter;
		DOMString _acceptedDate;
};

#endif
