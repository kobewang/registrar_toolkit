#if ! defined(EPPCOMMANDPOLL_HPP)    /* { */
#define       EPPCOMMANDPOLL_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandPoll.hpp,v 1.2 2006/03/01 01:35:37 wtan Exp $
 */
#include "EppCommand.hpp"

/**
 * This <code>EppCommandPoll</code> class implements EPP Command Poll
 * entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:37 $
 */
class EPP_EXPORT EppCommandPoll : public EppCommand
{
private:
	DOMString op;
	DOMString msgID;

public:
	/**
	 * Poll operation type for polling existing messages (default)
	 */
	static const char * OPTYPE_REQ;
	/**
	 * Poll operation type for acknowledging the receiption of a message
	 */
	static const char * OPTYPE_ACK;

	/**
	 * Creates an <code>EppCommandPoll</code> object, with default operation
	 * type as "req"
	 */
	EppCommandPoll();

	/**
	 * Creates an <code>EppCommandPoll</code> object, with default operation
	 * type as "req", given a client transaction id associated with
	 * operation
	 */
	EppCommandPoll( DOMString xid );
	
	/**
	 * Creates an <code>EppCommandPoll</code> object, given the operation
	 * type and the message id.
	 *
	 * @note the operation type is either "req" for request, or "ack" for
	 *       acknowledgement
	 */
	EppCommandPoll( DOMString operation, DOMString messageId );

	/**
	 * Creates an <code>EppCommandPoll</code> object, given the operation
	 * type and the message id and a client transaction id associated with
	 * operation
	 *
	 * @note the operation type is either "req" for request, or "ack" for
	 *       acknowledgement
	 */
	EppCommandPoll( DOMString operation, DOMString messageId, DOMString xid );

	/**
	 * Destructor
	 */
	~EppCommandPoll() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandPoll;
	};

	/**
	 * Gets the poll operation type
	 */
	DOMString getOperation()
	{
		return this->op;
	};

	/**
	 * Sets the poll operation type, either "req" or "ack"
	 */
	void setOperation( DOMString operation )
	{
		this->op = operation;
	};

	/**
	 * Gets the message id related to the poll command
	 */
	DOMString getMessageId()
	{
		return this->msgID;
	};

	/**
	 * Sets the message id related to the poll command
	 */
	void setMessageId( DOMString messageId )
	{
		this->msgID = messageId;
	};

	/**
	 * Converts the <code>EppCommandPoll</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the <code>EppCommandPoll</code>
	 *            object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandPoll</code> object.
	 * The caller of this method must make sure that the root node is of an
	 * EPP Command Create entity.
	 *
	 * @param root root node for an <code>EppCommandPoll</code> object
	 *             in XML format
	 *
	 * @return an <code>EppCommandPoll</code> object, or null if the node
	 *         is invalid
	 */
	static EppCommandPoll * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("poll"));
	};
};

#endif     /* EPPCOMMANDPOLL_HPP */  /* } */
