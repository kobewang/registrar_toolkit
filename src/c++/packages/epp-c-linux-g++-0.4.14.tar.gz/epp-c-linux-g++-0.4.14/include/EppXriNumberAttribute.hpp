#if ! defined(EPPXRIINUMBERATTRIBUTE_HPP)    /* { */
#define       EPPXRIINUMBERATTRIBUTE_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppXriNumberAttribute.hpp,v 1.3 2008/04/24 21:31:59 wtan Exp $
 */
#include "EppEntity.hpp"

/**
 * This <code>EppXriNumberAttribute</code> class defines i-numbers
 * information associated with XRI authority objects.  It
 * implements XRI inumberType defined
 * in the XRI authority schema file.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.3 $ $Date: 2008/04/24 21:31:59 $
 */
class EPP_EXPORT EppXriNumberAttribute : public EppEntity
{
private:
	DOMString          inumber;

public:
	/**
	 * Creates an <code>EppXriNumberAttribute</code> object
	 */
	EppXriNumberAttribute()
	{
		this->inumber  = null;
	};

	/**
	 * Creates an <code>EppXriNumberAttribute</code> object with an identifier
	 */
	EppXriNumberAttribute( DOMString inumber )
	{
		this->inumber  = inumber;
	};

	/**
	 * Destructor
	 */
	~EppXriNumberAttribute() {} ;

	/**
	 * Gets the i-number
	 */
	DOMString getINumber()
	{
		return this->inumber;
	};

	/**
	 * Sets the i-number
	 */
	void setINumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
         * Converts the <code>EppXriNumberAttribute</code> object into an XML element
         *
         * @param doc the XML <code>DOM_Document</code> object
         * @param tag the tag/element name for the <code>EppXriNumberAttribute</code> object
         *
         * @return an <code>DOM_Element</code> object
         */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppXriNumberAttribute</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP XRI xriAU:inumberType.
	 *
	 * @param root root node for an <code>EppXriNumberAttribute</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriNumberAttribute</code> object, or null if the node is
	 *         invalid
	 */
	static EppXriNumberAttribute * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("inumber"));
	};
};

#endif     /* EPPXRIINUMBERATTRIBUTE_HPP */  /* } */
