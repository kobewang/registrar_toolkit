#if ! defined(EPPRESPONSEDATACHECKXRIAUTHORITY_HPP)    /* { */
#define       EPPRESPONSEDATACHECKXRIAUTHORITY_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataCheckXriAuthority.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppResponseDataCheck.hpp"

/**
 * This <code>EppResponseDataCheckXriAuthority</code> class implements EPP
 * Response Data entity for EPP Command Check of EPP XRI Authority objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataCheckXriAuthority : public EppResponseDataCheck
{
public:
	/**
	 * Checks an <code>EppResponseDataCheckXriAuthority</code> object
	 */
	EppResponseDataCheckXriAuthority() {};

	/**
	 * Destructor
	 */
	~EppResponseDataCheckXriAuthority() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCheckXriAuthority;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCheckXriAuthority</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for checking EPP XRI Authority objects.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCheckXriAuthority</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCheckXriAuthority</code> object, or null
	 *         if the node is invalid
	 */
	static EppResponseDataCheckXriAuthority * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataCheckXriAuthority</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCheckXriAuthority</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATACHECKXRIAUTHORITY_HPP */  /* } */
