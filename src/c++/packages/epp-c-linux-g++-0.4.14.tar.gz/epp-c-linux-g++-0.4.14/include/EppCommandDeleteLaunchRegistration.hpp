#if ! defined(EPPCOMMANDDELETELAUNCHREGISTRATION_HPP)    /* { */
#define       EPPCOMMANDDELETELAUNCHREGISTRATION_HPP 1
#include "EppExtension.hpp"
#include <util/ValueVectorOf.hpp>
#include "EppLaunchPhase.hpp"

class EPP_EXPORT EppCommandDeleteLaunchRegistration : public EppExtension {
	public:
		EppCommandDeleteLaunchRegistration();
		EppCommandDeleteLaunchRegistration(const EppCommandDeleteLaunchRegistration&);
		EppCommandDeleteLaunchRegistration& operator=(const EppCommandDeleteLaunchRegistration&);
		virtual ~EppCommandDeleteLaunchRegistration();
		void phase(const EppLaunchPhase &_p);
                EppLaunchPhase phase(void);
		void applicationID(const DOMString &_id);
		DOMString applicationID(void);
		static EppCommandDeleteLaunchRegistration* fromXML( const DOM_Node& root );
		DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
		virtual DOMString toString();
		virtual int getEntityType();
	private:
		EppLaunchPhase _phase;
		DOMString _appId;
};

#endif
