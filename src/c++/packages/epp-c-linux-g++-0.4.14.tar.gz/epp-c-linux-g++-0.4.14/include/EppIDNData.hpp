#if ! defined(EPPIDNDATA_HPP)    /* { */
#define       EPPIDNDATA_HPP 1
#include "EppExtension.hpp"
#include "EppEntity.hpp"

class EPP_EXPORT EppIDNData : public EppExtension {

public:
	EppIDNData();
	EppIDNData(const EppIDNData&);
	EppIDNData& operator=(const EppIDNData&);
	virtual ~EppIDNData();

	void table(const DOMString&);
	DOMString table(void);

	void uname(const DOMString&);
	DOMString uname(void);

	virtual DOM_Element toXML(DOM_Document &doc, const DOMString &tag);
	virtual DOMString toString();
	static EppIDNData * fromXML( const DOM_Node& root );
	virtual int getEntityType();

private:
	DOMString _table , _uname;

};
#endif /* } */
