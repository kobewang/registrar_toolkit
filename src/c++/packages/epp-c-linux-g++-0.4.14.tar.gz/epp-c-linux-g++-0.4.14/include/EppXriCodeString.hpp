#ifndef EPPXRICODESTRING_HPP
#define EPPXRICODESTRING_HPP
#include "EppEntity.hpp"
#include "EppUtil.hpp"
#include "EppObject.hpp"
#include "EppPeriod.hpp"
#include "EppXriResolutionPattern.hpp"
#include "EppAuthInfo.hpp"
#include "EppXriCodeStringExt.hpp"
#include "EppStatus.hpp"

class EPP_EXPORT EppXriCodeString: public EppObject {
	public:
		EppXriCodeString():
											parentIname(""), codeString(""), ROID(""),
											authId(""), UsedRUnits(0), totalRUnits(0), usedMcap(0), totalMcap(0),
											rStartDate(0), rEndDate(0),
											period(null),authInfo(null), sUsedRUnits(false) , sTotalRUnits(false) , sUsedMcap(false) , sTotalMcap(false), CSExt(null) {
			this->rPattern = new ValueVectorOf<EppXriResolutionPattern>(3);
		}

		virtual ~EppXriCodeString() {
			if( this->period != null ) {
				delete this->period;
				this->period = null;
			}
			if( this->authInfo != null ) {
				delete this->authInfo;
				this->authInfo = null;
			}
			if( this->rPattern != null ) {
				delete this->rPattern;
				this->rPattern = null;
			}
			if( this->CSExt != null ) {
				delete this->CSExt;
				this->CSExt = null;
			}
		}
		virtual int getEntityType() {
			return EppEntity::TYPE_EppXriCodeString;
		}
		DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
		static EppXriCodeString* fromXML( const DOM_Node& root );
		DOMString toString() {
			return  EppEntity::toString(DOMString("codeString"));
		}
		void setParentIName(DOMString iname){
			this->parentIname = iname;
		}
		void setCodeString(DOMString cs){
			this->codeString = cs;
		}
		void setRoid(DOMString roid){
			this->ROID = roid;
		}
		void setAuthId(DOMString auth_id){
			this->authId = auth_id;
		}
		void setUsedRUnits(unsigned long ur){
			sUsedRUnits = true;
			this->UsedRUnits = ur;
		}
		void setTotalRUnits(unsigned long tr){
			sTotalRUnits = true;
			this->totalRUnits = tr;
		}
		bool isSetTotalRUnits()
		{
			return sTotalRUnits;
		}
		bool isSetTotalMCap()
		{
			return sTotalMcap;
		}
		void setUsedMCap(unsigned long um){
			sUsedMcap = true;
			this->usedMcap = um;
		}
		void setTotalMCap(unsigned long tm){
			sTotalMcap = true;
			this->totalMcap = tm;
		}
		void setResStartDate(time_t rsd){
			this->rStartDate = rsd;
		}
		void setResEndDate(time_t esd){
			this->rEndDate = esd;
		}
		void addResPattern(EppXriResolutionPattern pt){
			this->rPattern->addElement(pt);
		}
		void setPeriod(EppPeriod p){
			if( this->period != null ) {
				delete this->period;
				this->period = null;
			}
			this->period = new EppPeriod(p);
		}
		void setAuthInfo(EppAuthInfo au){
			if( this->authInfo != null ) {
				delete this->authInfo;
				this->authInfo = null;
			}
			this->authInfo = new EppAuthInfo(au);
		}
		void addValueAddedService(EppXriCodeStringExt & ext) {
			if( this->CSExt != null ) {
				delete this->CSExt;
				this->CSExt = null;
			}
			this->CSExt = new EppXriCodeStringExt(ext);
		}

		DOMString getParentIName(){
			return this->parentIname;
		}
		DOMString getCodeString(){
			return this->codeString;
		}
		DOMString getRoid(){
			return this->ROID;
		}
		DOMString getAuthId(){
			return this->authId;
		}
		unsigned long getUsedRUnits() {
			return this->UsedRUnits;
		}
		unsigned long getTotalRUnits(){
			return this->totalRUnits;
		}
		unsigned long getUsedMCap(){
			return this->usedMcap;
		}
		unsigned long getTotalMCap(){
			return this->totalMcap;
		}
		time_t getResStartDate(){
			return this->rStartDate;
		}
		time_t getResEndDate(){
			return this->rEndDate;
		}
		ValueVectorOf<EppXriResolutionPattern>* getResPattern(){
			return this->rPattern;
		}
		EppPeriod* getPeriod(){
			return this->period;
		}
		EppAuthInfo* getAuthInfo(){
			return this->authInfo;
		}
		EppXriCodeStringExt* getValueAddedService(){
			return this->CSExt;
		}

	private:
		DOMString																parentIname;
		DOMString																codeString;
		DOMString																ROID;
		DOMString																authId;
		unsigned long														UsedRUnits;
		unsigned long														totalRUnits;
		unsigned long														usedMcap;
		unsigned long														totalMcap;
		bool 																		sUsedRUnits , sTotalRUnits , sUsedMcap , sTotalMcap;
		time_t																rStartDate;
		time_t																rEndDate;
		ValueVectorOf<EppXriResolutionPattern>	*rPattern;
		EppPeriod																*period;
		EppAuthInfo															*authInfo;
		EppXriCodeStringExt											*CSExt;
};
#endif
