#if ! defined(EPPRESPONSEDATARENEWINAME_HPP)    /* { */
#define       EPPRESPONSEDATARENEWINAME_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataRenewXriName.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include <time.h>
#include "EppResponseDataRenew.hpp"

/**
 * This <code>EppResponseDataRenewXriName</code> class implements EPP
 * Response Data entity for EPP Command Renew of EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataRenewXriName : public EppResponseDataRenew
{
private:
	DOMString iname;
	time_t    exDate;

public:
	/**
	 * Creates an <code>EppResponseDataRenewXriName</code> object
	 *
	 * @param iname the i-name of the XRI i-name object renewed
	 */
	EppResponseDataRenewXriName()
	{
		this->iname = null;
		this->roid = null;
		this->exDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataRenewXriName</code> object
	 *
	 * @param iname the i-name of the XRI i-name object renewed
	 */
	EppResponseDataRenewXriName( DOMString iname )
	{
		this->iname = iname;
		this->roid = null;
		this->exDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataRenewXriName</code> object
	 *
	 * @param iname the i-name of the XRI i-name object renewed
	 * @param exDate the expiration date of the XRI i-name
	 *               object renewed
	 */
	EppResponseDataRenewXriName( DOMString iname, time_t exDate )
	{
		this->iname = iname;
		this->roid = null;
		this->exDate = exDate;
	};

	/**
	 * Renews an <code>EppResponseDataRenewXriName</code> object
	 *
	 * @param iname the iname of the <code>EppXriName</code> object renewed
	 * @param roid the ROID of the <code>EppXriName</code> object renewed
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	EppResponseDataRenewXriName( DOMString iname, DOMString roid )
	{
		this->iname = iname;
		this->roid = roid;
		this->exDate = 0;
	};

	/**
	 * Renews an <code>EppResponseDataRenewXriName</code> object
	 *
	 * @param iname   the iname of the <code>EppXriName</code> object renewed
	 * @param roid   the ROID of the <code>EppXriName</code> object renewed
	 * @param exDate the expiration date of the <code>EppXriName</code>
	 *               object renewed
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	EppResponseDataRenewXriName( DOMString iname, DOMString roid, time_t exDate )
	{
		this->iname = iname;
		this->roid = roid;
		this->exDate = exDate;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataRenewXriName() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataRenewXriName;
	};

	/**
	 * Gets the iname of the XRI i-name renewed
	 */
	DOMString getIName()
	{
		return this->iname;
	};

	/**
	 * Sets the iname of the XRI i-name renewed
	 */
	void setIName( DOMString iname )
	{
		this->iname = iname;
	};

	/**
	 * Gets expiration date of the XRI i-name renewed
	 */
	time_t getDateExpired()
	{
		return this->exDate;
	};

	/**
	 * Sets expiration date of the XRI i-name renewed
	 */
	void setDateExpired( time_t exDate )
	{
		this->exDate = exDate;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataRenewXriName</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XRI I-Name object
	 *
	 * @param root root node for an <code>EppResponseDataRenewXriName</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataRenewXriName</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataRenewXriName * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataRenewXriName</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataRenewXriName</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATARENEWINAME_HPP */  /* } */
