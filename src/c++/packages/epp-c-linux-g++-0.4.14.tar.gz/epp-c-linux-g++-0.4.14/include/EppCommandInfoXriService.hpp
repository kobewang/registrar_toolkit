#if ! defined(EPPCOMMANDINFOXRIISERVICE_HPP)    /* { */
#define       EPPCOMMANDINFOXRIISERVICE_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandInfoXriService.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppCommandInfo.hpp"

/**
 * This <code>EppCommandInfo</code> class implements EPP Command Info
 * entity for EPP XRI I-Service objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppCommandInfoXriService : public EppCommandInfo
{
private:
	DOMString id;

public:
	/**
	 * Creates an <code>EppCommandInfoXriService</code> object for
	 * querying an XRI i-service based on its identifier
	 */
	EppCommandInfoXriService( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Creates an <code>EppCommandInfoXriService</code> object for
	 * querying an XRI i-service based on its identifier, given a client
	 * transaction id associated with the operation
	 */
	EppCommandInfoXriService( DOMString id, DOMString xid )
	{
		this->id = id;
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandInfoXriService() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandInfoXriService;
	};

	/**
	 * Gets the identifier of the XRI i-service object to be queried
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the identifier of the XRI i-service object to be queried
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Converts the <code>EppCommandInfoXriService</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandInfoXriService</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandInfoXriService</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Info entity for EPP XriService object.
	 *
	 * @param root root node for an <code>EppCommandInfoXriService</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandInfoXriService</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandInfoXriService * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDINFOXRIISERVICE_HPP */  /* } */
