#if ! defined(EPPXRICONTACTDATA_HPP)    /* { */
#define       EPPXRICONTACTDATA_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppXriContactData.hpp,v 1.1 2009/11/23 14:35:10 nseshadr Exp $
 */
#include "EppEntity.hpp"

enum xriContactType {
	negContact					= -1,
	billingContact,
	adminContact,
	techContact,
	invalidContact			= 3
};


class EPP_EXPORT EppXriContactData : public EppEntity {
	public:
		EppXriContactData() {
			this->contactHandle = null;
			this->contactType = negContact;
		}
		~EppXriContactData() {
			this->contactHandle = null;
			this->contactType = negContact;
		}
		void setContactHandle(DOMString input) {
			this->contactHandle = input;
		}
		void setContactType(short input) {
			this->contactType = (xriContactType)input;
		}
		void setContactType(DOMString type) {
			xriContactType conType= negContact;
			if( type.equals("billing") ) {
				conType = billingContact;
			} else if( type.equals("admin") ) {
				conType = adminContact;
			} else if( type.equals("tech") ) {
				conType = techContact;
			}
			this->contactType = conType;
		}
		DOMString getContactHandle(void) {
			return this->contactHandle;
		}
		xriContactType getContactType(void) {
			return this->contactType;
		}
		bool isValidType(short t) {
			if( t < billingContact || t > techContact )
				return false;
			return true;
		}
		DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
		static EppXriContactData * fromXML( const DOM_Node& root );
		
		DOMString toString() {
			return  EppEntity::toString(DOMString("contactId"));
		}
	private:
		DOMString contactHandle;
		xriContactType contactType;
};

#endif     /* EPPXRICONTACTDATA_HPP */  /* } */
