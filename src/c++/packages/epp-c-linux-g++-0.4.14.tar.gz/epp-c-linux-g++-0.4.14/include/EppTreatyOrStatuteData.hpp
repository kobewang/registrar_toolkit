#if ! defined(EPPTREATYORSTATUTEDATA_HPP)    /* { */
#define       EPPTREATYORSTATUTEDATA_HPP 1
#include <time.h>
#include "EppEntity.hpp"
#include "EppMarkData.hpp"
#include "EppLaunchProtection.hpp"

class EPP_EXPORT EppTreatyOrStatuteData : public EppMarkData {
	public:
		EppTreatyOrStatuteData();
		EppTreatyOrStatuteData(const EppTreatyOrStatuteData&);
		virtual ~EppTreatyOrStatuteData();
		EppTreatyOrStatuteData& operator=(const EppTreatyOrStatuteData&);

		void refNum(const DOMString&);
		DOMString refNum(void);

		void proDate(time_t);
		void proDate(const DOMString &);
		time_t proDate(void);

		void title(const DOMString& _cc);
		DOMString title(void);

		void exDate(time_t);
		void exDate(const DOMString &);
		time_t exDate(void);

		void addRegion(const EppLaunchProtection& _r);
		ValueVectorOf<EppLaunchProtection> region(void);

		virtual DOM_Element toXML(DOM_Document &doc, const DOMString &tag);
		static EppTreatyOrStatuteData* fromXML( const DOM_Node& root );
		virtual DOMString toString();

	private:
		ValueVectorOf<EppLaunchProtection> _region;
		DOMString _refNum; /*registration number of TM*/ 
		time_t _proDate; /*optional*/ 
		DOMString _title;
		time_t _exDate; /*optional*/ 
};
#endif
