#if ! defined(EPPSERVICEMENU_HPP)    /* { */
#define       EPPSERVICEMENU_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppServiceMenu.hpp,v 1.2 2006/03/01 01:35:37 wtan Exp $
 */
#include <util/ValueVectorOf.hpp>
#include "EppEntity.hpp"

#define	MAX_NUM_OF_VERSIONS	5
#define	MAX_NUM_OF_SERVICES	10
#define	MAX_NUM_OF_LANGUAGES	20
#define	MAX_NUM_OF_UNSPECS	10

/**
 * This <code>EppServiceMenu</code> class implements EPP svcMenuType entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:37 $
 */
class EPP_EXPORT EppServiceMenu : public EppEntity
{
protected:
	/**
	 * The version list of the EPP Service Menu
	 */
	ValueVectorOf<DOMString> * version;
	/**
	 * The language list of the EPP Service Menu
	 */
	ValueVectorOf<DOMString> * lang;
	/**
	 * The standard object URI list of the EPP Service Menu (EPP-1.0).
	 * For example: "urn:ietf:params:xml:ns:obj1"
	 */
	ValueVectorOf<DOMString> * objURI;
	/**
	 * The <I>svcExtension</I> object list of the EPP Service Menu (EPP-1.0).
	 * For example: "http://custom/obj1ext-1.0 obj1ext-1.0.xsd"
	 */
	ValueVectorOf<DOMString> * extURI;

public:
	/**
	 * Creates an <code>EppServiceMenu</code> object
	 */
	EppServiceMenu()
	{
		this->version = new ValueVectorOf<DOMString>(MAX_NUM_OF_VERSIONS);
		this->lang    = new ValueVectorOf<DOMString>(MAX_NUM_OF_LANGUAGES);
		this->objURI  = new ValueVectorOf<DOMString>(MAX_NUM_OF_SERVICES);
		this->extURI  = new ValueVectorOf<DOMString>(MAX_NUM_OF_UNSPECS);
	};

	/**
	 * Destructor
	 */
	~EppServiceMenu()
	{
		if( this->version != null )
		{
			delete this->version;
		}
		if( this->lang != null )
		{
			delete this->lang;
		}
		if( this->objURI != null )
		{
			delete this->objURI;
		}
		if( this->extURI != null )
		{
			delete this->extURI;
		}
		this->version = null;
		this->lang    = null;
		this->objURI  = null;
		this->extURI  = null;
	};

	/**
	 * Returns a <code>Vector</code> containing all version numbers
	 * supported by the EPP server
	 */
	ValueVectorOf<DOMString> * getVersion()
	{
		return this->version;
	};

	/**
	 * Adds a version number to the list of versions supported by the
	 * EPP server
	 */
	void addVersion( DOMString version )
	{
		this->version->addElement(version);
	};

	/**
	 * Returns a <code>Vector</code> containing all languages supported
	 * by the Epp server
	 */
	ValueVectorOf<DOMString> * getLanguage()
	{
		return this->lang;
	};

	/**
	 * Adds a language to the list of languages supported by the
	 * EPP server
	 */
	void addLanguage( DOMString language )
	{
		this->lang->addElement(language);
	};

	/**
	 * Returns a <code>Vector</code> containing the the URIs
	 * for all standard objects supported by the EPP server
	 */
	ValueVectorOf<DOMString> * getService()
	{
		return this->objURI;
	};

	/**
	 * Adds an object URI to the list of all standard objects supported by
	 * the EPP server
	 */
	void addService( DOMString service )
	{
		this->objURI->addElement(service);
	};

	/**
	 * Returns a <code>Vector</code> containing the URIs of
	 * all <I>extension</I> objects supported by the EPP server - alias to getServiceExtention()
	 */
	ValueVectorOf<DOMString> * getUnspec()
	{
		return this->extURI;
	};

	/**
	 * Returns a <code>Vector</code> containing the URIs of
	 * all <I>extension</I> objects supported by the EPP server
	 */
	ValueVectorOf<DOMString> * getServiceExtension()
	{
		return this->extURI;
	};

	/**
	 * Adds an <I>extension</I> object to the list of all <I>extURI</I>
	 * objects supported by the EPP server
	 */
	void addServiceExtension( DOMString uri )
	{
		this->extURI->addElement(uri);
	};

	/**
	 * Adds an <I>extension</I> object to the list of all <I>extension</I>
	 * objects supported by the EPP server
	 *
	 * @param name the name of the object (not used)
	 * @param uri the uri of the object
	 * @param schema the XML schema defining the object (not used)
	 *
	 * <P><B>Note:</B> This method is retained for backward compatiblity
	 */
        void addUnspec( DOMString name, DOMString uri, DOMString schema )
	{
		this->extURI->addElement(uri);
	};

	/**
	 * Converts the <code>EppServiceMenu</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the <code>EppServiceMenu</code>
	 *            object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppServiceMenu</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP addrType.
	 *
	 * @param root root node for an <code>EppServiceMenu</code> object
	 *             in XML format
	 *
	 * @return an <code>EppServiceMenu</code> object, or null if the node
	 *         is invalid
	 */
	static EppServiceMenu * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("svcMenu"));
	};
};

#endif     /* EPPSERVICEMENU_HPP */  /* } */
