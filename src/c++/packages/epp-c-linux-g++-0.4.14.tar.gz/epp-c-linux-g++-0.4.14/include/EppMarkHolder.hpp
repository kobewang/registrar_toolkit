#if ! defined(EPPEPPMARKHOLDER_HPP)    /* { */
#define       EPPEPPMARKHOLDER_HPP 1
#include <time.h>
#include "EppEntity.hpp"
#include "EppMarkAddress.hpp"
#include "EppE164.hpp"

enum holderType { EPPMARK_HOLDER,EPPMARK_CONTACT };

class EPP_EXPORT EppMarkHolder : public EppEntity {
	public:
		EppMarkHolder( holderType _t=EPPMARK_HOLDER);
		EppMarkHolder( const EppMarkHolder &);
		virtual ~EppMarkHolder();
		EppMarkHolder& operator=(const EppMarkHolder&);

		void name(const DOMString&);
		DOMString name(void);
		void org(const DOMString&);
		DOMString org(void);
		void address(const EppMarkAddress &);
		EppMarkAddress address(void);
		void voice(const DOMString&);
		DOMString voice(void);
		void fax(const DOMString&);
		DOMString fax(void);
		void email(const DOMString&);
		DOMString email(void);
		void type(holderType _t);
		holderType type(void);
		void holderParam(const DOMString &);
		DOMString holderParam(void);

 /* NOTE: need to keep _type field in consideration as attribute type/entitlement depends on it.*/ 
		virtual DOM_Element toXML(DOM_Document &doc, const DOMString &tag);
 /* NOTE: need to keep _type field in consideration as attribute type/entitlement depends on it.*/
		static EppMarkHolder* fromXML( const DOM_Node& root );
		virtual DOMString toString();

	private:
		DOMString _name;/* optional unless org is specified */ 
		DOMString _org;/* optional if _name is specified */ 
		EppMarkAddress _addr;/* address of the entiry */ 
		EppE164 _voice; /* optional phone number */ 
		EppE164 _fax; /* optional fax number */ 
		DOMString _email; /* optional email */ 
		DOMString _addParam; /*some TM data can specify type/entitlement param to oject*/ 
		holderType _type; /*identifies if it's type of holder or contact*/ 
};
#endif
