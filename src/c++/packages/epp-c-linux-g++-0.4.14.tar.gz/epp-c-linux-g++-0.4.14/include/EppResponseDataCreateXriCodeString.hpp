#if ! defined(EPPRESPONSEDATACREATEXRICODESTRING_HPP)    /* { */
#define       EPPRESPONSEDATACREATEXRICODESTRING_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataCreateXriCodeString.hpp,v 1.1 2009/11/23 14:35:22 nseshadr Exp $
 */
#include "EppResponseDataCreate.hpp"

/**
 * This <code>EppResponseDataCreateXriCodeString</code> class implements EPP
 * Response Data entity for EPP Command Create of EPP XRI CodeString objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2009/11/23 14:35:22 $
 */
class EPP_EXPORT EppResponseDataCreateXriCodeString : public EppResponseDataCreate
{
private:
	DOMString codeString;

public:
	/**
	 * Creates an <code>EppResponseDataCreateXriCodeString</code> object
	 */
	EppResponseDataCreateXriCodeString()
	{
		this->codeString = null;
		this->crDate = time(0);
	};

	/**
	 * Creates an <code>EppResponseDataCreateXriCodeString</code> object,
	 * given the XRI authority identifier, with the current date as the creation date
	 */
	EppResponseDataCreateXriCodeString( DOMString codeString )
	{
		this->codeString = codeString;
		this->crDate = time(0);
	};

	/**
	 * Creates an <code>EppResponseDataCreateXriCodeString</code> object,
	 * given the XRI authority identifier and the creation date
	 */
	EppResponseDataCreateXriCodeString( DOMString codeString, time_t crDate )
	{
		this->codeString = codeString;
		this->crDate = crDate;
	};

	/**
	 * Sets the XRI authority identifier
	 */
	void setCodeString( DOMString codeString )
	{
		this->codeString = codeString;
	};

	/**
	 * Gets the XRI authority identifier
	 */
	DOMString getCodeString()
	{
		return this->codeString;
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCreateXriCodeString;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCreateXriCodeString</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XriCodeString object.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCreateXriCodeString</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCreateXriCodeString</code> object, or null
	 *         if the node is invalid
	 */
	static EppResponseDataCreateXriCodeString * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataCreateXriCodeString</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCreateXriCodeString</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATACREATEXRIAUTHORITY_HPP */  /* } */
