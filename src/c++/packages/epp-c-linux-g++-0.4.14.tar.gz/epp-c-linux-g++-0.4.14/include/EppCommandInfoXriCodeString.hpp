#if ! defined(EPPCOMMANDINFOXRICODESTRING_HPP)    /* { */
#define       EPPCOMMANDINFOXRICODESTRING_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandInfoXriCodeString.hpp,v 1.2 2010/01/04 11:30:41 nseshadr Exp $
 */
#include "EppCommandInfo.hpp"

class EPP_EXPORT EppCommandInfoXriCodeString : public EppCommandInfo {
private:
	DOMString		codeString;
public:
	EppCommandInfoXriCodeString() {
		this->codeString = null;
		clTRID   = null;
	};

	EppCommandInfoXriCodeString( DOMString codeString) {
		this->codeString   = codeString;
		clTRID   = null;
	};

	EppCommandInfoXriCodeString( DOMString codeString, DOMString xid ) {
		this->codeString   = codeString;
		clTRID   = xid;
	};

	~EppCommandInfoXriCodeString() {
	};

	virtual int getEntityType() {
		return EppEntity::TYPE_EppCommandInfoXriCodeString;
	};

	DOMString getCodeString() {
		return this->codeString;
	};
	

	void setCodeString( DOMString codeString ) {
		this->codeString = codeString;
	};
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
	static EppCommandInfoXriCodeString * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDINFOXRICODESTRING_HPP */  /* } */
