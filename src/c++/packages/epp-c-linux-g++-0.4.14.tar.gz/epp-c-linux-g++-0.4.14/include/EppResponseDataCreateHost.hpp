#if ! defined(EPPRESPONSEDATACREATEHOST_HPP)    /* { */
#define       EPPRESPONSEDATACREATEHOST_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataCreateHost.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppResponseDataCreate.hpp"

/**
 * This <code>EppResponseDataCreateHost</code> class implements EPP
 * Response Data entity for EPP Command Create of EPP Contact objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataCreateHost : public EppResponseDataCreate
{
private:
	DOMString name;

public:
	/**
	 * Creates an <code>EppResponseDataCreateHost</code> object
	 */
	EppResponseDataCreateHost()
	{
		this->name = null;
		this->roid = null;
	};

	/**
	 * Creates an <code>EppResponseDataCreateHost</code> object
	 *
	 * @param name the name of the <code>EppHost</code> object created
	 */
	EppResponseDataCreateHost( DOMString name )
	{
		this->name = name;
		this->roid = null;
		this->crDate = time(0);
	};

	/**
	 * Creates an <code>EppResponseDataCreateHost</code> object
	 *
	 * @param name the name of the <code>EppHost</code> object created
	 * @param crDate the date of the <code>EppHost</code> object was created
	 */
	EppResponseDataCreateHost( DOMString name, time_t crDate )
	{
		this->name = name;
		this->roid = null;
		this->crDate = crDate;
	};

	/**
	 * Creates an <code>EppResponseDataCreateHost</code> object
	 *
	 * @param name the name of the <code>EppHost</code> object created
	 * @param roid the ROID of the <code>EppHost</code> object created
	 *
	 * @deprecated for EPP-04 (06/29/2001)
	 */
	EppResponseDataCreateHost( DOMString name, DOMString roid )
	{
		this->name = name;
		this->roid = roid;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataCreateHost() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCreateHost;
	};

	/**
	 * Gets the name of the host created
	 */
	DOMString getName()
	{
		return this->name;
	};

	/**
	 * Sets the name of the host created
	 */
	void setName( DOMString name )
	{
		this->name = name;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCreateHost</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP Host object
	 *
	 * @param root root node for an <code>EppResponseDataCreateHost</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataCreateHost</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataCreateHost * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataCreateHost</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataCreateHost</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATACREATEHOST_HPP */  /* } */
