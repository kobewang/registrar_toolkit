#if ! defined(EPPEXTENSION_HPP)    /* { */
#define       EPPEXTENSION_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppExtension.hpp,v 1.3 2012/05/18 05:38:49 nseshadr Exp $
 */
#include "EppEntity.hpp"

#define EPPSECDNS_NONE		0
#define EPPSECDNS_10			16
#define EPPSECDNS_11			17

#define EPPSECDNSMAJOR_MASK (240 & ( (1<<7)|(1<<6)|(1<<5)|(1<<4) ))
#define EPPSECDNSMINOR_MASK (15 & ( (1<<3)|(1<<2)|(1<<1)|(1<<0) ))
#define getDnsSecMajor(i) ((((uint8_t)i) & (EPPSECDNSMAJOR_MASK))>>4)
#define getDnsSecMinor(i) (((uint8_t)i) & (EPPSECDNSMINOR_MASK))
#define setDnsSecVersion(ma,mi) ( (((uint8_t)ma)<<4) | ((uint8_t)mi) )

/**
 * This <code>EppExtension</code> class implements EPP Extension entity.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.3 $ $Date: 2012/05/18 05:38:49 $
 */
class EPP_EXPORT EppExtension : public EppEntity {
	public:
		/**
		 * Creates an <code>EppExtension</code> object
		 */
		EppExtension():secDnsVersion(setDnsSecVersion(0,0))
		{
		};

		/**
		 * Destructor
		 */
		virtual ~EppExtension();

		/**
		 * Returns the run-time type of an EppEntity object
		 */
		virtual int getEntityType()
		{
			return EppEntity::TYPE_EppExtension;
		};

		virtual int getDnsSecMajorVersion()
		{
			return (int)(getDnsSecMajor(this->secDnsVersion));
		}
		virtual int getDnsSecMinorVersion()
		{
			return (int)(getDnsSecMinor(this->secDnsVersion));
		}

		/**
		 * Converts an XML element into an <code>EppExtension</code> object.
		 * The caller of this method must make sure that the root node is a
		 * child node of an EPP extension tag
		 *
		 * @param root root node for an <code>EppExtension</code> object in XML format
		 *
		 * @return an <code>EppExtension</code> object, or null if the node is invalid
		 */
		static EppExtension* fromXML( const DOM_Node &root );
	protected:
		uint8_t secDnsVersion;
	private:
};

#endif     /* EPPEXTENSION_HPP */  /* } */
