#if ! defined(EPPRESPONSEDATAPENDINGCONTACT_HPP)	/* { */
#define	      EPPRESPONSEDATAPENDINGCONTACT_HPP		   1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataPendingContact.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppResponseDataPending.hpp"

/**
 * This <code>EppResponseDataPendingContact</code> class implements EPP
 * Response Data entity for EPP Pending Actions of EPP Contact objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataPendingContact : public EppResponseDataPending
{
private:
	DOMString   id;

public:
	/**
	 * Creates an <code>EppResponseDataPendingContact</code> object
	 *
	 * @param id the id of the <code>EppContact</code> object associated with the pending action
	 */
	EppResponseDataPendingContact( DOMString id )
	{
		this->id = id;
		this->paResult = false;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataPendingContact</code> object
	 *
	 * @param id the id of the <code>EppContact</code> object associated with the pending action
	 * @param result the boolean flag indicating if the pending action is a success or a failure
	 */
	EppResponseDataPendingContact( DOMString id, bool result )
	{
		this->id = id;
		this->paResult = result;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = null;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataPendingContact() {};

	/**
	 * Gets the id of the contact object associated with the pending action
	*/
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the id of the contact object associated with the pending action
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataPendingContact;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataPendingContact</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP Contact object
	 *
	 * @param root root node for an <code>EppResponseDataPendingContact</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataPendingContact</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataPendingContact * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataPendingContact</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataPendingContact</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif	/*    EPPRESPONSEDATAPENDINGCONTACT_HPP */	/* } */
