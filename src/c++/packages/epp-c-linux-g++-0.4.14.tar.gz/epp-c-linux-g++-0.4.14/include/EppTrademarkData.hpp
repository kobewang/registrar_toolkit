#if ! defined(EPPEPPTRADEMARKDATA_HPP)    /* { */
#define       EPPEPPTRADEMARKDATA_HPP 1
#include <time.h>
#include "EppEntity.hpp"
#include "EppMarkData.hpp"

class EPP_EXPORT EppTrademarkData : public EppMarkData {
	public:
		EppTrademarkData();
		EppTrademarkData(const EppTrademarkData&);
		virtual ~EppTrademarkData();
		EppTrademarkData& operator=(const EppTrademarkData&);

		void jurisdiction(const DOMString&);
		DOMString jurisdiction(void);

		void tmClass(int);
		ValueVectorOf<int> tmClass(void);
		
		
		void apId(const DOMString &);
		DOMString apId(void);

		void apDate(const DOMString &);
		time_t apDate(void);

		void regNum(const DOMString &);
		DOMString regNum(void);

		void regDate(const DOMString &);
		time_t regDate(void);

		void exDate(const DOMString &);
		time_t exDate(void);

		virtual DOM_Element toXML(DOM_Document &doc, const DOMString &tag);
		static EppTrademarkData* fromXML( const DOM_Node& root );
		virtual DOMString toString();

	private:
		DOMString _jurisdiction; 
		ValueVectorOf<int> _class; /* * */ 
		DOMString _apId; /*optional*/ 
		time_t _apDate; /*optional*/ 
		DOMString _regNum; /*registration number of TM*/ 
		time_t _regDate; /*registration date*/ 
		time_t _exDate;/*optional: expiration date*/
};
#endif
