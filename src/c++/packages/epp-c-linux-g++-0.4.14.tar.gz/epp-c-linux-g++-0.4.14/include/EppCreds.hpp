#if ! defined(EPPCREDS_HPP)    /* { */
#define       EPPCREDS_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCreds.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppEntity.hpp"
#include "EppCredsOptions.hpp"

/**
 * This <code>EppCreds</code> class implements EPP credsType entity.
 *
 * <P><B>Warning</B>: This class is for backward compatibility. It will be
 * removed in the future version.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppCreds : public EppEntity
{
private:
	DOMString         clID;
	DOMString         pw;
	DOMString         newPW;
	EppCredsOptions * options;

public:
	/**
	 * Creates an <code>EppCreds</code> object
	 */
	EppCreds()
	{
		this->clID = null;
		this->pw = null;
		this->newPW = null;
		this->options = null;
	};

	/**
	 * Creates an <code>EppCreds</code> object, given the registrar client
	 * id and the password
	 *
	 * @param clientId client/registrar id
	 * @param password the password for the client/registrar
	 */
	EppCreds( DOMString clientId, DOMString password )
	{
		this->clID = clientId;
		this->pw = password;
		this->newPW = null;
		this->options = new EppCredsOptions("1.0", "en-US");
	};

	/**
	 * Creates an <code>EppCreds</code> object, given the registrar client
	 * id, the current password, and the new password
	 *
	 * @param clientId registrar client id
	 * @param password the current password for the registrar client
	 * @param newPassword the new password replacing the current password
	 */
	EppCreds( DOMString clientId, DOMString password, DOMString newPassword )
	{
		this->clID = clientId;
		this->pw = password;
		this->newPW = newPassword;
		this->options = new EppCredsOptions("1.0", "en-US");
	};

	/**
	 * Destructor
	 */
	~EppCreds()
	{
		if( this->options != null )
		{	
			delete this->options;
			this->options = null;
		}
	};

	/**
	 * Gets registrar client id
	 */
	DOMString getClientId()
	{
		return this->clID;
	};

	/**
	 * Sets registrar client id
	 */
	void setClientId( DOMString clientId )
	{
		this->clID = clientId;
	};

	/**
	 * Gets registrar client's password
	 */
	DOMString getPassword()
	{
		return this->pw;
	};

	/**
	 * Sets registrar client's password
	 */
	void setPassword( DOMString password )
	{
		this->pw = password;
	};

	/**
	 * Gets registrar client's new password
	 */
	DOMString getNewPassword()
	{
		return this->newPW;
	};

	/**
	 * Sets registrar client's new password
	 */
	void setNewPassword( DOMString newPassword )
	{
		this->newPW = newPassword;
	};

	/**
	 * Gets credentials options
	 */
	EppCredsOptions * getOptions()
	{
		return this->options;
	};

	/**
	 * Sets credentials options
	 */
	void setOptions( EppCredsOptions options )
	{
		if( this->options == null )
		{
			this->options = new EppCredsOptions();
		}
		*(this->options) = options;
	};

	/**
	 * Converts the <code>EppCreds</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the <code>EppCreds</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCreds</code> object. The
	 * caller of this method must make sure that the root node is of the
	 * EPP credsType.
	 *
	 * @param root root node for an <code>EppCreds</code> object in XML format
	 *
	 * @return an <code>EppCreds</code> object, or null if the node is invalid
	 */
	static EppCreds * fromXML( const DOM_Node& root );

	/**
	 * Converts the <code>EppCreds</code> object into plain XML text string
	 * by using the default root tag name
	 *
	 * @return a text string representing the <code>EppCreds</code> object
	 *         in XML format
	 */
	DOMString toString()
	{
		return EppEntity::toString(DOMString("creds"));
	};
};

#endif     /* EPPCREDS_HPP */  /* } */
