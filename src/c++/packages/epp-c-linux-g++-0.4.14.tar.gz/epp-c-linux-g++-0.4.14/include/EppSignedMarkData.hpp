#if ! defined(EPPSIGNEDMARKDATA_HPP)    /* { */
#define       EPPSIGNEDMARKDATA_HPP 1
#if 0
#include <time.h>
#endif
#include "EppEntity.hpp"
#if 0
#include "EppSignedMarkIssuerInfo.hpp"
#include "EppMarkData.hpp"
#include "EppSignature.hpp"
#endif

class EPP_EXPORT EppSignedMarkData: public EppEntity {
	public:
		EppSignedMarkData();
		EppSignedMarkData(const EppSignedMarkData&);
		EppSignedMarkData& operator=(const EppSignedMarkData&);
		virtual ~EppSignedMarkData();
#if 0
		void id(const std::string&);
		std::string id();

		void issuer(const EppSignedMarkIssuerInfo&);
		EppSignedMarkIssuerInfo issuer(void);

		void mark(const EppMarkData&);
		EppMarkData mark(void);

		void signature(const EppSignature&);
		EppSignature signature(void);

		void attribID(const std::string&);
		std::string attribID(void);
#endif
		void rawXml(const DOMString&);
		DOMString rawXml(void);
		bool hasSMD();
		void hasSMD(bool);
#if 0
		void notBefore(time_t);
		void notBefore(const std::string&);
		time_t notBefore(void);

		void notAfter(time_t);
		void notAfter(const std::string&);
		time_t notAfter(void);
#endif
		virtual DOM_Element toXML(DOM_Document &doc, const DOMString &tag);
		virtual DOMString toString();
		static EppSignedMarkData* fromXML( const DOM_Node& root );
		virtual int getEntityType();
	private:
#if 0
		/*we shall be keeping only the raw XML and shall be passed to APP as is*/
		std::string id;
		EppSignedMarkIssuerInfo _issuer;
		time_t _notBefore;
		time_t _notAfter;
		EppMarkData _mark;
		EppSignature _sig;
		std::string _attributeID;/*required*/ 
#endif
		DOMString _rawXml; /*shall only be used in C++ RTK*/
		bool _hasElement;
};
#endif
