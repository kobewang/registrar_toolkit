#if ! defined(EPPRESPONSEDATAPOLL_HPP)    /* { */
#define       EPPRESPONSEDATAPOLL_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataPoll.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppResponseData.hpp"
#include "EppPollable.hpp"

/**
 * This <code>EppResponseDataPoll</code> class implements EPP Response
 * Data entity for EPP Command Poll.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataPoll : public EppResponseData
{
private:
	EppPollable * object;
	bool          freeable;

public:
	/**
	 * Creates an <code>EppResponseDataPoll</code> object
	 */
	EppResponseDataPoll()
	{
		this->object = null;
		this->freeable = false;
	};

	/**
	 * Creates an <code>EppResponseDataPoll</code> object
	 *
	 * @note the memory associated with the object data will not be
	 *       freed by this class. The caller of this method should be
	 *       responsible to free the memory, if needed.
	 */
	EppResponseDataPoll( EppPollable * object )
	{
		this->object = object;
		this->freeable = false;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataPoll()
	{
		if( this->freeable )
		{
			if( this->object != null )
			{
				delete this->object;
			}
		}
		this->object = null;
	};

	/**
	 * Gets the <code>EppPollable</code> object returned by the EPP poll
	 * poll command
	 */
	EppPollable * getPollable()
	{
		return this->object;
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataPoll;
	};

	/**
	 * Sets the <code>EppPollable</code> object returned by the EPP
	 * poll command
	 *
	 * @note the memory associated with the object data will not be
	 *       freed by this class. The caller of this method should be
	 *       responsible to free the memory, if needed.
	 */
	void setPollable( EppPollable * object )
	{
		if( this->freeable )
		{
			if( this->object != null )
			{
				delete this->object;
			}
			this->freeable = false;
		}
		this->object = object;
	};

	/**
	 * Converts the <code>EppResponseDataPoll</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the <code>EppResponse</code>
	 *            object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppResponseDataPoll</code>
	 * object. The caller of this method must make sure that the root
	 * node is of the EPP transferType.
	 *
	 * @param root root node for an <code>EppResponseDataPoll</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataPoll</code> object, or null
	 *         if the node is invalid
	 */
	static EppResponseDataPoll * fromXML( const DOM_Node& root );
};

#endif     /* EPPRESPONSEDATAPOLL_HPP */  /* } */
