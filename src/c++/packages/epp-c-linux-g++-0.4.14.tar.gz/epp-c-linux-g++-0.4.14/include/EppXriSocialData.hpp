#if ! defined(EPPXRISOCIALDATA_HPP)    /* { */
#define       EPPXRISOCIALDATA_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppXriSocialData.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppEntity.hpp"
#include "EppE164.hpp"
#include "EppContactData.hpp"

/**
 * This <code>EppXriSocialData</code> class defines social
 * information associated with XRI authority objects.  It
 * implements XRI socialDataType and chgSocialDataType defined
 * in the XRI authority schema file.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppXriSocialData : public EppEntity
{
private:
	EppContactData	* postalInfo;
	EppE164		* voicePrimary;
	EppE164         * voiceSecondary;
	bool		  voiceNullified;
	EppE164         * fax;
	bool	          faxNullified;
	EppE164         * pager;
	bool	          pagerNullified;
	DOMString         emailPrimary;
	DOMString         emailSecondary;
	bool		  emailNullified;

public:
	/**
	 * Creates an <code>EppXriSocialData</code> object
	 */
	EppXriSocialData()
	{
		this->postalInfo     = null;
		this->voicePrimary   = null;
		this->voiceSecondary = null;
		this->fax            = null;
		this->pager          = null;
		this->emailPrimary   = null;
		this->emailSecondary = null;

		this->faxNullified   = false;
		this->pagerNullified = false;
		this->voiceNullified = false;
		this->emailNullified = false;
	};

	/**
	 * Destructor
	 */
	~EppXriSocialData()
	{
		if( this->postalInfo != null )
		{
			delete this->postalInfo;
			this->postalInfo = null;
		}
		if( this->voicePrimary != null )
		{
			delete this->voicePrimary;
			this->voicePrimary = null;
		}
		if( this->voiceSecondary != null )
		{
			delete this->voiceSecondary;
			this->voiceSecondary = null;
		}
		if( this->fax != null )
		{
			delete this->fax;
			this->fax = null;
		}
		if( this->pager != null )
		{
			delete this->pager;
			this->pager = null;
		}
	};

	/**
	 * Sets up postal information of the XRI authority
	 */
	void setPostalInfo( EppContactData& postalInfo )
	{
		if( this->postalInfo == null )
		{
			this->postalInfo = new EppContactData();
		}
		*(this->postalInfo) = postalInfo;
	};

	/**
	 * Gets the postal information of the XRI authoruty
	 */
	EppContactData * getPostalInfo()
	{
		return this->postalInfo;
	};

	/**
	 * Returns true if voice numbers are to be nullified via an EPP update command
	 */
	bool isVoiceNullified()
	{
		return this->voiceNullified;
	};

	/**
	 * Gets the primary voice phone number
	 */
	EppE164 * getPrimaryVoice()
	{
		return this->voicePrimary;
	};

	/**
	 * Sets the primary voice phone number
	 */
	void setPrimaryVoice( DOMString voice )
	{
		this->setPrimaryVoice(EppE164(voice));
		this->voiceNullified = false;
	};

	/**
	 * Sets the primary voice phone number and extenstion
	 */
	void setPrimaryVoice( DOMString voice, DOMString ext )
	{
		this->setPrimaryVoice(EppE164(voice, ext));
		this->voiceNullified = false;
	};

	/**
	 * Sets the primary voice phone number
	 */
	void setPrimaryVoice( EppE164 voice )
	{
		if( this->voicePrimary == null )
		{
			this->voicePrimary = new EppE164();
		}
		*(this->voicePrimary) = voice;
		this->voiceNullified = false;
	};

	/**
	 * Gets the secondary voice phone number
	 */
	EppE164 * getSecondaryVoice()
	{
		return this->voiceSecondary;
	};

	/**
	 * Sets the secondary voice phone number
	 */
	void setSecondaryVoice( DOMString voice )
	{
		this->setSecondaryVoice(EppE164(voice));
		this->voiceNullified = false;
	};

	/**
	 * Sets the secondary voice phone number and extenstion
	 */
	void setSecondaryVoice( DOMString voice, DOMString ext )
	{
		this->setSecondaryVoice(EppE164(voice, ext));
		this->voiceNullified = false;
	};

	/**
	 * Sets the secondary voice phone number
	 */
	void setSecondaryVoice( EppE164 voice )
	{
		if( this->voiceSecondary == null )
		{
			this->voiceSecondary = new EppE164();
		}
		*(this->voiceSecondary) = voice;
		this->voiceNullified = false;
	};

	/**
	 * Nullifies the voice number via an EPP update command
	 */
	void nullifyVoice()
	{
		if( this->voicePrimary != null )
		{
			delete this->voicePrimary;
		}
		if( this->voiceSecondary != null )
		{
			delete this->voiceSecondary;
		}
		this->voicePrimary = null;
		this->voiceSecondary = null;
		this->voiceNullified = true;
	};

	/**
	 * Returns true if fax is to be nullified via an EPP update command
	 */
	bool isFaxNullified()
	{
		return this->faxNullified;
	};

	/**
	 * Gets the fax number
	 */
	EppE164 * getFax()
	{
		return this->fax;
	};

	/**
	 * Sets the fax number
	 */
	void setFax( DOMString fax )
	{
		this->setFax(EppE164(fax));
	};

	/**
	 * Sets the fax number and extenstion
	 */
	void setFax( DOMString fax, DOMString ext )
	{
		this->setFax(EppE164(fax, ext));
	};

	/**
	 * Sets the fax number
	 */
	void setFax( EppE164 fax )
	{
		if( this->fax == null )
		{
			this->fax = new EppE164();
		}
		*(this->fax) = fax;
		this->faxNullified = false;
	};

	/**
	 * Nullifies the fax number via an EPP update command
	 */
	void nullifyFax()
	{
		if( this->fax != null )
		{
			delete this->fax;
		}
		this->fax = null;
		this->faxNullified = true;
	};

	/**
	 * Returns true if pager is to be nullified via an EPP update command
	 */
	bool isPagerNullified()
	{
		return this->pagerNullified;
	};

	/**
	 * Gets the pager number
	 */
	EppE164 * getPager()
	{
		return this->pager;
	};

	/**
	 * Sets the pager number
	 */
	void setPager( DOMString pager )
	{
		this->setPager(EppE164(pager));
	};

	/**
	 * Sets the pager number and extenstion
	 */
	void setPager( DOMString pager, DOMString ext )
	{
		this->setPager(EppE164(pager, ext));
	};

	/**
	 * Sets the pager number
	 */
	void setPager( EppE164 pager )
	{
		if( this->pager == null )
		{
			this->pager = new EppE164();
		}
		*(this->pager) = pager;
		this->pagerNullified = false;
	};

	/**
	 * Nullifies the pager number via an EPP update command
	 */
	void nullifyPager()
	{
		if( this->pager != null )
		{
			delete this->pager;
		}
		this->pager = null;
		this->pagerNullified = true;
	};

	/**
	 * Gets the primary email address
	 */
	DOMString getPrimaryEmail()
	{
		return this->emailPrimary;
	};

	/**
	 * Returns true if email addresses are to be nullified via an EPP update command
	 */
	bool isEmailNullified()
	{
		return this->emailNullified;
	};

	/**
	 * Sets the primary email address
	 */
	void setPrimaryEmail( DOMString email )
	{
		this->emailPrimary = email;
		this->emailNullified = false;
	};

	/**
	 * Gets the secondary email address
	 */
	DOMString getSecondaryEmail()
	{
		return this->emailSecondary;
	};

	/**
	 * Sets the secondary email address
	 */
	void setSecondaryEmail( DOMString email )
	{
		this->emailSecondary = email;
		this->emailNullified = false;
	};

	/**
	 * Nullifies the email addresses via an EPP update command
	 */
	void nullifyEmail()
	{
		this->emailPrimary = null;
		this->emailSecondary = null;
		this->emailNullified = true;
	};

	/**
         * Converts the <code>EppXriSocialData</code> object into an XML element
         *
         * @param doc the XML <code>DOM_Document</code> object
         * @param tag the tag/element name for the <code>EppXriSocialData</code> object
         *
         * @return an <code>DOM_Element</code> object
         */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppXriSocialData</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP XRI socialDataType or chgSocialDataType.
	 *
	 * @param root root node for an <code>EppXriSocialData</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriSocialData</code> object, or null if the node is
	 *         invalid
	 */
	static EppXriSocialData * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return  EppEntity::toString(DOMString("socialData"));
	};
};

#endif     /* EPPXRISOCIALDATA_HPP */  /* } */
