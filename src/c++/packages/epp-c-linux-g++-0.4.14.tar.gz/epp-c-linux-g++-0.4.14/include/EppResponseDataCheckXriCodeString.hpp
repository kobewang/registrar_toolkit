#if ! defined(EPPRESPONSEDATACHECKXRICODESTRING_HPP)    /* { */
#define       EPPRESPONSEDATACHECKXRICODESTRING_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataCheckXriCodeString.hpp,v 1.1 2009/11/23 14:35:20 nseshadr Exp $
 */
#include "EppResponseDataCheck.hpp"

/**
 * This <code>EppResponseDataCheckXriCodeString</code> class implements EPP
 * Response Data entity for EPP Command Check of EPP XRI CodeString objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.1 $ $Date: 2009/11/23 14:35:20 $
 */
class EPP_EXPORT EppResponseDataCheckXriCodeString : public EppResponseDataCheck
{
public:
	/**
	 * Checks an <code>EppResponseDataCheckXriCodeString</code> object
	 */
	EppResponseDataCheckXriCodeString() {};

	/**
	 * Destructor
	 */
	~EppResponseDataCheckXriCodeString() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCheckXriCodeString;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCheckXriCodeString</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for checking EPP XRI CodeString objects.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCheckXriCodeString</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCheckXriCodeString</code> object, or null
	 *         if the node is invalid
	 */
	static EppResponseDataCheckXriCodeString * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataCheckXriCodeString</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCheckXriCodeString</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATACHECKXRIAUTHORITY_HPP */  /* } */
