#if ! defined(EPPLAUNCHPHASE_HPP)    /* { */
#define       EPPLAUNCHPHASE_HPP 1
#include <time.h>
#include "EppEntity.hpp"

class EPP_EXPORT EppLaunchPhase : public EppEntity {
	public:
		EppLaunchPhase();/*ctor*/ 
		EppLaunchPhase(const EppLaunchPhase&);/*copy ctor*/ 
		virtual ~EppLaunchPhase();/*d'tor*/ 
		EppLaunchPhase& operator=(const EppLaunchPhase&);/*assigment*/ 
		/* getter(s) | setter(s) */ 
		DOMString phase(void);
		void phase(const DOMString &);
		DOMString subPhase(void);
		void subPhase(const DOMString &);
		virtual DOM_Element toXML(DOM_Document &doc, const DOMString &tag);
		static EppLaunchPhase* fromXML( const DOM_Node& root );
		virtual DOMString toString();
	private:
		DOMString _phase;
		DOMString _sub_phase;
};

#endif
