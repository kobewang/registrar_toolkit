#if ! defined(EPPUNSPEC_HPP)    /* { */
#define       EPPUNSPEC_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppUnspec.hpp,v 1.4 2010/09/29 13:54:43 achowdhu Exp $
 */
#include "EppEntity.hpp"
#include "EppGenericNVPairs.hpp"

/**
 * This <code>EppUnspec</code> class implements EPP unspecType objects defined in EPP-04.
 * In EPP-1.0, it becomes a special class for handling NeuLevel's EPP extension with full
 * name space specification required in the XML representation.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.4 $ $Date: 2010/09/29 13:54:43 $
 */
class EPP_EXPORT EppUnspec : public EppEntity
{
private:
	DOMString value;
	EppGenericNVPairs * nvPairs;

public:
	/**
	 * Creates an <code>EppUnspec</code> object
	 */
	EppUnspec()
	{
		value = null;
		nvPairs = null;
	};

	/**
	 * Creates an <code>EppUnspec</code> object with a value
	 */
	EppUnspec( DOMString value )
	{
		this->value = value;
		this->nvPairs = new EppGenericNVPairs();
	};

        /**
         * Creates an <code>EppUnspec</code> object with a value
         */
        EppUnspec( DOMString value , EppGenericNVPairs & pairs)
        {
                this->value = value;
                this->nvPairs = new EppGenericNVPairs(pairs);
        };

	
	/**     
         * Destructor
         */  
	~EppUnspec() 
	{
		if( this->nvPairs != null )
		{
			delete this->nvPairs;
			this->nvPairs = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppExtensionUnspec;
	};

	/**
	 * Gets the value associated with <code>EppUnspec</code> object
	 */
	DOMString getValue()
	{
		return this->value;
	};

	/**
	 * Sets the value associated with <code>EppUnspec</code> object
	 */
	void setValue( const DOMString& value )
	{
		this->value = value;
	};

	/**
	 * Converts the <code>EppUnspec</code> object into an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the <code>EppUnspec</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document &doc, const DOMString &tag );

	/**
	 * Converts an XML element into an <code>EppUnspec</code> object.
	 * The caller of this method must make sure that the root node is of
	 * EPP unspecType
	 *
	 * @param root root node for an <code>EppUnspec</code> object in XML format
	 *
	 * @return an <code>EppUnspec</code> object, or null if the node is invalid
	 */
	static EppUnspec * fromXML( const DOM_Node &root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("unspec"));
	};
	void setGenericNVPairs ( EppGenericNVPairs & pairs)
	{
		if( this->nvPairs != null ) {
			delete this->nvPairs;
			this->nvPairs = null;
		}
		this->nvPairs = new EppGenericNVPairs(pairs);
	}
	EppGenericNVPairs * getGenericNVPairs()
	{
		return this->nvPairs;
	}
	EppUnspec & operator=(EppUnspec & r_unspec)
	{
		if(this != &r_unspec)
		{
			delete nvPairs;
                	this->value = r_unspec.getValue();
		        this->nvPairs = new EppGenericNVPairs(*r_unspec.getGenericNVPairs());


		}
		return *this;
	}
	EppUnspec(EppUnspec & c_unspec)
	{
		value = c_unspec.getValue();
		nvPairs = new EppGenericNVPairs(*c_unspec.getGenericNVPairs());
	}
};

#endif     /* EPPUNSPEC_HPP */  /* } */
