#if ! defined(EPPXRISERVICEENDPOINTRULE_HPP)    /* { */
#define       EPPXRISERVICEENDPOINTRULE_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppXriServiceEndpointRule.hpp,v 1.3 2006/05/12 13:14:13 wtan Exp $
 */
#include "EppEntity.hpp"


/**
 * This <code>EppXriServiceEndpointRule</code> abstract class
 * encapsulates the common EPP XRI Authority ServiceEndpoint rules
 * (Type, MediaType and Path).
 *
 * @author William Tan william.tan@neustar.biz
 * @version $Revision: 1.3 $ $Date: 2006/05/12 13:14:13 $
 */
class EPP_EXPORT EppXriServiceEndpointRule : public EppEntity
{
private:
	static const bool _TRUE;
	static const bool _FALSE;

protected:
	DOMString    match;
	const bool  *select;
	DOMString    value;


public:
	static const char * MATCH_ATTR_DEFAULT;
	static const char * MATCH_ATTR_CONTENT;
	static const char * MATCH_ATTR_ANY;
	static const char * MATCH_ATTR_NON_NULL;
	static const char * MATCH_ATTR_NULL;
	static const char * MATCH_ATTR_NONE;

	static const char * DEFAULT_MATCH_ATTR;

	static const bool DEFAULT_SELECT_ATTR;

protected:
	/**
	 * Creates an <code>EppXriServiceEndpoint</code> object
	 */
	EppXriServiceEndpointRule()
	{
		this->value  = null;
		this->match  = null;
		this->select = null;
	}

	/**
	 * Creates an <code>EppXriServiceEndpoint</code> object
	 */
	EppXriServiceEndpointRule( DOMString value, DOMString match, bool select )
	{
		this->value  = value;
		this->match  = match;
		this->select = (select)? &_TRUE : &_FALSE;
	};


public:
	/**
	 * Destructor
	 */
	virtual ~EppXriServiceEndpointRule()
	{
	};

	/**
	 * Gets the "match" attribute value of this rule object
	 */
	DOMString getMatch()
	{
		return this->match;
	};

	/**
	 * Sets the "match" attribute value of this rule object
	 */
	void setMatch( DOMString match )
	{
		this->match = match;
	};

	/**
	 * Gets the select attribute value for this rule object
	 */
	const bool *getSelect()
	{
		return this->select;
	};

	/**
	 * Sets the select attribute value for this rule object
	 */
	void setSelect( const bool *select )
	{
		if (select == null)
			this->select = null;
		else
			this->select = (*select)? &_TRUE : &_FALSE;
	};

	/**
	 * Gets the text value of this rule object
	 */
	DOMString getValue()
	{
		return this->value;
	};

	/**
	 * Sets the text value of this rule object
	 */
	void setValue( DOMString value )
	{
		this->value = value;
	};

	/**
         * Converts the <code>EppXriServiceEndpoint</code> object into an XML element
         *
         * @param doc the XML <code>DOM_Document</code> object
         * @param tag the tag/element name for the <code>EppXriServiceEndpoint</code> object
         *
         * @return an <code>DOM_Element</code> object
         */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppXriServiceEndpoint</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP XRI sepAddType or sepInfType.
	 *
	 * @param root root node for an <code>EppXriServiceEndpoint</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriServiceEndpoint</code> object, or null if the node is
	 *         invalid
	 */
	void setFromXML( const DOM_Node& root );

};

#endif     /* EPPXRISERVICEENDPOINTRULE_HPP */  /* } */
