#if ! defined(EPPCOMMANDDELETEXRICODESTRING_HPP)    /* { */
#define       EPPCOMMANDDELETEXRICODESTRING_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandDeleteXriCodeString.hpp,v 1.1 2009/12/30 19:47:09 nseshadr Exp $
 */
#include "EppCommandDelete.hpp"

class EPP_EXPORT EppCommandDeleteXriCodeString : public EppCommandDelete {
private:
	DOMString		codeString;
public:
	EppCommandDeleteXriCodeString() {
		this->codeString = null;
		clTRID   = null;
	};

	EppCommandDeleteXriCodeString( DOMString codeString) {
		this->codeString   = codeString;
		clTRID   = null;
	};

	EppCommandDeleteXriCodeString( DOMString codeString, DOMString xid ) {
		this->codeString   = codeString;
		clTRID   = xid;
	};

	~EppCommandDeleteXriCodeString() {
	};

	virtual int getEntityType() {
		return EppEntity::TYPE_EppCommandDeleteXriCodeString;
	};

	DOMString getCodeString() {
		return this->codeString;
	};
	

	void setCodeString( DOMString codeString ) {
		this->codeString = codeString;
	};
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
	static EppCommandDeleteXriCodeString * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDDELETEXRICODESTRING_HPP */  /* } */
