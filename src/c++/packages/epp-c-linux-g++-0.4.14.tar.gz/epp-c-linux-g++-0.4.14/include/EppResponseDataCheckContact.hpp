#if ! defined(EPPRESPONSEDATACHECKCONTACT_HPP)    /* { */
#define       EPPRESPONSEDATACHECKCONTACT_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataCheckContact.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppResponseDataCheck.hpp"

/**
 * This <code>EppResponseDataCheckContact</code> class implements EPP
 * Response Data entity for EPP Command Check of EPP Contact objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataCheckContact : public EppResponseDataCheck
{
public:
	/**
	 * Creates an <code>EppResponseDataCheckContact</code> object
	 */
	EppResponseDataCheckContact() {};

	/**
	 * Destructor
	 */
	~EppResponseDataCheckContact() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCheckContact;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCheckContact</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP Contact object.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCheckContact</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCheckContact</code> object, or null
	 *         if the node is invalid
	 */
	static EppResponseDataCheckContact * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataCheckContact</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCheckContact</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATACHECKCONTACT_HPP */  /* } */
