#if ! defined(EPPRESPONSEDATACREATECONTACT_HPP)    /* { */
#define       EPPRESPONSEDATACREATECONTACT_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataCreateContact.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppResponseDataCreate.hpp"

/**
 * This <code>EppResponseDataCreateContact</code> class implements EPP
 * Response Data entity for EPP Command Create of EPP Contact objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataCreateContact : public EppResponseDataCreate
{
private:
	DOMString id;

public:
	/**
	 * Creates an <code>EppResponseDataCreateContact</code> object
	 */
	EppResponseDataCreateContact()
	{
		this->id = null;
	};

	/**
	 * Creates an <code>EppResponseDataCreateContact</code> object,
	 * given the contact id, with the current date as the creation date
	 */
	EppResponseDataCreateContact( DOMString id )
	{
		this->id = id;
		this->crDate = time(0);
	};

	/**
	 * Creates an <code>EppResponseDataCreateContact</code> object,
	 * given the contact id and the creation date
	 */
	EppResponseDataCreateContact( DOMString id, time_t crDate )
	{
		this->id = id;
		this->crDate = crDate;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataCreateContact() {};

	/**
	 * Gets the contact id
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the contact id
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCreateContact;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCreateContact</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP Contact object.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCreateContact</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCreateContact</code> object, or null
	 *         if the node is invalid
	 */
	static EppResponseDataCreateContact * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataCreateContact</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCreateContact</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATACREATECONTACT_HPP */  /* } */
