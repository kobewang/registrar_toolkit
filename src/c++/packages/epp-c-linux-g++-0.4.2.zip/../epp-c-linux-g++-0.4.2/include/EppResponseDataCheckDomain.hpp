#if ! defined(EPPRESPONSEDATACHECKDOMAIN_HPP)    /* { */
#define       EPPRESPONSEDATACHECKDOMAIN_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataCheckDomain.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppResponseDataCheck.hpp"

/**
 * This <code>EppResponseDataCheckDomain</code> class implements EPP
 * Response Data entity for EPP Command Check of EPP Domain objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataCheckDomain : public EppResponseDataCheck
{
public:
	/**
	 * Creates an <code>EppResponseDataCheckDomain</code> object
	 */
	EppResponseDataCheckDomain() {};

	/**
	 * Destructor
	 */
	~EppResponseDataCheckDomain() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataCheckDomain;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataCheckDomain</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP Domain object.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataCheckDomain</code> object
	 *             in XML format
	 *
	 * @return an <code>EppResponseDataCheckDomain</code> object, or null
	 *         if the node is invalid
	 */
	static EppResponseDataCheckDomain * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataCheckDomain</code> object into
	 * an XML element.
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataCheckDomain</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif     /* EPPRESPONSEDATACHECKDOMAIN_HPP */  /* } */
