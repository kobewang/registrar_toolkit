#if ! defined(EPPCOMMANDINFOXRIINAME_HPP)    /* { */
#define       EPPCOMMANDINFOXRIINAME_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandInfoXriName.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppCommandInfo.hpp"

/**
 * This <code>EppCommandInfo</code> class implements EPP Command Info
 * entity for EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppCommandInfoXriName : public EppCommandInfo
{
private:
	DOMString iname;

public:
	/**
	 * Creates an <code>EppCommandInfoXriName</code> object for
	 * querying an XRI i-name based on its i-name
	 */
	EppCommandInfoXriName( DOMString iname )
	{
		this->iname = iname;
	};

	/**
	 * Creates an <code>EppCommandInfoXriName</code> object for
	 * querying an XRI i-name based on its i-name, given a client
	 * transaction id associated with the operation
	 */
	EppCommandInfoXriName( DOMString iname, DOMString xid )
	{
		this->iname = iname;
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandInfoXriName() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandInfoXriName;
	};

	/**
	 * Gets the i-name of the XRI i-name object to be queried
	 */
	DOMString getIName()
	{
		return this->iname;
	};

	/**
	 * Sets the i-name of the XRI i-name object to be queried
	 */
	void setIName( DOMString iname )
	{
		this->iname = iname;
	};

	/**
	 * Converts the <code>EppCommandInfoXriName</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandInfoXriName</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandInfoXriName</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Info entity for EPP XriName object.
	 *
	 * @param root root node for an <code>EppCommandInfoXriName</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandInfoXriName</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandInfoXriName * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDINFOXRIINAME_HPP */  /* } */
