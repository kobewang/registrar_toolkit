#if ! defined(EPPRESPONSEDATATRANSFERCONTACT_HPP)    /* { */
#define       EPPRESPONSEDATATRANSFERCONTACT_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataTransferContact.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppResponseDataTransfer.hpp"

/**
 * This <code>EppResponseDataTransferContact</code> class implements EPP
 * Response Data entity for EPP Command Transfer of EPP Contact objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataTransferContact : public EppResponseDataTransfer
{
private:
	DOMString id;

public:
	/**
	 * Creates an <code>EppResponseDataTransferContact</code> object
	 */
	EppResponseDataTransferContact()
	{
		this->id = null;
	};

	/**
	 * Creates an <code>EppResponseDataTransferContact</code> object
	 */
	EppResponseDataTransferContact( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataTransferContact() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataTransferContact;
	};

	/**
	 * Gets the id of the EPP Contact object
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the id of the EPP Contact Object
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Converts the <code>EppResponseDataTransferContact</code> object into
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataTransferContact</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataTransferContact</code> object. The caller
	 * of this method must make sure that the root node is of an EPP
	 * Response Transfer entity for EPP Contact object.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataTransferContact</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataTransferContact</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataTransferContact * fromXML( const DOM_Node& root );
};

#endif     /* EPPRESPONSEDATATRANSFERCONTACT_HPP */  /* } */
