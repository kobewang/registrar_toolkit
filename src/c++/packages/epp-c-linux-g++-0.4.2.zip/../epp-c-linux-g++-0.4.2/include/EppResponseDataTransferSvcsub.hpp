#if ! defined(EPPRESPONSEDATATRANSFERSVCSUB_HPP)    /* { */
#define       EPPRESPONSEDATATRANSFERSVCSUB_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataTransferSvcsub.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppResponseDataTransfer.hpp"

/**
 * This <code>EppResponseDataTransferSvcsub</code> class implements EPP
 * Response Data entity for EPP Command Transfer of EPP Svcsub objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $
 */
class EPP_EXPORT EppResponseDataTransferSvcsub : public EppResponseDataTransfer
{
private:
	DOMString id;
	DOMString service;

public:
	/**
	 * Creates an <code>EppResponseDataTransferSvcsub</code> object
	 */
	EppResponseDataTransferSvcsub()
	{
		this->id = null;
		this->service = null;
	};

	/**
	 * Creates an <code>EppResponseDataTransferSvcsub</code> object
	 */
	EppResponseDataTransferSvcsub( DOMString id )
	{
		this->id = id;
		this->service = null;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataTransferSvcsub() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataTransferSvcsub;
	};

	/**
	 * Gets the id of the EPP Svcsub object
	 */
	DOMString getId()
	{
		return this->id;
	};

	/**
	 * Sets the id of the EPP Svcsub object
	 */
	void setId( DOMString id )
	{
		this->id = id;
	};

	/**
	 * Gets the new expiration date of the subscription object after the
	 * transfer, or null if the transfer request does not change the
	 * expiration date of the subscription object.
	 */
	time_t getDateExpired()
	{
		return this->exDate;
	};

	/**
	 * Sets the new expiration date of the subscription object after the
	 * transfer. The value of the new expiration date is optional.
	 */
	void setDateExpired( time_t date )
	{
		this->exDate = date;
	};

	/**
	 * Gets the service name
	 */
	DOMString getService()
	{
		return this->service;
	};

	/**
	 * Sets the service name
	 */
	void setService( DOMString service )
	{
		this->service = service;
        };

	/**
	 * Converts the <code>EppResponseDataTransferSvcsub</code> object into
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppResponseDataTransferSvcsub</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataTransferSvcsub</code> object. The caller of
	 * this method must make sure that the root node is of an EPP Response
	 * Transfer entity for EPP Svcsub object.
	 *
	 * @param root root node for an
	 *             <code>EppResponseDataTransferSvcsub</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataTransferSvcsub</code> object, or null
	 *         if the node is invalid
	 */
	static EppResponseDataTransferSvcsub * fromXML( const DOM_Node& root );
};

#endif     /* EPPRESPONSEDATATRANSFERSVCSUB_HPP */  /* } */
