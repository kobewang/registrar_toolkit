#if ! defined(EPPCOMMANDCHECKDOMAIN_HPP)    /* { */
#define       EPPCOMMANDCHECKDOMAIN_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandCheckDomain.hpp,v 1.2 2006/03/01 01:35:37 wtan Exp $
 */
#include "EppCommandCheck.hpp"

#define	MAX_NUM_OF_DOMAIN_NAMES	16

/**
 * This <code>EppCommandCheckDomain</code> class implements EPP Command Check
 * entity for EPP Domain objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:37 $
 */
class EPP_EXPORT EppCommandCheckDomain : public EppCommandCheck
{
private:
	ValueVectorOf<DOMString> * names;

public:
	/**
	 * Creates an <code>EppCommandCheckDomain</code> object
	 */
	EppCommandCheckDomain()
	{
		this->names = new ValueVectorOf<DOMString>(MAX_NUM_OF_DOMAIN_NAMES);
	};

	/**
	 * Creates an <code>EppCommandCheckDomain</code> object, given a
	 * client transaction id associated with the operation
	 */
	EppCommandCheckDomain( DOMString xid )
	{
		this->names = new ValueVectorOf<DOMString>(MAX_NUM_OF_DOMAIN_NAMES);
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandCheckDomain()
	{
		if( this->names != null )
		{
			delete this->names;
			this->names = null;
		}
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandCheckDomain;
	};

	/**
	 * Gets the list of the names of the domain objects to be checked
	 */
	ValueVectorOf<DOMString> * getName()
	{
		return this->names;
	};

	/**
	 * Gets the list of the names of the domain objects to be checked
	 *
	 * @note this is an alias for <code>getName</code>
	 */
	ValueVectorOf<DOMString> * get()
	{
		return this->getName();
	}

	/**
	 * Add a domain name to the list of the names of the domain
	 * objects to be checked
	 */
	void addName( DOMString name )
	{
		this->names->addElement(name);
	};

	/**
	 * Add a domain name to the list of the names of the domain
	 * objects to be checked
	 *
	 * @note this is an alias for <code>addName</code>
	 */
	void add( DOMString name )
	{
		this->addName(name);
	};

	/**
	 * Converts the <code>EppCommandCheckDomain</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Element</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandCheckDomain</code> object
	 *
	 * @return an <code>DOM_Element</code> object 
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandCheckDomain</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Check entity for EPP Domain objects.
	 *
	 * @param root root node for an <code>EppCommandCheckDomain</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandCheckDomain</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandCheckDomain * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDCHECKDOMAIN_HPP */  /* } */
