#if ! defined(EPPRESPONSEDATAPENDINGXRIINUMBER_HPP)	/* { */
#define	      EPPRESPONSEDATAPENDINGXRIINUMBER_HPP		   1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppResponseDataPendingXriNumber.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppResponseDataPending.hpp"

/**
 * This <code>EppResponseDataPendingXriNumber</code> class implements EPP
 * Response Data entity for EPP Pending Actions of EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppResponseDataPendingXriNumber : public EppResponseDataPending
{
private:
	DOMString   inumber;

public:
	/**
	 * Creates an <code>EppResponseDataPendingXriNumber</code> object
	 *
	 * @param inumber the i-number of the <code>EppXriNumber</code> object associated with the pending action
	 */
	EppResponseDataPendingXriNumber( DOMString inumber )
	{
		this->inumber = inumber;
		this->paResult = false;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = 0;
	};

	/**
	 * Creates an <code>EppResponseDataPendingXriNumber</code> object
	 *
	 * @param inumber the i-number of the <code>EppXriNumber</code> object associated with the pending action
	 * @param result the boolean flag indicating if the pending action is a success or a failure
	 */
	EppResponseDataPendingXriNumber( DOMString inumber, bool result )
	{
		this->inumber = inumber;
		this->paResult = result;
		this->paTRID.setClientTransactionId(null);
		this->paTRID.setServiceTransactionId(null);
		this->paDate = null;
	};

	/**
	 * Destructor
	 */
	~EppResponseDataPendingXriNumber() {};

	/**
	 * Gets the i-number of the XRI i-number object associated with the pending action
	*/
	DOMString getINumber()
	{
		return this->inumber;
	};

	/**
	 * Sets the i-number of the XRI i-number object associated with the pending action
	 */
	void setINumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppResponseDataPendingXriNumber;
	};

	/**
	 * Converts an XML element into an
	 * <code>EppResponseDataPendingXriNumber</code> object. The caller of this
	 * method must make sure that the root node is the resData element of
	 * EPP responseType for creating an EPP XRI I-Number object
	 *
	 * @param root root node for an <code>EppResponseDataPendingXriNumber</code>
	 *             object in XML format
	 *
	 * @return an <code>EppResponseDataPendingXriNumber</code> object,
	 *         or null if the node is invalid
	 */
	static EppResponseDataPendingXriNumber * fromXML( const DOM_Node& root );

	/**
	 * Converts an <code>EppResponseDataPendingXriNumber</code> object
	 * into an XML element.
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *        <code>EppResponseDataPendingXriNumber</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );
};

#endif	/*    EPPRESPONSEDATAPENDINGXRIINUMBER_HPP */	/* } */
