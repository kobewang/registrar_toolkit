#if ! defined(EPPXRIREF_HPP)    /* { */
#define       EPPXRIREF_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppXriRef.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppEntity.hpp"

/**
 * This <code>EppXriRef</code> class defines references
 * associated with XRI authority objects.  It
 * implements XRI refAddType and refInfType defined
 * in the XRI authority schema file.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppXriRef : public EppEntity
{
private:
	unsigned short int priority;
	DOMString          xs;

public:
	/**
	 * Default priority value - 10
	 */
	static const unsigned short int DEFAULT_PRIORITY;

	/**
	 * Creates an <code>EppXriRef</code> object
	 */
	EppXriRef()
	{
		this->priority = DEFAULT_PRIORITY;
		this->xs       = null;
	};

	/**
	 * Creates an <code>EppXriRef</code> object with a reference
	 * and the default priority value
	 */
	EppXriRef( DOMString xs )
	{
		this->priority = DEFAULT_PRIORITY;
		this->xs       = xs;
	};

	/**
	 * Creates an <code>EppXriRef</code> object with a reference
	 * and a priority value
	 */
	EppXriRef( DOMString xs, unsigned short int priority )
	{
		this->priority = priority;
		this->xs       = xs;
	};

	/**
	 * Destructor
	 */
	~EppXriRef() {} ;

	/**
	 * Gets the priority value for this reference
	 */
	unsigned short int getPriority()
	{
		return this->priority;
	};

	/**
	 * Sets the priority value for this reference
	 */
	void setPriority( unsigned short int priority )
	{
		this->priority = priority;
	};

	/**
	 * Gets the XRI string of the reference
	 */
	DOMString getRef()
	{
		return this->xs;
	}

	/**
	 * Sets the XRI string of the reference
	 */
	void setRef( DOMString xs )
	{
		this->xs = xs;
	};

	/**
         * Converts the <code>EppXriRef</code> object into an XML element
         *
         * @param doc the XML <code>DOM_Document</code> object
         * @param tag the tag/element name for the <code>EppXriRef</code> object
         *
         * @return an <code>DOM_Element</code> object
         */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppXriRef</code> object.
	 * The caller of this method must make sure that the root node is of
	 * the EPP XRI xsAddType or xsInfType.
	 *
	 * @param root root node for an <code>EppXriRef</code> object in
	 *             XML format
	 *
	 * @return an <code>EppXriRef</code> object, or null if the node is
	 *         invalid
	 */
	static EppXriRef * fromXML( const DOM_Node& root );

	DOMString toString()
	{
		return EppEntity::toString(DOMString("xs"));
	};
};

#endif     /* EPPXRIREF_HPP */  /* } */
