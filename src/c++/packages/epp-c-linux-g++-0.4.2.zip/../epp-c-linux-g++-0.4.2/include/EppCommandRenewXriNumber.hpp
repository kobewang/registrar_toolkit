#if ! defined(EPPCOMMANDRENEWXRIINUMBER_HPP)    /* { */
#define       EPPCOMMANDRENEWXRIINUMBER_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandRenewXriNumber.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppCommandRenew.hpp"

/**
 * This <code>EppCommandRenewXriNumber</code> class implements EPP Command Renew
 * entity for EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppCommandRenewXriNumber : public EppCommandRenew
{
private:
	 DOMString inumber;

public:
	/**
	 * Creates an <code>EppCommandRenewXriNumber</code> object
	 */
	EppCommandRenewXriNumber()
	{
		this->inumber = null;
	};

	/**
	 * Creates an <code>EppCommandRenewXriNumber</code> object with a
	 * default expiration period, specified by the registry
	 */
	EppCommandRenewXriNumber( DOMString inumber, time_t curExpDate )
	{
		this->inumber = inumber;
		this->curExpDate = curExpDate;
	};

	/**
	 * Creates an <code>EppCommandRenewXriNumber</code> object with a
	 * client transaction id associated with the operation. The current
	 * date of expiration would be the current date.
	 */
	EppCommandRenewXriNumber( DOMString inumber, DOMString xid )
	{
		this->inumber = inumber;
		this->clTRID = xid;
	};

	/**
	 * Creates an <code>EppCommandRenewXriNumber</code> object with a
	 * default expiration period, specified by the registry, and a
	 * client transaction id associated with the operation
	 */
	EppCommandRenewXriNumber( DOMString inumber, time_t curExpDate, DOMString xid )
	{
		this->inumber = inumber;
		this->curExpDate = curExpDate;
		this->clTRID = xid;
	};

	/**
	 * Creates an <code>EppCommandRenewXriNumber</code> object with a
	 * specified expiration period, and a client transaction id associated
	 * with the operation
	 */
	EppCommandRenewXriNumber( DOMString inumber, time_t curExpDate, EppPeriod period, DOMString xid )
	{
		this->inumber = inumber;
		this->curExpDate = curExpDate;
		this->clTRID = xid;
		this->setPeriod(period);
	};

	/**
	 * Destructor
	 */
	~EppCommandRenewXriNumber() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandRenewXriNumber;
	};

	/**
	 * Gets the i-number of the XRI i-number object to be renewed
	 */
	DOMString getINumber()
	{
		return this->inumber;
	};

	/**
	 * Sets the i-number of the XRI i-number object to be renewed
	 */
	void setINumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Converts the <code>EppCommandRenewXriNumber</code> object into
	 *		an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *		<code>EppCommandRenewXriNumber</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandRenewXriNumber</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Renew entity for EPP XRI I-Number object
	 *
	 * @param root root node for an <code>EppCommandRenewXriNumber</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandRenewXriNumber</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandRenewXriNumber * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDRENEWXRIINUMBER_HPP */  /* } */
