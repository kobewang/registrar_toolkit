#if ! defined(EPPCOMMANDDELETEXRIINUMBER_HPP)    /* { */
#define       EPPCOMMANDDELETEXRIINUMBER_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandDeleteXriNumber.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppCommandDelete.hpp"

/**
 * This <code>EppCommandDelete</code> class implements EPP Command Delete
 * entity for EPP XRI I-Number objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppCommandDeleteXriNumber : public EppCommandDelete
{
private:
	DOMString inumber;

public:
	/**
	 * Creates an <code>EppCommandDeleteXriNumber</code> object for
	 * deleting an XRI i-number based on its i-number
	 */
	EppCommandDeleteXriNumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Creates an <code>EppCommandDeleteXriNumber</code> object for
	 * deleting an XRI i-number based on its i-number, given a client
	 * transaction id associated with the operation
	 */
	EppCommandDeleteXriNumber( DOMString inumber, DOMString xid )
	{
		this->inumber = inumber;
		this->clTRID = xid;
	};

	/**
	 * Destructor
	 */
	~EppCommandDeleteXriNumber() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandDeleteXriNumber;
	};

	/**
	 * Gets the i-number of the XRI i-number object to be deleted
	 */
	DOMString getINumber()
	{
		return this->inumber;
	};

	/**
	 * Sets the i-number of the XRI i-number object to be deleted
	 */
	void setINumber( DOMString inumber )
	{
		this->inumber = inumber;
	};

	/**
	 * Converts the <code>EppCommandDeleteXriNumber</code> object into an XML
	 * element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the
	 *            <code>EppCommandDeleteXriNumber</code> object
	 *
	 * @return an <code>DOM_Element</code> object
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandDeleteXriNumber</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Delete entity for EPP XriNumber object.
	 *
	 * @param root root node for an <code>EppCommandDeleteXriNumber</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandDeleteXriNumber</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandDeleteXriNumber * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDDELETEXRIINUMBER_HPP */  /* } */
