#if ! defined(EPPCOMMANDUPDATEXRIINAME_HPP)    /* { */
#define       EPPCOMMANDUPDATEXRIINAME_HPP        1
/*
 * Copyright (c) 2001-2006 NeuStar, Inc. All Rights Reserved.
 *
 * $Id: EppCommandUpdateXriName.hpp,v 1.2 2006/03/01 01:35:38 wtan Exp $
 */
#include "EppCommandUpdate.hpp"

/**
 * This <code>EppCommandUpdateXriName</code> class implements EPP Command Update
 * entity for EPP XRI I-Name objects.
 *
 * @author Ning Zhang ning.zhang@neustar.com
 * @version $Revision: 1.2 $ $Date: 2006/03/01 01:35:38 $
 */
class EPP_EXPORT EppCommandUpdateXriName : public EppCommandUpdate
{
private:
	DOMString iname;

public:
	/**
	 * Creates an <code>EppCommandUpdateXriName</code>
	 */
	EppCommandUpdateXriName()
	{
		this->iname = null;
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandUpdateXriName</code> given the
	 * i-name of the XRI i-name object
	 */
	EppCommandUpdateXriName( DOMString iname )
	{
		this->iname = iname;
		this->clTRID = null;
	};

	/**
	 * Creates an <code>EppCommandUpdateXriName</code> given the
	 * i-name of the XRI i-name object and a client transaction id
	 */
	EppCommandUpdateXriName( DOMString iname, DOMString xid )
	{
		this->iname = iname;
		this->clTRID = xid;
	};

	/**
	 * Destricutor
	 */
	~EppCommandUpdateXriName() {};

	/**
	 * Returns the run-time type of an EppEntity object
	 */
	virtual int getEntityType()
	{
		return EppEntity::TYPE_EppCommandUpdateXriName;
	};

	/**
	 * Gets the i-name of the XRI i-name object to be updated
	 */
	DOMString getIName()
	{
		return this->iname;
	};

	/**
	 * Sets the i-name of the XRI i-name object to be updated
	 */
	void setIName( DOMString iname )
	{
		this->iname = iname;
	};

	/**
	 * Converts the <code>EppCommandUpdateXriName</code> object into 
	 * an XML element
	 *
	 * @param doc the XML <code>DOM_Document</code> object
	 * @param tag the tag/element name for the 
	 *            <code>EppCommandUpdateXriName</code> object
	 *
	 * @return an <code>DOM_Element</code> object 
	 */
	DOM_Element toXML( DOM_Document& doc, const DOMString& tag );

	/**
	 * Converts an XML element into an <code>EppCommandUpdateXriName</code>
	 * object. The caller of this method must make sure that the root node
	 * is of an EPP Command Update entity for an EPP XRI I-Name object.
	 *
	 * @param root root node for an <code>EppCommandUpdateXriName</code>
	 *             object in XML format
	 *
	 * @return an <code>EppCommandUpdateXriName</code> object, or null
	 *         if the node is invalid
	 */
	static EppCommandUpdateXriName * fromXML( const DOM_Node& root );
};

#endif     /* EPPCOMMANDUPDATEXRIINAME_HPP */  /* } */
